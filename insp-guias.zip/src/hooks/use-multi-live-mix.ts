import { useCallback, useEffect, useRef, useState } from "react";
import { toast } from "sonner";
import { loadAudioBuffer } from "@/lib/audio/buffer-cache";
import { getAudioContext } from "@/lib/audio/decode";

export type LiveLayer = { entry: number; trimStart: number; trimEnd: number | null; gain: number; muted: boolean };

/**
 * Player ao vivo com várias vozes sobre o beat: cada voz tem sua fonte,
 * então mudar entrada/corte/volume de uma guia soa na hora sem parar.
 */
export function useMultiLiveMix(beatPath: string | null | undefined, voices: { id: string; path: string }[]) {
  const [beat, setBeat] = useState<AudioBuffer | null>(null);
  const [buffers, setBuffers] = useState<Record<string, AudioBuffer>>({});
  const [playing, setPlaying] = useState(false);
  const [time, setTime] = useState(0);
  const layers = useRef<Record<string, LiveLayer>>({});
  const beatGainValue = useRef(0.85);
  const nodes = useRef<{ startedAt: number; beat: AudioBufferSourceNode | null; beatGain: GainNode; voices: Record<string, { src: AudioBufferSourceNode | null; gain: GainNode }> } | null>(null);
  const key = voices.map((v) => `${v.id}:${v.path}`).join("|");

  useEffect(() => {
    let live = true;
    if (beatPath) loadAudioBuffer(beatPath).then((b) => live && setBeat(b)).catch(() => {});
    for (const v of voices) loadAudioBuffer(v.path).then((b) => live && setBuffers((p) => ({ ...p, [v.id]: b }))).catch(() => {});
    return () => { live = false; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [beatPath, key]);

  const stop = useCallback(() => {
    const n = nodes.current;
    if (n) {
      try { n.beat?.stop(); } catch { /* parado */ }
      for (const v of Object.values(n.voices)) { try { v.src?.stop(); } catch { /* parado */ } }
    }
    nodes.current = null;
    setPlaying(false);
  }, []);
  useEffect(() => () => stop(), [stop]);

  const schedule = useCallback((id: string) => {
    const n = nodes.current;
    const buf = buffers[id];
    const layer = layers.current[id];
    if (!n || !buf || !layer) return;
    const ctx = getAudioContext();
    let slot = n.voices[id];
    if (!slot) { const gain = ctx.createGain(); gain.connect(ctx.destination); slot = { src: null, gain }; n.voices[id] = slot; }
    try { slot.src?.stop(); } catch { /* parado */ }
    slot.src = null;
    slot.gain.gain.value = layer.muted ? 0 : layer.gain;
    const pos = ctx.currentTime - n.startedAt;
    const a = Math.max(0, layer.trimStart);
    const b = Math.min(buf.duration, layer.trimEnd ?? buf.duration);
    if (b <= a || pos >= layer.entry + b) return;
    const src = ctx.createBufferSource();
    src.buffer = buf;
    src.connect(slot.gain);
    const rel = pos - layer.entry;
    if (rel < a) src.start(n.startedAt + layer.entry + a, a, b - a);
    else src.start(0, rel, b - rel);
    slot.src = src;
  }, [buffers]);

  const play = useCallback(async (from: number) => {
    if (!beat && !Object.keys(buffers).length) { toast.error("Carregando o áudio, tente de novo em instantes."); return; }
    stop();
    const ctx = getAudioContext();
    if (ctx.state === "suspended") await ctx.resume();
    const beatGain = ctx.createGain(); beatGain.gain.value = beatGainValue.current; beatGain.connect(ctx.destination);
    let beatSrc: AudioBufferSourceNode | null = null;
    if (beat && from < beat.duration) {
      beatSrc = ctx.createBufferSource(); beatSrc.buffer = beat; beatSrc.connect(beatGain); beatSrc.start(ctx.currentTime + 0.05, from);
    }
    nodes.current = { startedAt: ctx.currentTime + 0.05 - from, beat: beatSrc, beatGain, voices: {} };
    for (const id of Object.keys(layers.current)) schedule(id);
    setPlaying(true);
  }, [beat, buffers, stop, schedule]);

  const end = Math.max(beat?.duration ?? 0, ...Object.entries(layers.current).map(([id, l]) => l.entry + (buffers[id]?.duration ?? 0)));
  useEffect(() => {
    if (!playing) return;
    let raf = 0;
    const tick = () => {
      const n = nodes.current;
      if (!n) return;
      const t = getAudioContext().currentTime - n.startedAt;
      setTime(Math.max(0, t));
      if (t > end + 0.3) { stop(); return; }
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [playing, end, stop]);

  const setLayer = useCallback((id: string, layer: LiveLayer) => {
    const prev = layers.current[id];
    layers.current[id] = layer;
    const n = nodes.current;
    if (!n) return;
    if (prev && prev.entry === layer.entry && prev.trimStart === layer.trimStart && prev.trimEnd === layer.trimEnd) {
      const slot = n.voices[id];
      if (slot) slot.gain.gain.value = layer.muted ? 0 : layer.gain;
      return;
    }
    schedule(id);
  }, [schedule]);

  const setBeatGain = useCallback((g: number) => {
    beatGainValue.current = g;
    if (nodes.current) nodes.current.beatGain.gain.value = g;
  }, []);

  const seek = useCallback((t: number) => { setTime(t); if (nodes.current) void play(t); }, [play]);

  return { beat, buffers, playing, time, play, stop, seek, setLayer, setBeatGain };
}
