import { useCallback, useEffect, useRef, useState } from "react";

/** Desfazer/refazer leve: guarda os últimos ajustes (arrastes viram 1 passo) enquanto o painel está aberto. */
export function useUndo<T>(value: T, apply: (v: T) => void, limit = 15) {
  const key = JSON.stringify(value);
  const past = useRef<string[]>([]);
  const future = useRef<string[]>([]);
  const last = useRef(key);
  const skip = useRef(false);
  const [, force] = useState(0);

  useEffect(() => {
    if (skip.current) { skip.current = false; last.current = key; return; }
    const t = setTimeout(() => {
      if (last.current === key) return;
      past.current = [...past.current, last.current].slice(-limit);
      future.current = [];
      last.current = key;
      force((n) => n + 1);
    }, 350);
    return () => clearTimeout(t);
  }, [key, limit]);

  const go = useCallback((target: string) => { skip.current = true; apply(JSON.parse(target) as T); force((n) => n + 1); }, [apply]);
  const undo = useCallback(() => {
    if (last.current !== key) { future.current = [key, ...future.current]; go(last.current); return; }
    const prev = past.current.pop();
    if (prev === undefined) return;
    future.current = [key, ...future.current];
    go(prev);
  }, [key, go]);
  const redo = useCallback(() => {
    const next = future.current.shift();
    if (next === undefined) return;
    past.current = [...past.current, last.current].slice(-limit);
    go(next);
  }, [go, limit]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (!(e.ctrlKey || e.metaKey)) return;
      const tag = (e.target as HTMLElement)?.tagName;
      if (tag === "INPUT" || tag === "TEXTAREA") return;
      const k = e.key.toLowerCase();
      if (k === "z" && !e.shiftKey) { e.preventDefault(); undo(); }
      else if (k === "y" || (k === "z" && e.shiftKey)) { e.preventDefault(); redo(); }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [undo, redo]);

  return { undo, redo, canUndo: past.current.length > 0 || last.current !== key, canRedo: future.current.length > 0 };
}
