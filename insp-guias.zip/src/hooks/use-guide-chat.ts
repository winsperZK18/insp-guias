import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import type { GuideComment, Reaction } from "@/lib/chat-types";

const comments = () => supabase.from("guide_comments") as any;
const reactions = () => supabase.from("reactions") as any;

export function useGuideComments(guideId: string) {
  return useQuery({
    queryKey: ["guide-comments", guideId],
    queryFn: async (): Promise<GuideComment[]> => {
      const { data, error } = await comments().select("*").eq("guide_id", guideId).order("created_at");
      if (error) throw new Error(error.message);
      return (data ?? []) as GuideComment[];
    },
    enabled: Boolean(guideId),
  });
}

export function useSendComment(guideId: string) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (input: { project_id: string; body: string; reply_to_id: string | null; mentions: string[] }) => {
      const { data: auth } = await supabase.auth.getUser();
      const { error } = await comments().insert({
        guide_id: guideId,
        project_id: input.project_id,
        author_id: auth.user?.id,
        body: input.body,
        reply_to_id: input.reply_to_id,
        mentions: input.mentions,
      });
      if (error) throw new Error(error.message);
    },
    onSuccess: () => void qc.invalidateQueries({ queryKey: ["guide-comments", guideId] }),
  });
}

export function useDeleteComment(guideId: string) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (id: string) => {
      const { error } = await comments().delete().eq("id", id);
      if (error) throw new Error(error.message);
    },
    onSuccess: () => void qc.invalidateQueries({ queryKey: ["guide-comments", guideId] }),
  });
}

/** Reações de emoji da guia e dos comentários informados. */
export function useReactions(guideId: string, commentIds: string[]) {
  const key = commentIds.slice().sort().join(",");
  return useQuery({
    queryKey: ["reactions", guideId, key],
    queryFn: async (): Promise<Reaction[]> => {
      const own = await reactions().select("*").eq("guide_id", guideId);
      if (own.error) throw new Error(own.error.message);
      let onComments: Reaction[] = [];
      if (commentIds.length) {
        const { data, error } = await reactions().select("*").in("comment_id", commentIds);
        if (error) throw new Error(error.message);
        onComments = (data ?? []) as Reaction[];
      }
      return [...((own.data ?? []) as Reaction[]), ...onComments];
    },
    enabled: Boolean(guideId),
  });
}

export function useToggleReaction(guideId: string) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (input: { emoji: string; commentId?: string | null; existingId?: string | null }) => {
      if (input.existingId) {
        const { error } = await reactions().delete().eq("id", input.existingId);
        if (error) throw new Error(error.message);
        return;
      }
      const { data: auth } = await supabase.auth.getUser();
      const { error } = await reactions().insert({
        emoji: input.emoji,
        user_id: auth.user?.id,
        comment_id: input.commentId ?? null,
        guide_id: input.commentId ? null : guideId,
      });
      if (error) throw new Error(error.message);
    },
    onSuccess: () => void qc.invalidateQueries({ queryKey: ["reactions", guideId] }),
  });
}
