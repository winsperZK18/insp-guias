import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { asGuides, guidesTable } from "@/lib/db";
import { removeAudio } from "@/lib/storage";
import type { Guide, GuideInput } from "@/lib/types";

export function useGuides(projectId: string) {
  return useQuery({
    queryKey: ["guides", projectId],
    queryFn: async (): Promise<Guide[]> => {
      const { data, error } = await guidesTable()
        .select("*")
        .eq("project_id", projectId)
        .order("position", { ascending: true })
        .order("created_at", { ascending: true });
      if (error) throw new Error(error.message);
      return asGuides(data);
    },
    enabled: Boolean(projectId),
  });
}

export function useAllGuides() {
  return useQuery({
    queryKey: ["guides", "all"],
    queryFn: async (): Promise<Guide[]> => {
      const { data, error } = await guidesTable().select("*");
      if (error) throw new Error(error.message);
      return asGuides(data);
    },
  });
}

export function useCreateGuide(projectId: string) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (input: GuideInput) => {
      const { data, error } = await guidesTable().insert(input).select("*").single();
      if (error) throw new Error(error.message);
      return data as Guide;
    },
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: ["guides", projectId] });
      void qc.invalidateQueries({ queryKey: ["guides", "all"] });
    },
  });
}

export function useUpdateGuide(projectId: string) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async ({ id, ...patch }: Partial<Guide> & { id: string }) => {
      const { data, error } = await guidesTable().update(patch).eq("id", id).select("*").single();
      if (error) throw new Error(error.message);
      return data as Guide;
    },
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: ["guides", projectId] });
      void qc.invalidateQueries({ queryKey: ["guides", "all"] });
    },
  });
}

export function useReorderGuides(projectId: string) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (updates: (Partial<Guide> & { id: string })[]) => {
      for (const update of updates) {
        const { id, ...patch } = update;
        const { error } = await guidesTable().update(patch).eq("id", id);
        if (error) throw new Error(error.message);
      }
    },
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: ["guides", projectId] });
      void qc.invalidateQueries({ queryKey: ["guides", "all"] });
    },
  });
}

export function useDeleteGuide(projectId: string) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (guide: Guide) => {
      const { error } = await guidesTable().delete().eq("id", guide.id);
      if (error) throw new Error(error.message);
      await removeAudio([guide.audio_path, guide.processed_path]);
    },
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: ["guides", projectId] });
      void qc.invalidateQueries({ queryKey: ["guides", "all"] });
    },
  });
}
