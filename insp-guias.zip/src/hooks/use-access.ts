import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useCurrentGroup } from "@/hooks/use-groups";

/** Função do usuário no grupo ativo (admin, produtor ou artista). */
export function useAccess() {
  const user = useQuery({
    queryKey: ["current-user-id"],
    queryFn: async () => (await supabase.auth.getUser()).data.user?.id ?? null,
    staleTime: Infinity,
  });
  const { group, isLoading } = useCurrentGroup();
  const role = group?.role ?? null;
  return {
    isLoading: user.isLoading || isLoading,
    userId: user.data ?? null,
    groupId: group?.id ?? null,
    group,
    role,
    isAdmin: role === "admin",
    canManageProjects: role === "admin" || role === "producer",
  };
}
