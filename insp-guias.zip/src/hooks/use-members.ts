import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useCurrentGroup } from "@/hooks/use-groups";
import type { Member } from "@/lib/chat-types";

/** Integrantes do grupo ativo (perfil + função). */
export function useMembers() {
  const { group } = useCurrentGroup();
  const groupId = group?.id ?? null;
  return useQuery({
    queryKey: ["members", groupId],
    enabled: Boolean(groupId),
    queryFn: async (): Promise<Member[]> => {
      const { data: rows, error } = await supabase.from("group_members").select("user_id, role").eq("group_id", groupId!);
      if (error) throw new Error(error.message);
      const ids = (rows ?? []).map((r) => r.user_id);
      const { data: profiles } = ids.length ? await supabase.from("profiles").select("id, email, display_name, avatar_url").in("id", ids) : { data: [] };
      const roleMap = new Map((rows ?? []).map((r) => [r.user_id, r.role as string]));
      return (profiles ?? []).map((p) => ({ ...p, role: roleMap.get(p.id) ?? null }));
    },
    staleTime: 60_000,
  });
}

export function useMemberMap() {
  const query = useMembers();
  const map = new Map((query.data ?? []).map((member) => [member.id, member]));
  return { ...query, map };
}

export function useSetMemberRole() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async ({ groupId, userId, role }: { groupId: string; userId: string; role: "admin" | "producer" | "member" | null }) => {
      const q = supabase.from("group_members");
      const { error } = role ? await q.update({ role }).eq("group_id", groupId).eq("user_id", userId) : await q.delete().eq("group_id", groupId).eq("user_id", userId);
      if (error) throw new Error(error.message);
    },
    onSuccess: () => void qc.invalidateQueries({ queryKey: ["members"] }),
  });
}
