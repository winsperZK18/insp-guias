import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import type { ProjectMessage, Reaction } from "@/lib/chat-types";

const messages = () => supabase.from("project_messages") as any;
const reactions = () => supabase.from("reactions") as any;

export function useProjectMessages(projectId: string) {
  return useQuery({
    queryKey: ["project-messages", projectId],
    queryFn: async (): Promise<ProjectMessage[]> => {
      const { data, error } = await messages().select("*").eq("project_id", projectId).order("created_at");
      if (error) throw new Error(error.message);
      return (data ?? []) as ProjectMessage[];
    },
    enabled: Boolean(projectId),
    refetchInterval: 8000,
  });
}

export function useSendMessage(projectId: string) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (input: { body: string; reply_to_id: string | null; mentions: string[]; guide_refs: string[] }) => {
      const { data: auth } = await supabase.auth.getUser();
      const { error } = await messages().insert({ project_id: projectId, author_id: auth.user?.id, ...input });
      if (error) throw new Error(error.message);
    },
    onSuccess: () => void qc.invalidateQueries({ queryKey: ["project-messages", projectId] }),
  });
}

export function useDeleteMessage(projectId: string) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (id: string) => {
      const { error } = await messages().delete().eq("id", id);
      if (error) throw new Error(error.message);
    },
    onSuccess: () => void qc.invalidateQueries({ queryKey: ["project-messages", projectId] }),
  });
}

export function useMessageReactions(projectId: string, ids: string[]) {
  const key = ids.slice().sort().join(",");
  return useQuery({
    queryKey: ["message-reactions", projectId, key],
    queryFn: async (): Promise<Reaction[]> => {
      if (!ids.length) return [];
      const { data, error } = await reactions().select("*").in("message_id", ids);
      if (error) throw new Error(error.message);
      return (data ?? []) as Reaction[];
    },
  });
}

export function useToggleMessageReaction(projectId: string) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (input: { emoji: string; messageId: string; existingId?: string | null }) => {
      if (input.existingId) {
        const { error } = await reactions().delete().eq("id", input.existingId);
        if (error) throw new Error(error.message);
        return;
      }
      const { data: auth } = await supabase.auth.getUser();
      const { error } = await reactions().insert({ emoji: input.emoji, user_id: auth.user?.id, message_id: input.messageId });
      if (error) throw new Error(error.message);
    },
    onSuccess: () => void qc.invalidateQueries({ queryKey: ["message-reactions", projectId] }),
  });
}
