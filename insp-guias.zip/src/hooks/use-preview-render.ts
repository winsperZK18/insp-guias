import { useCallback, useRef, useState } from "react";
import { toast } from "sonner";
import { useQueryClient } from "@tanstack/react-query";
import { clearAudioBuffer, loadAudioBuffer } from "@/lib/audio/buffer-cache";
import { getAudioContext } from "@/lib/audio/decode";
import { renderPreview } from "@/lib/audio/render-preview";
import { encodeWav } from "@/lib/audio/wav";
import { projectsTable } from "@/lib/db";
import { uploadAudioAt } from "@/lib/storage";
import type { Guide, Project } from "@/lib/types";

export function usePreviewRender(project: Project | null | undefined) {
  const qc = useQueryClient();
  const [busy, setBusy] = useState<string | null>(null);
  const [playing, setPlaying] = useState(false);
  const sourceRef = useRef<AudioBufferSourceNode | null>(null);

  const build = useCallback(
    async (guides: Guide[]) => {
      if (!project) return null;
      const beat = project.beat_path ? await loadAudioBuffer(project.beat_path) : null;
      const layers = [] as { buffer: AudioBuffer; entrySeconds: number; trimStart: number; trimEnd: number | null }[];
      for (const guide of guides) {
        const path = guide.processed_path ?? guide.audio_path;
        try {
          layers.push({ buffer: await loadAudioBuffer(path), entrySeconds: Number(guide.entry_seconds) || 0, trimStart: Number(guide.trim_start_seconds) || 0, trimEnd: guide.trim_end_seconds != null ? Number(guide.trim_end_seconds) : null });
        } catch {
          /* ignora guia que não carregou */
        }
      }
      if (!beat && !layers.length) {
        toast.error("Adicione o beat ou pelo menos uma guia antes de gerar a prévia.");
        return null;
      }
      return await renderPreview(beat, layers);
    },
    [project],
  );

  const stop = useCallback(() => {
    sourceRef.current?.stop();
    sourceRef.current = null;
    setPlaying(false);
  }, []);

  const play = useCallback(
    async (guides: Guide[]) => {
      if (playing) {
        stop();
        return;
      }
      setBusy("Montando a prévia");
      try {
        const buffer = await build(guides);
        if (!buffer) return;
        const ctx = getAudioContext();
        const source = ctx.createBufferSource();
        source.buffer = buffer;
        source.connect(ctx.destination);
        source.onended = () => {
          sourceRef.current = null;
          setPlaying(false);
        };
        source.start();
        sourceRef.current = source;
        setPlaying(true);
      } catch (error) {
        toast.error(error instanceof Error ? error.message : "Não deu para tocar a prévia.");
      } finally {
        setBusy(null);
      }
    },
    [build, playing, stop],
  );

  const save = useCallback(
    async (guides: Guide[]) => {
      if (!project) return;
      setBusy("Gerando e salvando a prévia");
      try {
        const buffer = await build(guides);
        if (!buffer) return;
        const path = `previas/${project.id}.wav`;
        clearAudioBuffer(path);
        await uploadAudioAt(path, encodeWav(buffer), "audio/wav");
        const { error } = await projectsTable()
          .update({ preview_path: path, preview_url: path, preview_created_at: new Date().toISOString() })
          .eq("id", project.id);
        if (error) throw new Error(error.message);
        await qc.invalidateQueries({ queryKey: ["project", project.id] });
        await qc.invalidateQueries({ queryKey: ["audio-url", path] });
        toast.success("Prévia salva.");
      } catch (error) {
        toast.error(error instanceof Error ? error.message : "Não deu para salvar a prévia.");
      } finally {
        setBusy(null);
      }
    },
    [build, project, qc],
  );

  return { busy, playing, play, stop, save };
}
