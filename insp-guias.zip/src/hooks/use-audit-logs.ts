import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import type { AuditLog } from "@/lib/chat-types";
import { useCurrentGroup } from "@/hooks/use-groups";

export type AuditFilters = { entityType: string; actorId: string; from: string; to: string };

export function useAuditLogs(filters: AuditFilters, enabled: boolean) {
  const { group } = useCurrentGroup();
  return useQuery({
    queryKey: ["audit-logs", group?.id, filters],
    queryFn: async (): Promise<AuditLog[]> => {
      let query = (supabase.from("audit_logs") as any)
        .select("*")
        .order("created_at", { ascending: false })
        .eq("group_id", group?.id)
        .limit(300);
      if (filters.entityType !== "todos") query = query.eq("entity_type", filters.entityType);
      if (filters.actorId !== "todos") query = query.eq("actor_id", filters.actorId);
      if (filters.from) query = query.gte("created_at", new Date(filters.from).toISOString());
      if (filters.to) query = query.lte("created_at", new Date(`${filters.to}T23:59:59`).toISOString());
      const { data, error } = await query;
      if (error) throw new Error(error.message);
      return (data ?? []) as AuditLog[];
    },
    enabled: enabled && Boolean(group),
  });
}
