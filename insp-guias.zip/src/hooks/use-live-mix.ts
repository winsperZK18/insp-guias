import { useCallback, useEffect, useRef, useState } from "react";
import { toast } from "sonner";
import { loadAudioBuffer } from "@/lib/audio/buffer-cache";
import { getAudioContext } from "@/lib/audio/decode";

/**
 * Player ao vivo: beat e voz tocam em fontes separadas, então dá para mudar
 * a entrada da voz e os volumes enquanto escuta (estilo DJ).
 */
export function useLiveMix(beatPath: string | null | undefined, voicePath: string | null | undefined, enabled = true) {
  const [beat, setBeat] = useState<AudioBuffer | null>(null);
  const [voice, setVoice] = useState<AudioBuffer | null>(null);
  const [playing, setPlaying] = useState(false);
  const [time, setTime] = useState(0);
  const nodes = useRef<{ startedAt: number; beat: AudioBufferSourceNode | null; voice: AudioBufferSourceNode | null; beatGain: GainNode; voiceGain: GainNode } | null>(null);
  const entryRef = useRef(0);
  const trimRef = useRef<{ start: number; end: number | null }>({ start: 0, end: null });
  const gains = useRef({ voice: 1, beat: 0.85 });

  useEffect(() => {
    if (!enabled) return;
    let live = true;
    if (beatPath) loadAudioBuffer(beatPath).then((b) => live && setBeat(b)).catch(() => {});
    if (voicePath) loadAudioBuffer(voicePath).then((b) => live && setVoice(b)).catch(() => {});
    return () => { live = false; };
  }, [beatPath, voicePath, enabled]);

  const duration = Math.max(beat?.duration ?? 0, entryRef.current + (voice?.duration ?? 0));

  const stop = useCallback(() => {
    const n = nodes.current;
    if (n) {
      try { n.beat?.stop(); } catch { /* já parado */ }
      try { n.voice?.stop(); } catch { /* já parado */ }
    }
    nodes.current = null;
    setPlaying(false);
  }, []);

  useEffect(() => () => stop(), [stop]);

  const scheduleVoice = useCallback(() => {
    const n = nodes.current;
    if (!n || !voice) return;
    try { n.voice?.stop(); } catch { /* já parado */ }
    const ctx = getAudioContext();
    const pos = ctx.currentTime - n.startedAt;
    const entry = entryRef.current;
    const a = Math.max(0, trimRef.current.start);
    const b = Math.min(voice.duration, trimRef.current.end ?? voice.duration);
    if (b <= a || pos >= entry + b) { n.voice = null; return; }
    const src = ctx.createBufferSource();
    src.buffer = voice;
    src.connect(n.voiceGain);
    if (pos < entry + a) src.start(n.startedAt + entry + a, a, b - a);
    else src.start(0, pos - entry, b - (pos - entry));
    n.voice = src;
  }, [voice]);

  const play = useCallback(async (from: number) => {
    if (!beat && !voice) { toast.error("Carregando o áudio, tente de novo em instantes."); return; }
    stop();
    const ctx = getAudioContext();
    if (ctx.state === "suspended") await ctx.resume();
    const beatGain = ctx.createGain(); beatGain.gain.value = gains.current.beat; beatGain.connect(ctx.destination);
    const voiceGain = ctx.createGain(); voiceGain.gain.value = gains.current.voice; voiceGain.connect(ctx.destination);
    const startedAt = ctx.currentTime + 0.05 - from;
    let beatSrc: AudioBufferSourceNode | null = null;
    if (beat && from < beat.duration) {
      beatSrc = ctx.createBufferSource();
      beatSrc.buffer = beat;
      beatSrc.connect(beatGain);
      beatSrc.start(ctx.currentTime + 0.05, from);
    }
    nodes.current = { startedAt, beat: beatSrc, voice: null, beatGain, voiceGain };
    scheduleVoice();
    setPlaying(true);
  }, [beat, voice, stop, scheduleVoice]);

  // Relógio do cursor.
  useEffect(() => {
    if (!playing) return;
    let raf = 0;
    const end = Math.max(beat?.duration ?? 0, entryRef.current + (voice?.duration ?? 0));
    const tick = () => {
      const n = nodes.current;
      if (!n) return;
      const t = getAudioContext().currentTime - n.startedAt;
      setTime(Math.max(0, t));
      if (t > end + 0.2) { stop(); return; }
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [playing, beat, voice, stop]);

  const setEntry = useCallback((seconds: number) => {
    if (entryRef.current === seconds) return;
    entryRef.current = seconds;
    if (nodes.current) scheduleVoice();
  }, [scheduleVoice]);

  const setTrim = useCallback((start: number, end: number | null) => {
    if (trimRef.current.start === start && trimRef.current.end === end) return;
    trimRef.current = { start, end };
    if (nodes.current) scheduleVoice();
  }, [scheduleVoice]);

  const setGains = useCallback((voiceGain: number, beatGain: number) => {
    gains.current = { voice: voiceGain, beat: beatGain };
    const n = nodes.current;
    if (n) { n.voiceGain.gain.value = voiceGain; n.beatGain.gain.value = beatGain; }
  }, []);

  const seek = useCallback((t: number) => {
    setTime(t);
    if (nodes.current) void play(t);
  }, [play]);

  return { beat, voice, playing, time, duration, play, stop, seek, setEntry, setTrim, setGains, ready: Boolean(beat && voice) };
}
