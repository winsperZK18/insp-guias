import { useCallback, useEffect, useRef, useState } from "react";
import { toast } from "sonner";
import { loadAudioBuffer } from "@/lib/audio/buffer-cache";
import { getAudioContext } from "@/lib/audio/decode";
import { renderPreview } from "@/lib/audio/render-preview";
import type { Guide } from "@/lib/types";

export type MixGains = { voiceGain?: number; beatGain?: number };

/** Toca a voz (tratada, se houver) por cima do beat do projeto, no tempo de entrada da guia. */
export function useGuideMix(beatPath: string | null | undefined) {
  const [busy, setBusy] = useState(false);
  const [playing, setPlaying] = useState(false);
  const sourceRef = useRef<AudioBufferSourceNode | null>(null);

  const stop = useCallback(() => {
    sourceRef.current?.stop();
    sourceRef.current = null;
    setPlaying(false);
  }, []);

  useEffect(() => () => sourceRef.current?.stop(), []);

  const toggle = useCallback(
    async (guide: Guide, gains: MixGains = {}, fromSeconds = 0) => {
      if (playing) return stop();
      if (!beatPath) {
        toast.error("Este projeto ainda não tem beat.");
        return;
      }
      setBusy(true);
      try {
        const [beat, voice] = await Promise.all([
          loadAudioBuffer(beatPath),
          loadAudioBuffer(guide.processed_path ?? guide.audio_path),
        ]);
        const mix = await renderPreview(beat, [{ buffer: voice, entrySeconds: Number(guide.entry_seconds) || 0, gain: gains.voiceGain ?? 1 }], { beatGain: gains.beatGain ?? 0.85 });
        const ctx = getAudioContext();
        const source = ctx.createBufferSource();
        source.buffer = mix;
        source.connect(ctx.destination);
        source.onended = () => {
          sourceRef.current = null;
          setPlaying(false);
        };
        source.start(0, Math.max(0, Math.min(fromSeconds, mix.duration - 0.1)));
        sourceRef.current = source;
        setPlaying(true);
      } catch (error) {
        toast.error(error instanceof Error ? error.message : "Não deu para tocar com o beat.");
      } finally {
        setBusy(false);
      }
    },
    [beatPath, playing, stop],
  );

  return { busy, playing, toggle, stop };
}
