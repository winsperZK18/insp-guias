import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { asProject, asProjects, projectsTable } from "@/lib/db";
import { removeAudio } from "@/lib/storage";
import type { Project, ProjectInput } from "@/lib/types";
import { useCurrentGroup } from "@/hooks/use-groups";

export function useProjects() {
  const { group } = useCurrentGroup();
  const groupId = group?.id ?? null;
  return useQuery({
    queryKey: ["projects", groupId],
    enabled: Boolean(groupId),
    queryFn: async (): Promise<Project[]> => {
      const { data, error } = await projectsTable().select("*").eq("group_id", groupId).order("created_at", { ascending: false });
      if (error) throw new Error(error.message);
      return asProjects(data);
    },
  });
}

export function useProject(id: string) {
  return useQuery({
    queryKey: ["project", id],
    queryFn: async (): Promise<Project | null> => {
      const { data, error } = await projectsTable().select("*").eq("id", id).maybeSingle();
      if (error) throw new Error(error.message);
      return data ? asProject(data) : null;
    },
    enabled: Boolean(id),
  });
}

export function useCreateProject() {
  const qc = useQueryClient();
  const { group } = useCurrentGroup();
  return useMutation({
    mutationFn: async (input: ProjectInput) => {
      const { data, error } = await projectsTable().insert({ ...input, group_id: group?.id }).select("*").single();
      if (error) throw new Error(error.message);
      return asProject(data);
    },
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: ["projects"] });
    },
  });
}

export function useUpdateProject() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async ({ id, ...patch }: Partial<Project> & { id: string }) => {
      const { data, error } = await projectsTable().update(patch).eq("id", id).select("*").single();
      if (error) throw new Error(error.message);
      return asProject(data);
    },
    onSuccess: (project) => {
      void qc.invalidateQueries({ queryKey: ["projects"] });
      void qc.invalidateQueries({ queryKey: ["project", project.id] });
    },
  });
}

export function useDeleteProject() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (project: Project) => {
      const { error } = await projectsTable().delete().eq("id", project.id);
      if (error) throw new Error(error.message);
      await removeAudio([project.beat_path, project.preview_path]);
      return project.id;
    },
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: ["projects"] });
    },
  });
}
