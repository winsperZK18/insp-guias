import { useCallback, useState } from "react";
import { toast } from "sonner";
import { useQueryClient } from "@tanstack/react-query";
import { clearAudioBuffer, loadAudioBuffer } from "@/lib/audio/buffer-cache";
import { encodeWav } from "@/lib/audio/wav";
import { processGuide } from "@/lib/dsp/process-guide";
import { guidesTable } from "@/lib/db";
import { uploadAudioAt } from "@/lib/storage";
import type { Guide, Project } from "@/lib/types";

export type ProcessingState = {
  guideId: string | null;
  ratio: number;
  label: string;
};

export function useGuideProcessing(project: Project | null | undefined) {
  const qc = useQueryClient();
  const [state, setState] = useState<ProcessingState>({ guideId: null, ratio: 0, label: "" });

  const process = useCallback(
    async (guide: Guide, options: { strength?: number; offsetSeconds?: number | null } = {}) => {
      if (!project) return;
      setState({ guideId: guide.id, ratio: 0.02, label: "Baixando o áudio" });
      try {
        const guideBuffer = await loadAudioBuffer(guide.audio_path);
        const beatBuffer = project.beat_path ? await loadAudioBuffer(project.beat_path) : null;

        const { buffer, offsetSeconds } = await processGuide(guideBuffer, beatBuffer, {
          strength: options.strength ?? 1.8,
          offsetSeconds: options.offsetSeconds ?? null,
          onProgress: (ratio, label) => setState({ guideId: guide.id, ratio, label }),
        });

        setState({ guideId: guide.id, ratio: 0.97, label: "Salvando a voz tratada" });
        const path = `vozes/${guide.id}.wav`;
        clearAudioBuffer(path);
        await uploadAudioAt(path, encodeWav(buffer), "audio/wav");

        const { error } = await guidesTable()
          .update({
            processed_path: path,
            processed_url: path,
            detected_offset_seconds: offsetSeconds,
          })
          .eq("id", guide.id);
        if (error) throw new Error(error.message);

        await qc.invalidateQueries({ queryKey: ["guides", project.id] });
        await qc.invalidateQueries({ queryKey: ["audio-url", path] });
        toast.success(`Voz de ${guide.artist_name} tratada.`);
      } catch (error) {
        toast.error(error instanceof Error ? error.message : "Não deu para tratar essa guia.");
      } finally {
        setState({ guideId: null, ratio: 0, label: "" });
      }
    },
    [project, qc],
  );

  const processAll = useCallback(
    async (guides: Guide[]) => {
      const pending = guides.filter((guide) => !guide.processed_path);
      if (!pending.length) {
        toast.info("Todas as guias já foram tratadas.");
        return;
      }
      for (const guide of pending) {
        await process(guide);
      }
    },
    [process],
  );

  return { state, process, processAll, isProcessing: state.guideId !== null };
}
