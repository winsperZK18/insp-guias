import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAccess } from "@/hooks/use-access";

/** Quem recebeu liberação para arrastar/ajustar a voz no grupo ativo. */
export function useTimelineEditors() {
  const { groupId } = useAccess();
  return useQuery({
    queryKey: ["timeline-editors", groupId],
    enabled: Boolean(groupId),
    queryFn: async () => {
      const { data, error } = await supabase.from("group_timeline_editors").select("user_id").eq("group_id", groupId!);
      if (error) throw new Error(error.message);
      return new Set((data ?? []).map((row) => row.user_id));
    },
    staleTime: 30_000,
  });
}

/** Produtor e administrador sempre podem; os demais só com liberação. */
export function useCanUseTimeline() {
  const access = useAccess();
  const { data } = useTimelineEditors();
  return access.canManageProjects || Boolean(access.userId && data?.has(access.userId));
}

export function useToggleTimelineAccess() {
  const client = useQueryClient();
  const { groupId } = useAccess();
  return useMutation({
    mutationFn: async ({ userId, allow }: { userId: string; allow: boolean }) => {
      if (!groupId) return;
      const q = supabase.from("group_timeline_editors");
      const { error } = allow ? await q.insert({ group_id: groupId, user_id: userId }) : await q.delete().eq("group_id", groupId).eq("user_id", userId);
      if (error) throw new Error(error.message);
    },
    onSettled: () => client.invalidateQueries({ queryKey: ["timeline-editors"] }),
  });
}
