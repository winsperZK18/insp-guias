import { useCurrentGroup, useRenameGroup } from "@/hooks/use-groups";

export function useGroupName() {
  const { group } = useCurrentGroup();
  return { data: group ? (group.is_personal ? "Meu espaço" : group.name) : null };
}

export function useSaveGroupName() {
  const { group } = useCurrentGroup();
  const rename = useRenameGroup();
  return { ...rename, mutate: (name: string, opts?: Parameters<typeof rename.mutate>[1]) => group && rename.mutate({ id: group.id, name: name || group.name }, opts) };
}
