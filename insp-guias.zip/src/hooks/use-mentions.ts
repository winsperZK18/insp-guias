import { useEffect, useRef } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAccess } from "@/hooks/use-access";
import type { ProjectMessage } from "@/lib/chat-types";

const db = (t: string) => supabase.from(t as never) as any;

export type MentionItem = ProjectMessage & { unread: boolean };

/** Menções a mim nos chats das músicas, com marcação de não lidas por música. */
export function useMentions() {
  const { userId } = useAccess();
  const seen = useRef<Set<string> | null>(null);
  const query = useQuery({
    queryKey: ["mentions", userId],
    enabled: Boolean(userId),
    refetchInterval: 15000,
    queryFn: async (): Promise<MentionItem[]> => {
      const [msgs, reads] = await Promise.all([
        db("project_messages").select("*").contains("mentions", [userId]).neq("author_id", userId).order("created_at", { ascending: false }).limit(30),
        db("chat_reads").select("project_id,last_read_at").eq("user_id", userId),
      ]);
      if (msgs.error) throw new Error(msgs.error.message);
      const readAt = new Map<string, string>((reads.data ?? []).map((r: { project_id: string; last_read_at: string }) => [r.project_id, r.last_read_at]));
      return ((msgs.data ?? []) as ProjectMessage[]).map((m) => {
        const r = readAt.get(m.project_id);
        return { ...m, unread: !r || new Date(m.created_at) > new Date(r) };
      });
    },
  });

  // Aviso na tela quando chega uma nova menção.
  useEffect(() => {
    const items = query.data;
    if (!items) return;
    if (seen.current) {
      for (const m of items) if (m.unread && !seen.current.has(m.id)) toast(`Você foi mencionado: “${m.body.slice(0, 80)}”`);
    }
    seen.current = new Set(items.map((m) => m.id));
  }, [query.data]);

  const unread = (query.data ?? []).filter((m) => m.unread);
  return { items: query.data ?? [], unreadCount: unread.length, unreadByProject: (id: string) => unread.filter((m) => m.project_id === id).length };
}

export function useMarkChatRead(projectId: string) {
  const qc = useQueryClient();
  const { userId } = useAccess();
  return useMutation({
    mutationFn: async () => {
      if (!userId) return;
      await db("chat_reads").upsert({ user_id: userId, project_id: projectId, last_read_at: new Date().toISOString() });
    },
    onSuccess: () => void qc.invalidateQueries({ queryKey: ["mentions"] }),
  });
}
