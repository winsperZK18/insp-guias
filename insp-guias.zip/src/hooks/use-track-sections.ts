import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { asTrackSections, guidesTable, trackSectionsTable } from "@/lib/db";
import type { TrackSection } from "@/lib/types";

export function useTrackSections(projectId: string) {
  return useQuery({
    queryKey: ["track-sections", projectId],
    queryFn: async () => {
      const { data, error } = await trackSectionsTable().select("*").eq("project_id", projectId).order("position");
      if (error) throw new Error(error.message);
      return asTrackSections(data);
    },
    enabled: Boolean(projectId),
  });
}

export type SectionDraft = Omit<TrackSection, "id" | "created_at"> & { id?: string | undefined };

/** Salva os blocos mantendo os ids (guias continuam ligadas ao seu bloco). */
export function useSaveTrackSections(projectId: string) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async ({ blocks, removed }: { blocks: SectionDraft[]; removed: string[] }) => {
      if (removed.length) {
        await guidesTable().update({ section_id: null }).in("section_id", removed);
        const { error } = await trackSectionsTable().delete().in("id", removed);
        if (error) throw new Error(error.message);
      }
      for (const { id, ...row } of blocks) {
        const { error } = id ? await trackSectionsTable().update(row).eq("id", id) : await trackSectionsTable().insert(row);
        if (error) throw new Error(error.message);
      }
    },
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: ["track-sections", projectId] });
      void qc.invalidateQueries({ queryKey: ["guides", projectId] });
    },
  });
}
