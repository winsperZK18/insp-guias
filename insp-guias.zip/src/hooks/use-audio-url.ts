import { useQuery } from "@tanstack/react-query";
import { getAudioUrl } from "@/lib/storage";

/** Resolve uma URL assinada para tocar um áudio guardado no armazenamento. */
export function useAudioUrl(path: string | null | undefined) {
  const { data } = useQuery({
    queryKey: ["audio-url", path],
    queryFn: () => getAudioUrl(path),
    enabled: Boolean(path),
    staleTime: 1000 * 60 * 60,
  });
  return data ?? null;
}
