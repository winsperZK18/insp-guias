import { useEffect, useSyncExternalStore } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import type { AppRole } from "@/lib/types";

export type MyGroup = { id: string; name: string; is_personal: boolean; owner_id: string; role: AppRole };

const KEY = "inspmusic.current-group";
const listeners = new Set<() => void>();
let current: string | null = null;
function read() {
  if (current === null && typeof window !== "undefined") current = window.localStorage.getItem(KEY);
  return current;
}
export function setCurrentGroupId(id: string) {
  if (current === id) return;
  current = id;
  window.localStorage.setItem(KEY, id);
  listeners.forEach((l) => l());
}
function subscribe(l: () => void) { listeners.add(l); return () => listeners.delete(l); }

/** Grupos dos quais eu faço parte (inclui o espaço pessoal). */
export function useMyGroups() {
  return useQuery({
    queryKey: ["my-groups"],
    queryFn: async (): Promise<MyGroup[]> => {
      const { data: auth } = await supabase.auth.getUser();
      if (!auth.user) return [];
      const { data, error } = await supabase.from("group_members").select("role, groups(id, name, is_personal, owner_id)").eq("user_id", auth.user.id);
      if (error) throw new Error(error.message);
      return (data ?? [])
        .filter((row) => row.groups)
        .map((row) => ({ ...(row.groups as any), role: row.role as AppRole }))
        .sort((a, b) => Number(b.is_personal) - Number(a.is_personal) || a.name.localeCompare(b.name));
    },
    staleTime: 60_000,
  });
}

/** Grupo ativo no seletor do topo. */
export function useCurrentGroup() {
  const id = useSyncExternalStore(subscribe, read, () => null);
  const groups = useMyGroups();
  const list = groups.data ?? [];
  const group = list.find((g) => g.id === id) ?? list.find((g) => !g.is_personal) ?? list[0] ?? null;
  useEffect(() => { if (group && group.id !== id) setCurrentGroupId(group.id); }, [group, id]);
  return { group, groups: list, isLoading: groups.isLoading };
}

export function useCreateGroup() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (name: string) => {
      const { data, error } = await supabase.rpc("create_group", { _name: name });
      if (error) throw new Error(error.message);
      return data as string;
    },
    onSuccess: async (id) => { await qc.invalidateQueries({ queryKey: ["my-groups"] }); setCurrentGroupId(id); },
  });
}

export function useRenameGroup() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async ({ id, name }: { id: string; name: string }) => {
      const { error } = await supabase.from("groups").update({ name }).eq("id", id);
      if (error) throw new Error(error.message);
    },
    onSuccess: () => void qc.invalidateQueries({ queryKey: ["my-groups"] }),
  });
}
