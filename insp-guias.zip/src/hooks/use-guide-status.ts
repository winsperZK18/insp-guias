import { useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useUpdateGuide } from "@/hooks/use-guides";
import { useAccess } from "@/hooks/use-access";
import type { Guide } from "@/lib/types";

const db = (t: string) => supabase.from(t as never) as any;

/** Quando o produtor/admin ouve a guia, ela deixa de ser "Novo Take" e vira "Em Teste". */
export function useMarkTesting(projectId: string, canManage: boolean) {
  const update = useUpdateGuide(projectId);
  return useCallback(
    (guides: Guide[]) => {
      if (!canManage) return;
      for (const g of guides) {
        if (g.status === "novo_take") update.mutate({ id: g.id, status: "em_teste" });
      }
    },
    [canManage, update],
  );
}

/** Pedido de regravação: muda o status e avisa o artista no chat da música. */
export function useRequestRedo(projectId: string) {
  const update = useUpdateGuide(projectId);
  const { userId } = useAccess();
  return useCallback(
    async (guide: Guide, reason: string) => {
      update.mutate({ id: guide.id, status: "regravar" });
      const tag = guide.artist_name.trim().replace(/\s+/g, "_");
      await db("project_messages").insert({
        project_id: projectId,
        author_id: userId,
        body: `@${tag}: a guia de ${guide.part_label || "sua parte"} precisa ser regravada (${reason}).`,
        mentions: guide.owner_id ? [guide.owner_id] : [],
        guide_refs: [guide.id],
      });
    },
    [projectId, update, userId],
  );
}
