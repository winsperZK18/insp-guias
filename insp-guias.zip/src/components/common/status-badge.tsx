import { Badge } from "@/components/ui/badge";
import {
  GUIDE_STATUS_LABELS,
  PROJECT_STATUS_LABELS,
  type GuideStatus,
  type ProjectStatus,
} from "@/lib/types";

export function StatusBadge({ status }: { status: ProjectStatus | GuideStatus }) {
  const label =
    PROJECT_STATUS_LABELS[status as ProjectStatus] ?? GUIDE_STATUS_LABELS[status as GuideStatus];
  return <Badge variant={status}>{label}</Badge>;
}