import { useEffect, useRef, useState } from "react";
import { Headphones, Mic, RotateCcw, Square } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { formatDuration } from "@/lib/format";

/** Gravação da guia direto no navegador, com o beat tocando junto. */
export function AudioRecorder({ beatUrl, onRecorded }: { beatUrl: string | null; onRecorded: (file: File | null) => void }) {
  const [recording, setRecording] = useState(false);
  const [seconds, setSeconds] = useState(0);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [playBeat, setPlayBeat] = useState(true);
  const recorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const beatRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => () => {
    if (timerRef.current) clearInterval(timerRef.current);
    recorderRef.current?.stream.getTracks().forEach((track) => track.stop());
    beatRef.current?.pause();
  }, []);

  const start = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: { echoCancellation: false, noiseSuppression: false, autoGainControl: false },
      });
      const recorder = new MediaRecorder(stream);
      chunksRef.current = [];
      recorder.ondataavailable = (event) => { if (event.data.size) chunksRef.current.push(event.data); };
      recorder.onstop = () => {
        const blob = new Blob(chunksRef.current, { type: recorder.mimeType || "audio/webm" });
        const file = new File([blob], `guia-${Date.now()}.webm`, { type: blob.type });
        setPreviewUrl(URL.createObjectURL(blob));
        onRecorded(file);
        stream.getTracks().forEach((track) => track.stop());
      };
      recorder.start();
      recorderRef.current = recorder;
      setPreviewUrl(null);
      onRecorded(null);
      setSeconds(0);
      setRecording(true);
      timerRef.current = setInterval(() => setSeconds((value) => value + 1), 1000);
      if (playBeat && beatUrl && beatRef.current) {
        beatRef.current.currentTime = 0;
        void beatRef.current.play();
      }
    } catch {
      toast.error("Não foi possível usar o microfone. Libere o acesso no navegador.");
    }
  };

  const stop = () => {
    recorderRef.current?.stop();
    if (timerRef.current) clearInterval(timerRef.current);
    beatRef.current?.pause();
    setRecording(false);
  };

  return (
    <div className="space-y-3 border border-border bg-muted/30 p-3">
      <div className="flex gap-2 text-xs text-muted-foreground">
        <Headphones className="mt-0.5 size-4 shrink-0 text-primary" />
        <p>Coloque o fone, aperte gravar e cante junto com o beat. Com fone a voz sai limpa, sem o beat vazando no microfone.</p>
      </div>

      {beatUrl && (
        <label className="flex min-h-11 items-center justify-between gap-3 text-sm">
          <span>Tocar o beat enquanto grava</span>
          <Switch checked={playBeat} onCheckedChange={setPlayBeat} disabled={recording} />
        </label>
      )}
      {beatUrl && <audio ref={beatRef} src={beatUrl} preload="auto" className="hidden" />}

      <div className="flex items-center gap-3">
        {!recording ? (
          <Button type="button" variant="hero" className="h-12 flex-1" onClick={start}>
            <Mic /> {previewUrl ? "Gravar de novo" : "Gravar agora"}
          </Button>
        ) : (
          <Button type="button" variant="destructive" className="h-12 flex-1" onClick={stop}>
            <Square /> Parar ({formatDuration(seconds)})
          </Button>
        )}
        {previewUrl && !recording && (
          <Button type="button" variant="ghost" className="h-12" onClick={() => { setPreviewUrl(null); onRecorded(null); }} aria-label="Descartar gravação">
            <RotateCcw />
          </Button>
        )}
      </div>

      {recording && <p className="text-xs text-destructive">Gravando... {formatDuration(seconds)}</p>}
      {previewUrl && !recording && (
        <div className="space-y-1">
          <p className="text-xs text-success">Gravação pronta. Ouça antes de enviar.</p>
          <audio controls src={previewUrl} className="w-full" />
        </div>
      )}
    </div>
  );
}
