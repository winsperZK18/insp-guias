import { useRef, useState } from "react";
import { FileAudio, Upload, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { formatFileSize } from "@/lib/format";
import { validateAudioFile } from "@/lib/storage";

export function AudioFileField({
  value,
  onChange,
  label = "Arquivo de áudio",
}: {
  value: File | null;
  onChange: (file: File | null) => void;
  label?: string;
}) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [error, setError] = useState<string | null>(null);

  const choose = (file: File | null) => {
    if (!file) return;
    const message = validateAudioFile(file);
    setError(message);
    if (!message) onChange(file);
  };

  return (
    <div className="space-y-2">
      <span className="text-sm font-medium">{label}</span>
      <input
        ref={inputRef}
        type="file"
        accept=".mp3,.wav,.m4a,.aac,.ogg,.webm,audio/mpeg,audio/wav,audio/x-wav,audio/mp4,audio/aac,audio/ogg"
        className="sr-only"
        onChange={(event) => choose(event.target.files?.[0] ?? null)}
      />
      {value ? (
        <div className="flex items-center gap-3 rounded-md border border-border bg-muted/40 p-3">
          <FileAudio className="size-5 text-primary" />
          <div className="min-w-0 flex-1">
            <p className="truncate text-sm font-medium">{value.name}</p>
            <p className="text-xs text-muted-foreground">{formatFileSize(value.size)}</p>
          </div>
          <Button type="button" size="icon" variant="ghost" aria-label="Remover arquivo" onClick={() => onChange(null)}><X /></Button>
        </div>
      ) : (
        <Button type="button" variant="outline" className="h-20 w-full border-dashed" onClick={() => inputRef.current?.click()}>
          <Upload /> Escolher MP3 ou áudio
        </Button>
      )}
      {error && <p className="text-xs text-destructive">{error}</p>}
    </div>
  );
}