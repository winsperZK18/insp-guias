import { Progress } from "@/components/ui/progress";

export function ProgressField({ value, label }: { value: number; label: string }) {
  return (
    <div className="space-y-2" aria-live="polite">
      <div className="flex justify-between text-xs text-muted-foreground">
        <span>{label}</span><span>{Math.round(value * 100)}%</span>
      </div>
      <Progress value={value * 100} className="h-1.5" />
    </div>
  );
}