import { useEffect, useRef } from "react";
import { computePeaks } from "@/lib/audio/peaks";

export function WaveformCanvas({ buffer, className = "" }: { buffer: AudioBuffer | null; className?: string }) {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    const width = Math.max(1, canvas.clientWidth * devicePixelRatio);
    const height = Math.max(1, canvas.clientHeight * devicePixelRatio);
    canvas.width = width; canvas.height = height;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    ctx.clearRect(0, 0, width, height);
    const color = getComputedStyle(canvas).color;
    ctx.strokeStyle = color;
    ctx.lineWidth = Math.max(1, devicePixelRatio);
    if (!buffer) return;
    const peaks = computePeaks(buffer, Math.floor(width / devicePixelRatio));
    ctx.beginPath();
    const mid = height / 2;
    for (let x = 0; x < peaks.length / 2; x++) {
      const min = peaks[x * 2] ?? 0; const max = peaks[x * 2 + 1] ?? 0;
      ctx.moveTo(x * devicePixelRatio, mid + min * mid * 0.9);
      ctx.lineTo(x * devicePixelRatio, mid + max * mid * 0.9);
    }
    ctx.stroke();
  }, [buffer]);
  return <canvas ref={ref} className={`block h-full w-full text-primary ${className}`} aria-label="Forma de onda do beat" />;
}