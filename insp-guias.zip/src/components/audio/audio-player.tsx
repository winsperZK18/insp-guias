import { useEffect, useRef, useState } from "react";
import { Pause, Play } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { formatDuration } from "@/lib/format";

let activeAudio: HTMLAudioElement | null = null;

export function AudioPlayer({ src, compact = false }: { src: string | null | undefined; compact?: boolean }) {
  const ref = useRef<HTMLAudioElement>(null);
  const [playing, setPlaying] = useState(false);
  const [time, setTime] = useState(0);
  const [duration, setDuration] = useState(0);

  useEffect(() => () => ref.current?.pause(), []);

  if (!src) return <span className="text-xs text-muted-foreground">Áudio indisponível</span>;

  const toggle = async () => {
    const audio = ref.current;
    if (!audio) return;
    if (audio.paused) {
      if (activeAudio && activeAudio !== audio) activeAudio.pause();
      activeAudio = audio;
      await audio.play();
    } else audio.pause();
  };

  return (
    <div className={`flex items-center gap-2 ${compact ? "min-w-44" : "w-full"}`}>
      <audio ref={ref} src={src} preload="metadata" onPlay={() => setPlaying(true)} onPause={() => setPlaying(false)} onEnded={() => setPlaying(false)} onTimeUpdate={(e) => setTime(e.currentTarget.currentTime)} onLoadedMetadata={(e) => setDuration(e.currentTarget.duration)} />
      <Button size="icon" variant="secondary" className="size-11 shrink-0 sm:size-9" onClick={toggle} aria-label={playing ? "Pausar" : "Tocar"}>{playing ? <Pause /> : <Play />}</Button>
      <Slider value={[time]} max={duration || 1} step={0.1} onValueChange={(v) => { if (ref.current) ref.current.currentTime = v[0] ?? 0; }} aria-label="Posição do áudio" />
      {!compact && <span className="w-20 text-right font-mono text-[11px] text-muted-foreground">{formatDuration(time)} / {formatDuration(duration)}</span>}
    </div>
  );
}