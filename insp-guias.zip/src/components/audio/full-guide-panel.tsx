import { useEffect, useMemo, useRef, useState } from "react";
import { Download, Magnet, Pause, Play, Save, Volume2, VolumeX } from "lucide-react";
import { toast } from "sonner";
import { UndoButtons } from "@/components/audio/live-sync-panel";
import { useUndo } from "@/hooks/use-undo";
import { WaveformCanvas } from "@/components/audio/waveform-canvas";
import { ProgressField } from "@/components/common/progress-field";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { useMultiLiveMix, type LiveLayer } from "@/hooks/use-multi-live-mix";
import { exportMixMp3 } from "@/lib/audio/export-mix";
import { barLabel, secondsPerBar, secondsPerBeat, snapToBar } from "@/lib/bars";
import { formatTimelineTime } from "@/lib/format";
import { cn } from "@/lib/utils";
import type { Guide } from "@/lib/types";

type Props = {
  guides: Guide[];
  beatPath: string | null | undefined;
  bpm: number | null;
  title: string;
  canAdjust: boolean;
  userId?: string | null;
  onSave: (updates: { id: string; entry_seconds: number; trim_start_seconds: number; trim_end_seconds: number | null }[]) => void;
};

type DragMode = "move" | "trimStart" | "trimEnd";
const round = (n: number) => Math.max(0, Math.round(n * 1000) / 1000);
const fromGuide = (g: Guide): LiveLayer => ({ entry: Number(g.entry_seconds) || 0, trimStart: Number(g.trim_start_seconds) || 0, trimEnd: g.trim_end_seconds != null ? Number(g.trim_end_seconds) : null, gain: 1, muted: false });

/** "Ouvir toda a guia com o beat": todas as vozes em faixas, ajuste fino de cada uma ao vivo e MP3 da guia completa. */
export function FullGuidePanel({ guides, beatPath, bpm, title, canAdjust, userId = null, onSave }: Props) {
  const voices = useMemo(() => guides.map((g) => ({ id: g.id, path: g.processed_path ?? g.audio_path })), [guides]);
  const live = useMultiLiveMix(beatPath, voices);
  const [layers, setLayers] = useState<Record<string, LiveLayer>>(() => Object.fromEntries(guides.map((g) => [g.id, fromGuide(g)])));
  const [selected, setSelected] = useState(guides[0]?.id ?? "");
  const [beatGain, setBeatGain] = useState(0.85);
  const [zoom, setZoom] = useState(16);
  const [idle, setIdle] = useState(0);
  const [exporting, setExporting] = useState<{ ratio: number; label: string } | null>(null);
  const can = (id: string) => { const g = guides.find((x) => x.id === id); return canAdjust || Boolean(g && userId && g.owner_id === userId && g.status !== "fechada"); };
  const drag = useRef<{ id: string; mode: DragMode; x: number; l: LiveLayer; b: number } | null>(null);
  const scroller = useRef<HTMLDivElement>(null);

  // Guias novas entram no painel sem perder ajustes não salvos das outras.
  useEffect(() => {
    setLayers((prev) => Object.fromEntries(guides.map((g) => [g.id, prev[g.id] ?? fromGuide(g)])));
  }, [guides]);
  useEffect(() => { for (const [id, l] of Object.entries(layers)) live.setLayer(id, l); }, [layers, live.setLayer]);
  useEffect(() => { live.setBeatGain(beatGain); }, [beatGain, live.setBeatGain]);

  const positions = Object.fromEntries(Object.entries(layers).map(([id, l]) => [id, { entry: l.entry, trimStart: l.trimStart, trimEnd: l.trimEnd }]));
  const history = useUndo(positions, (v) => setLayers((prev) => Object.fromEntries(Object.entries(prev).map(([id, l]) => [id, v[id] ? { ...l, ...v[id] } : l]))));
  const cursor = live.playing ? live.time : idle;
  useEffect(() => {
    const el = scroller.current;
    if (!el || !live.playing) return;
    const x = cursor * zoom;
    if (x < el.scrollLeft || x > el.scrollLeft + el.clientWidth - 40) el.scrollLeft = Math.max(0, x - 40);
  }, [cursor, zoom, live.playing]);

  const dur = (id: string, g?: Guide) => live.buffers[id]?.duration ?? (Number(g?.duration_seconds) || 10);
  const total = Math.max(live.beat?.duration ?? 60, ...guides.map((g) => (layers[g.id]?.entry ?? 0) + dur(g.id, g) + 2));
  const markers = Array.from({ length: Math.floor(total / 5) + 1 }, (_, i) => i * 5);
  const beat = secondsPerBeat(bpm);
  const bar = secondsPerBar(bpm);
  const patch = (id: string, p: Partial<LiveLayer>) => setLayers((prev) => (prev[id] ? { ...prev, [id]: { ...prev[id]!, ...p } } : prev));
  const sel = layers[selected];
  const shift = (d: number) => sel && patch(selected, { entry: round(sel.entry + d) });

  const changed = guides.filter((g) => {
    const l = layers[g.id]; const o = fromGuide(g);
    return l && (l.entry !== o.entry || l.trimStart !== o.trimStart || l.trimEnd !== o.trimEnd);
  });

  const seek = (e: React.MouseEvent<HTMLDivElement>) => {
    const t = Math.max(0, (e.clientX - e.currentTarget.getBoundingClientRect().left) / zoom);
    setIdle(t);
    if (live.playing) live.seek(t);
  };
  const startDrag = (id: string, mode: DragMode) => (e: React.PointerEvent) => {
    setSelected(id);
    const l = layers[id];
    if (!can(id) || !l) return;
    e.stopPropagation();
    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
    drag.current = { id, mode, x: e.clientX, l, b: Math.min(dur(id), l.trimEnd ?? dur(id)) };
  };
  const onMove = (e: React.PointerEvent) => {
    const d = drag.current;
    if (!d) return;
    const dt = (e.clientX - d.x) / zoom;
    const full = dur(d.id);
    if (d.mode === "move") patch(d.id, { entry: round(d.l.entry + dt) });
    if (d.mode === "trimStart") patch(d.id, { trimStart: round(Math.min(d.b - 0.1, Math.max(0, d.l.trimStart + dt))) });
    if (d.mode === "trimEnd") { const v = round(Math.max(d.l.trimStart + 0.1, Math.min(full, d.b + dt))); patch(d.id, { trimEnd: v >= full - 0.01 ? null : v }); }
  };
  const endDrag = () => { drag.current = null; };

  const download = async () => {
    const active = guides.filter((g) => !layers[g.id]?.muted).map((g) => { const l = layers[g.id]!; return { ...g, entry_seconds: l.entry, trim_start_seconds: l.trimStart, trim_end_seconds: l.trimEnd }; });
    if (!active.length) { toast.error("Ative pelo menos uma voz."); return; }
    try {
      await exportMixMp3(`${title} - guia completa`, beatPath ?? null, active, { beatGain, onProgress: (ratio, label) => setExporting({ ratio, label }) });
      toast.success("Guia completa baixada.");
    } catch (error) { toast.error(error instanceof Error ? error.message : "Não deu para gerar o MP3."); }
    finally { setExporting(null); }
  };

  return (
    <div className="space-y-3 border border-primary/40 bg-background/60 p-3">
      <div className="flex items-center gap-3">
        <Button size="icon" variant="hero" className="size-12 shrink-0" onClick={() => (live.playing ? live.stop() : void live.play(cursor))} aria-label={live.playing ? "Parar" : "Tocar"}>
          {live.playing ? <Pause /> : <Play />}
        </Button>
        <div className="min-w-0">
          <p className="font-mono text-2xl leading-none tabular-nums">{formatTimelineTime(cursor)}</p>
          <p className="text-[11px] uppercase text-muted-foreground">{bpm ? barLabel(cursor, bpm) : "defina o BPM para ver compassos"}</p>
        </div>
        <div className="ml-auto"><UndoButtons h={history} /></div>
      </div>

      <div ref={scroller} className="overflow-x-auto border border-border">
        <div className="relative select-none" style={{ width: total * zoom }} onPointerMove={onMove} onPointerUp={endDrag} onPointerCancel={endDrag}>
          <div className="relative h-6 cursor-pointer border-b border-border bg-muted/70" onClick={seek}>{markers.map((s) => <span key={s} className="absolute top-1 text-[10px] text-muted-foreground" style={{ left: s * zoom }}>{formatTimelineTime(s)}</span>)}</div>
          <div className="relative h-14 cursor-pointer bg-muted/30" onClick={seek}><span className="absolute left-1 top-0.5 z-10 text-[10px] uppercase text-muted-foreground">Beat</span><WaveformCanvas buffer={live.beat} className="opacity-70" /></div>
          {guides.map((g) => {
            const l = layers[g.id];
            if (!l) return null;
            const full = dur(g.id, g);
            const b = Math.min(full, l.trimEnd ?? full);
            const on = g.id === selected;
            return (
              <div key={g.id} className={cn("relative h-16 border-t border-border", on ? "bg-primary/5" : "bg-muted/10", l.muted && "opacity-40")} onClick={seek}>
                <div
                  className={cn("absolute inset-y-1 overflow-hidden border-2", on ? "border-primary bg-primary/25" : "border-primary/40 bg-primary/10", can(g.id) && "cursor-grab touch-none active:cursor-grabbing")}
                  style={{ left: (l.entry + l.trimStart) * zoom, width: Math.max(8, (b - l.trimStart) * zoom) }}
                  onPointerDown={startDrag(g.id, "move")}
                  onClick={(e) => { e.stopPropagation(); setSelected(g.id); }}
                >
                  <div className="absolute inset-y-0" style={{ left: -l.trimStart * zoom, width: full * zoom }}><WaveformCanvas buffer={live.buffers[g.id] ?? null} /></div>
                  <span className="absolute left-3 top-0.5 z-10 truncate text-[10px] font-semibold uppercase text-primary">{g.artist_name}{g.part_label ? ` · ${g.part_label}` : ""}</span>
                  {can(g.id) && on && <>
                    <div className="absolute inset-y-0 left-0 z-20 w-3 cursor-ew-resize touch-none bg-primary/70" onPointerDown={startDrag(g.id, "trimStart")} aria-label="Cortar início" />
                    <div className="absolute inset-y-0 right-0 z-20 w-3 cursor-ew-resize touch-none bg-primary/70" onPointerDown={startDrag(g.id, "trimEnd")} aria-label="Cortar fim" />
                  </>}
                </div>
              </div>
            );
          })}
          <div className="pointer-events-none absolute inset-y-0 z-30 w-0.5 bg-foreground" style={{ left: cursor * zoom }} />
        </div>
      </div>

      <div className="flex flex-wrap gap-2">
        {guides.map((g) => {
          const l = layers[g.id];
          return (
            <div key={g.id} className={cn("flex items-center border", g.id === selected ? "border-primary" : "border-border")}>
              <button type="button" className="h-10 px-3 text-sm font-semibold" onClick={() => setSelected(g.id)}>{g.artist_name}</button>
              <button type="button" className="h-10 px-2 text-muted-foreground" onClick={() => l && patch(g.id, { muted: !l.muted })} aria-label={l?.muted ? "Ativar voz" : "Silenciar voz"}>{l?.muted ? <VolumeX className="size-4" /> : <Volume2 className="size-4" />}</button>
            </div>
          );
        })}
      </div>

      {sel && (
        <div className="space-y-2 border border-border p-2">
          <p className="text-xs text-muted-foreground">Ajustando <strong className="text-foreground">{guides.find((g) => g.id === selected)?.artist_name}</strong> · entra em <span className="font-mono text-primary">{formatTimelineTime(sel.entry + sel.trimStart)}</span>{can(selected) ? " — toque numa voz para escolher, arraste ou use os botões." : ""}</p>
          {can(selected) && (
            <div className="grid grid-cols-3 gap-2 sm:grid-cols-7">
              <Button variant="outline" className="h-11 px-0 text-xs" onClick={() => shift(-bar)}>−1 comp.</Button>
              <Button variant="outline" className="h-11 px-0 text-xs" onClick={() => shift(-beat)}>−1 tempo</Button>
              <Button variant="outline" className="h-11 px-0 text-xs" onClick={() => shift(-0.01)}>−0,01s</Button>
              <Button variant="outline" className="h-11 px-0 text-xs" onClick={() => patch(selected, { entry: snapToBar(sel.entry, bpm) })}><Magnet className="size-4" /> Colar</Button>
              <Button variant="outline" className="h-11 px-0 text-xs" onClick={() => shift(0.01)}>+0,01s</Button>
              <Button variant="outline" className="h-11 px-0 text-xs" onClick={() => shift(beat)}>+1 tempo</Button>
              <Button variant="outline" className="h-11 px-0 text-xs" onClick={() => shift(bar)}>+1 comp.</Button>
            </div>
          )}
          <label className="block text-xs text-muted-foreground">Volume desta voz · {Math.round(sel.gain * 100)}%<Slider min={0} max={2} step={0.05} value={[sel.gain]} onValueChange={(v) => patch(selected, { gain: v[0] ?? 1 })} /></label>
        </div>
      )}

      <div className="grid gap-3 sm:grid-cols-2">
        <label className="block text-xs text-muted-foreground">Beat · {Math.round(beatGain * 100)}%<Slider min={0} max={1.5} step={0.05} value={[beatGain]} onValueChange={(v) => setBeatGain(v[0] ?? 0.85)} /></label>
        <label className="block text-xs text-muted-foreground">Zoom<Slider min={6} max={200} step={2} value={[zoom]} onValueChange={(v) => setZoom(v[0] ?? 16)} /></label>
      </div>

      {exporting && <ProgressField value={exporting.ratio} label={exporting.label} />}

      <div className="flex flex-wrap justify-end gap-2">
        <Button variant="outline" className="h-11" disabled={Boolean(exporting)} onClick={download}><Download /> Baixar GUIA COMPLETA (MP3)</Button>
        {changed.some((g) => can(g.id)) && <Button variant="hero" className="h-11" disabled={!changed.length} onClick={() => onSave(changed.filter((g) => can(g.id)).map((g) => { const l = layers[g.id]!; return { id: g.id, entry_seconds: l.entry, trim_start_seconds: l.trimStart, trim_end_seconds: l.trimEnd }; }))}><Save /> {changed.length ? `Salvar ajustes (${changed.length})` : "Salvo"}</Button>}
      </div>
    </div>
  );
}
