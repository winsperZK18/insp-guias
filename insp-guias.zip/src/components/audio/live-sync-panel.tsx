import { useEffect, useRef, useState } from "react";
import { Download, Magnet, Pause, Play, Redo2, Save, Undo2, Wand2 } from "lucide-react";
import { useUndo } from "@/hooks/use-undo";
import { toast } from "sonner";
import { useServerFn } from "@tanstack/react-start";
import { WaveformCanvas } from "@/components/audio/waveform-canvas";
import { ProgressField } from "@/components/common/progress-field";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { useLiveMix } from "@/hooks/use-live-mix";
import { exportMixMp3 } from "@/lib/audio/export-mix";
import { barLabel, secondsPerBar, secondsPerBeat, snapToBar } from "@/lib/bars";
import { extractTimingFeatures } from "@/lib/dsp/timing-features";
import { formatTimelineTime } from "@/lib/format";
import { analyzeGuideSync } from "@/lib/sync-analysis.functions";
import type { SyncReport } from "@/lib/sync-analysis.server";
import type { Guide } from "@/lib/types";

export type SyncSave = { entry_seconds: number; trim_start_seconds: number; trim_end_seconds: number | null };

type Props = {
  guide: Guide;
  voicePath: string;
  beatPath: string | null | undefined;
  bpm: number | null;
  title: string;
  /** Quando falso, o painel só toca (sem arrastar, cortar nem salvar). */
  canAdjust: boolean;
  onSave: (patch: SyncSave) => void;
};

type DragMode = "move" | "trimStart" | "trimEnd";
const round = (n: number) => Math.max(0, Math.round(n * 1000) / 1000);

/** Editor único "Ouvir com o beat": ondas, cursor, arrastar/cortar a voz ao vivo, volumes, zoom, IA e MP3. */
export function LiveSyncPanel({ guide, voicePath, beatPath, bpm, title, canAdjust, onSave }: Props) {
  const live = useLiveMix(beatPath, voicePath);
  const [entry, setEntry] = useState(Number(guide.entry_seconds) || 0);
  const [trimStart, setTrimStart] = useState(Number(guide.trim_start_seconds) || 0);
  const [trimEnd, setTrimEnd] = useState<number | null>(guide.trim_end_seconds != null ? Number(guide.trim_end_seconds) : null);
  const [voiceGain, setVoiceGain] = useState(1);
  const [beatGain, setBeatGain] = useState(0.85);
  const [zoom, setZoom] = useState(24);
  const [idle, setIdle] = useState(Math.max(0, (Number(guide.entry_seconds) || 0) - 2));
  const [report, setReport] = useState<SyncReport | null>(null);
  const [analyzing, setAnalyzing] = useState(false);
  const [exporting, setExporting] = useState<{ ratio: number; label: string } | null>(null);
  const drag = useRef<{ mode: DragMode; x: number; entry: number; a: number; b: number } | null>(null);
  const scroller = useRef<HTMLDivElement>(null);
  const analyze = useServerFn(analyzeGuideSync);

  useEffect(() => {
    setEntry(Number(guide.entry_seconds) || 0);
    setTrimStart(Number(guide.trim_start_seconds) || 0);
    setTrimEnd(guide.trim_end_seconds != null ? Number(guide.trim_end_seconds) : null);
  }, [guide.entry_seconds, guide.trim_start_seconds, guide.trim_end_seconds]);

  useEffect(() => { live.setEntry(entry); }, [entry, live.setEntry]);
  useEffect(() => { live.setTrim(trimStart, trimEnd); }, [trimStart, trimEnd, live.setTrim]);
  useEffect(() => { live.setGains(voiceGain, beatGain); }, [voiceGain, beatGain, live.setGains]);

  const cursor = live.playing ? live.time : idle;
  // Segue o cursor enquanto toca.
  useEffect(() => {
    const el = scroller.current;
    if (!el || !live.playing) return;
    const x = cursor * zoom;
    if (x < el.scrollLeft || x > el.scrollLeft + el.clientWidth - 40) el.scrollLeft = Math.max(0, x - 40);
  }, [cursor, zoom, live.playing]);

  const voiceDur = live.voice?.duration ?? (Number(guide.duration_seconds) || 10);
  const b = Math.min(voiceDur, trimEnd ?? voiceDur);
  const total = Math.max(live.beat?.duration ?? 60, entry + voiceDur + 2);
  const width = total * zoom;
  const markers = Array.from({ length: Math.floor(total / 5) + 1 }, (_, i) => i * 5);
  const beat = secondsPerBeat(bpm);
  const bar = secondsPerBar(bpm);
  const dirty = entry !== (Number(guide.entry_seconds) || 0) || trimStart !== (Number(guide.trim_start_seconds) || 0) || trimEnd !== (guide.trim_end_seconds != null ? Number(guide.trim_end_seconds) : null);
  const history = useUndo({ entry, trimStart, trimEnd }, (v) => { setEntry(v.entry); setTrimStart(v.trimStart); setTrimEnd(v.trimEnd); });
  const shift = (d: number) => setEntry((v) => round(v + d));

  const seek = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const t = Math.max(0, (e.clientX - rect.left) / zoom);
    setIdle(t);
    if (live.playing) live.seek(t);
  };
  const startDrag = (mode: DragMode) => (e: React.PointerEvent) => {
    if (!canAdjust) return;
    e.stopPropagation();
    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
    drag.current = { mode, x: e.clientX, entry, a: trimStart, b };
  };
  const onMove = (e: React.PointerEvent) => {
    const d = drag.current;
    if (!d) return;
    const dt = (e.clientX - d.x) / zoom;
    if (d.mode === "move") setEntry(round(d.entry + dt));
    if (d.mode === "trimStart") setTrimStart(round(Math.min(d.b - 0.1, Math.max(0, d.a + dt))));
    if (d.mode === "trimEnd") { const v = round(Math.max(d.a + 0.1, Math.min(voiceDur, d.b + dt))); setTrimEnd(v >= voiceDur - 0.01 ? null : v); }
  };
  const endDrag = () => { drag.current = null; };

  const runAnalysis = async () => {
    if (!live.beat || !live.voice) { toast.error("Aguarde o beat e a voz carregarem."); return; }
    setAnalyzing(true);
    try { setReport(await analyze({ data: extractTimingFeatures(live.beat, live.voice, entry, bpm) })); }
    catch (error) { toast.error(error instanceof Error ? error.message : "A análise falhou."); }
    finally { setAnalyzing(false); }
  };
  const download = async () => {
    try {
      await exportMixMp3(title, beatPath ?? null, [{ ...guide, entry_seconds: entry, trim_start_seconds: trimStart, trim_end_seconds: trimEnd }], { voiceGain, beatGain, onProgress: (ratio, label) => setExporting({ ratio, label }) });
    } catch (error) { toast.error(error instanceof Error ? error.message : "Não deu para gerar o MP3."); }
    finally { setExporting(null); }
  };

  return (
    <div className="space-y-3 border border-primary/40 bg-background/60 p-3">
      <div className="flex items-center gap-3">
        <UndoButtons h={history} />
        <Button size="icon" variant="hero" className="size-12 shrink-0" disabled={!live.beat && !live.voice} onClick={() => (live.playing ? live.stop() : void live.play(cursor))} aria-label={live.playing ? "Parar" : "Tocar"}>
          {live.playing ? <Pause /> : <Play />}
        </Button>
        <div className="min-w-0">
          <p className="font-mono text-2xl leading-none tabular-nums">{formatTimelineTime(cursor)}</p>
          <p className="text-[11px] uppercase text-muted-foreground">{bpm ? barLabel(cursor, bpm) : "defina o BPM para ver compassos"}</p>
        </div>
        <p className="ml-auto text-right text-[11px] uppercase text-muted-foreground">Voz entra em<br /><span className="font-mono text-sm text-primary">{formatTimelineTime(entry + trimStart)}</span></p>
      </div>

      <div ref={scroller} className="overflow-x-auto border border-border">
        <div className="relative select-none" style={{ width }} onPointerMove={onMove} onPointerUp={endDrag} onPointerCancel={endDrag}>
          <div className="relative h-6 cursor-pointer border-b border-border bg-muted/70" onClick={seek}>{markers.map((s) => <span key={s} className="absolute top-1 text-[10px] text-muted-foreground" style={{ left: s * zoom }}>{formatTimelineTime(s)}</span>)}</div>
          <div className="relative h-16 cursor-pointer bg-muted/30" onClick={seek}><span className="absolute left-1 top-0.5 z-10 text-[10px] uppercase text-muted-foreground">Beat</span><WaveformCanvas buffer={live.beat} className="opacity-70" /></div>
          <div className="relative h-20 border-t border-border bg-muted/10" onClick={seek}>
            {report?.issues.map((issue, i) => <div key={i} title={issue.note} className="absolute top-0 h-full bg-destructive/20" style={{ left: issue.start * zoom, width: Math.max(4, (issue.end - issue.start) * zoom) }} />)}
            {/* Arquivo inteiro (apagado) + trecho ativo */}
            <div className="absolute inset-y-1 overflow-hidden border border-dashed border-border opacity-30" style={{ left: entry * zoom, width: voiceDur * zoom }}><WaveformCanvas buffer={live.voice} /></div>
            <div
              className={`absolute inset-y-1 overflow-hidden border-2 border-primary bg-primary/20 ${canAdjust ? "cursor-grab touch-none active:cursor-grabbing" : ""}`}
              style={{ left: (entry + trimStart) * zoom, width: Math.max(8, (b - trimStart) * zoom) }}
              onPointerDown={startDrag("move")}
              onClick={(e) => e.stopPropagation()}
            >
              <div className="absolute inset-y-0" style={{ left: -trimStart * zoom, width: voiceDur * zoom }}><WaveformCanvas buffer={live.voice} /></div>
              <span className="absolute left-3 top-0.5 z-10 text-[10px] font-semibold uppercase text-primary">Voz</span>
              {canAdjust && <>
                <div className="absolute inset-y-0 left-0 z-20 w-3 cursor-ew-resize touch-none bg-primary/70" onPointerDown={startDrag("trimStart")} aria-label="Cortar início" />
                <div className="absolute inset-y-0 right-0 z-20 w-3 cursor-ew-resize touch-none bg-primary/70" onPointerDown={startDrag("trimEnd")} aria-label="Cortar fim" />
              </>}
            </div>
          </div>
          <div className="pointer-events-none absolute inset-y-0 z-30 w-0.5 bg-foreground" style={{ left: cursor * zoom }} />
        </div>
      </div>

      {canAdjust && (
        <div className="space-y-2">
          <p className="text-xs text-muted-foreground">Dê play e arraste a voz, ou puxe as bordas amarelas para cortar o silêncio do começo e do fim — soa na hora.</p>
          <div className="grid grid-cols-3 gap-2 sm:grid-cols-7">
            <Button variant="outline" className="h-11 px-0 text-xs" onClick={() => shift(-bar)}>−1 comp.</Button>
            <Button variant="outline" className="h-11 px-0 text-xs" onClick={() => shift(-beat)}>−1 tempo</Button>
            <Button variant="outline" className="h-11 px-0 text-xs" onClick={() => shift(-0.01)}>−0,01s</Button>
            <Button variant="outline" className="h-11 px-0 text-xs" onClick={() => setEntry(snapToBar(entry, bpm))}><Magnet className="size-4" /> Colar</Button>
            <Button variant="outline" className="h-11 px-0 text-xs" onClick={() => shift(0.01)}>+0,01s</Button>
            <Button variant="outline" className="h-11 px-0 text-xs" onClick={() => shift(beat)}>+1 tempo</Button>
            <Button variant="outline" className="h-11 px-0 text-xs" onClick={() => shift(bar)}>+1 comp.</Button>
          </div>
          {(trimStart > 0 || trimEnd != null) && <Button variant="ghost" size="sm" className="h-9" onClick={() => { setTrimStart(0); setTrimEnd(null); }}>Desfazer corte</Button>}
        </div>
      )}

      <div className="grid gap-3 sm:grid-cols-3">
        <label className="block text-xs text-muted-foreground">Voz · {Math.round(voiceGain * 100)}%<Slider min={0} max={2} step={0.05} value={[voiceGain]} onValueChange={(v) => setVoiceGain(v[0] ?? 1)} /></label>
        <label className="block text-xs text-muted-foreground">Beat · {Math.round(beatGain * 100)}%<Slider min={0} max={1.5} step={0.05} value={[beatGain]} onValueChange={(v) => setBeatGain(v[0] ?? 0.85)} /></label>
        <label className="block text-xs text-muted-foreground">Zoom<Slider min={8} max={200} step={4} value={[zoom]} onValueChange={(v) => setZoom(v[0] ?? 24)} /></label>
      </div>

      {report && (
        <div className="space-y-2 border border-primary/40 bg-primary/5 p-3 text-sm">
          <p className="text-xs uppercase text-primary">Análise da IA (estimativa)</p>
          <p>{report.summary}</p>
          {report.explanation && <p className="text-muted-foreground">{report.explanation}</p>}
          {canAdjust && report.suggestedEntryShift !== 0 && (
            <Button size="sm" variant="secondary" className="h-10" onClick={() => shift(report.suggestedEntryShift)}>
              Aplicar entrada recomendada ({report.suggestedEntryShift > 0 ? "+" : ""}{report.suggestedEntryShift.toFixed(2)}s)
            </Button>
          )}
          {report.issues.length > 0 && <ul className="space-y-1">{report.issues.map((issue, i) => <li key={i}><button type="button" className="text-left hover:text-primary" onClick={() => void live.play(Math.max(0, issue.start - 1))}><strong>{formatTimelineTime(issue.start)}–{formatTimelineTime(issue.end)}</strong> · {issue.offsetMs > 0 ? "atrasada" : "adiantada"} {Math.abs(issue.offsetMs)} ms — {issue.note}</button></li>)}</ul>}
        </div>
      )}

      {exporting && <ProgressField value={exporting.ratio} label={exporting.label} />}

      <div className="flex flex-wrap justify-end gap-2">
        <Button variant="outline" className="h-11" disabled={analyzing || !live.ready} onClick={runAnalysis}><Wand2 /> {analyzing ? "Analisando..." : "Analisar com IA"}</Button>
        <Button variant="outline" className="h-11" disabled={Boolean(exporting)} onClick={download}><Download /> Baixar MP3</Button>
        {canAdjust && <Button variant="hero" className="h-11" disabled={!dirty} onClick={() => onSave({ entry_seconds: entry, trim_start_seconds: trimStart, trim_end_seconds: trimEnd })}><Save /> {dirty ? "Salvar ajuste" : "Salvo"}</Button>}
      </div>
    </div>
  );
}

export function UndoButtons({ h }: { h: { undo: () => void; redo: () => void; canUndo: boolean; canRedo: boolean } }) {
  return (
    <div className="order-last flex gap-1">
      <Button size="icon" variant="outline" className="size-11" disabled={!h.canUndo} onClick={h.undo} aria-label="Desfazer" title="Desfazer (Ctrl+Z)"><Undo2 /></Button>
      <Button size="icon" variant="outline" className="size-11" disabled={!h.canRedo} onClick={h.redo} aria-label="Refazer" title="Refazer (Ctrl+Y)"><Redo2 /></Button>
    </div>
  );
}
