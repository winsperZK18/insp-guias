import { useEffect, useMemo, useRef, useState } from "react";
import { useMarkChatRead } from "@/hooks/use-mentions";
import { CornerUpLeft, Mic2, Send, Trash2, X } from "lucide-react";
import { toast } from "sonner";
import { ProjectNotes } from "@/components/chat/project-notes";
import { ReactionBar } from "@/components/chat/reaction-bar";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { useAccess } from "@/hooks/use-access";
import { useMemberMap } from "@/hooks/use-members";
import { useDeleteMessage, useMessageReactions, useProjectMessages, useSendMessage, useToggleMessageReaction } from "@/hooks/use-project-chat";
import { memberName, type Member, type ProjectMessage } from "@/lib/chat-types";
import type { Guide } from "@/lib/types";

const guideTag = (g: Guide) => `${g.artist_name}${g.part_label ? ` ${g.part_label}` : ""}`.replace(/\s+/g, "_");

function formatTime(iso: string) {
  return new Date(iso).toLocaleString("pt-BR", { day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" });
}

function jumpToGuide(id: string) {
  const el = document.getElementById(`guia-${id}`);
  el?.scrollIntoView({ behavior: "smooth", block: "center" });
  el?.classList.add("ring-2", "ring-primary");
  setTimeout(() => el?.classList.remove("ring-2", "ring-primary"), 1600);
}

function Body({ msg, members, guides }: { msg: ProjectMessage; members: Member[]; guides: Guide[] }) {
  const names = members.map((m) => memberName(m).toLowerCase());
  const refs = guides.filter((g) => msg.guide_refs.includes(g.id));
  const parts = msg.body.split(/([@#][\p{L}0-9._-]+)/gu);
  return (
    <p className="whitespace-pre-wrap break-words text-sm">
      {parts.map((part, i) => {
        if (part.startsWith("@") && names.includes(part.slice(1).toLowerCase())) return <span key={i} className="font-semibold text-primary">{part}</span>;
        if (part.startsWith("#")) {
          const g = refs.find((item) => guideTag(item).toLowerCase() === part.slice(1).toLowerCase());
          if (g) return <button key={i} type="button" onClick={() => jumpToGuide(g.id)} className="mx-0.5 inline-flex items-center gap-1 rounded-full bg-primary/15 px-2 py-0.5 text-xs font-semibold text-primary"><Mic2 className="size-3" />{g.artist_name}{g.part_label ? ` · ${g.part_label}` : ""}</button>;
        }
        return <span key={i}>{part}</span>;
      })}
    </p>
  );
}

type Suggestion = { key: string; label: string; insert: string };

export function ProjectChat({ projectId, guides }: { projectId: string; guides: Guide[] }) {
  const access = useAccess();
  const { data: messages = [] } = useProjectMessages(projectId);
  const { data: members = [], map: memberById } = useMemberMap();
  const ids = useMemo(() => messages.map((m) => m.id), [messages]);
  const { data: reactions = [] } = useMessageReactions(projectId, ids);
  const send = useSendMessage(projectId);
  const remove = useDeleteMessage(projectId);
  const toggle = useToggleMessageReaction(projectId);
  const [tab, setTab] = useState<"chat" | "notas">("chat");
  const [text, setText] = useState("");
  const [replyTo, setReplyTo] = useState<ProjectMessage | null>(null);
  const [query, setQuery] = useState<{ sign: "@" | "#"; q: string } | null>(null);
  const areaRef = useRef<HTMLTextAreaElement>(null);
  const markRead = useMarkChatRead(projectId);
  const lastId = messages[messages.length - 1]?.id;
  useEffect(() => { if (lastId !== undefined || messages.length === 0) markRead.mutate(); }, [lastId]); // eslint-disable-line react-hooks/exhaustive-deps

  const suggestions: Suggestion[] = !query
    ? []
    : query.sign === "@"
      ? members.filter((m) => memberName(m).toLowerCase().includes(query.q.toLowerCase())).slice(0, 6).map((m) => ({ key: m.id, label: `@${memberName(m)}`, insert: `@${memberName(m)}` }))
      : guides.filter((g) => guideTag(g).toLowerCase().includes(query.q.toLowerCase())).slice(0, 6).map((g) => ({ key: g.id, label: `🎤 ${g.artist_name}${g.part_label ? ` · ${g.part_label}` : ""}`, insert: `#${guideTag(g)}` }));

  const handleChange = (value: string) => {
    setText(value);
    const match = /([@#])([\p{L}0-9._-]*)$/u.exec(value);
    setQuery(match ? { sign: match[1] as "@" | "#", q: match[2] ?? "" } : null);
  };

  const apply = (s: Suggestion) => {
    setText((cur) => cur.replace(/[@#][\p{L}0-9._-]*$/u, `${s.insert} `));
    setQuery(null);
    areaRef.current?.focus();
  };

  const submit = async () => {
    const body = text.trim();
    if (!body) return;
    const lower = body.toLowerCase();
    const mentions = members.filter((m) => lower.includes(`@${memberName(m).toLowerCase()}`)).map((m) => m.id);
    const guide_refs = guides.filter((g) => lower.includes(`#${guideTag(g).toLowerCase()}`)).map((g) => g.id);
    try {
      await send.mutateAsync({ body, reply_to_id: replyTo?.id ?? null, mentions, guide_refs });
      setText("");
      setReplyTo(null);
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Não foi possível enviar a mensagem.");
    }
  };

  return (
    <section id="chat" className="scroll-mt-20 border border-border bg-card p-4">
      <p className="text-xs uppercase text-primary">Conversa da música</p>
      <h2 className="mb-2 text-3xl">CHAT DA FAIXA</h2>
      <div className="mb-3 grid grid-cols-2 gap-1 rounded-md border border-border p-1">
        {(["chat", "notas"] as const).map((k) => (
          <button key={k} type="button" onClick={() => setTab(k)} className={`h-10 rounded text-sm font-semibold ${tab === k ? "bg-primary text-primary-foreground" : "text-muted-foreground"}`}>{k === "chat" ? "Conversa" : "Notas"}</button>
        ))}
      </div>
      {tab === "notas" ? <ProjectNotes projectId={projectId} /> : <>
      <p className="mb-4 text-xs text-muted-foreground">Use @ para chamar alguém e # para citar uma guia.</p>

      <div className="mb-3 max-h-[60vh] space-y-3 overflow-y-auto pr-1">
        {messages.length === 0 && <p className="text-sm text-muted-foreground">Ninguém falou ainda. Mande a primeira orientação.</p>}
        {messages.map((msg) => {
          const mine = msg.author_id === access.userId;
          const quoted = msg.reply_to_id ? messages.find((m) => m.id === msg.reply_to_id) : null;
          return (
            <div key={msg.id} className={`flex ${mine ? "justify-end" : "justify-start"}`}>
              <div className={`max-w-[85%] rounded-2xl border px-3 py-2 ${mine ? "border-primary/40 bg-primary/10" : "border-border bg-muted/40"}`}>
                <div className="mb-1 flex items-center gap-2 text-[11px] uppercase text-muted-foreground">
                  <span className="font-semibold text-foreground">{memberName(memberById.get(msg.author_id))}</span>
                  <span>{formatTime(msg.created_at)}</span>
                </div>
                {quoted && (
                  <div className="mb-2 border-l-2 border-primary/70 bg-background/60 px-2 py-1 text-xs">
                    <span className="block font-semibold text-primary">{memberName(memberById.get(quoted.author_id))}</span>
                    <span className="line-clamp-2 text-muted-foreground">{quoted.body}</span>
                  </div>
                )}
                <Body msg={msg} members={members} guides={guides} />
                <div className="mt-2 flex items-center gap-1">
                  <ReactionBar compact reactions={reactions.filter((r) => r.message_id === msg.id)} userId={access.userId} onToggle={(emoji, existingId) => toggle.mutate({ emoji, messageId: msg.id, existingId })} />
                  <Button size="icon" variant="ghost" className="size-8" aria-label="Responder" onClick={() => { setReplyTo(msg); areaRef.current?.focus(); }}><CornerUpLeft className="size-4" /></Button>
                  {(mine || access.isAdmin) && <Button size="icon" variant="ghost" className="size-8 text-destructive" aria-label="Apagar mensagem" onClick={() => remove.mutate(msg.id)}><Trash2 className="size-4" /></Button>}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {replyTo && (
        <div className="mb-2 flex items-center gap-2 border-l-2 border-primary bg-muted/40 px-2 py-1 text-xs">
          <div className="min-w-0 flex-1">
            <span className="block font-semibold text-primary">Respondendo {memberName(memberById.get(replyTo.author_id))}</span>
            <span className="line-clamp-1 text-muted-foreground">{replyTo.body}</span>
          </div>
          <Button size="icon" variant="ghost" className="size-8" aria-label="Cancelar resposta" onClick={() => setReplyTo(null)}><X className="size-4" /></Button>
        </div>
      )}

      {suggestions.length > 0 && (
        <div className="mb-2 flex flex-wrap gap-2">
          {suggestions.map((s) => <button key={s.key} type="button" onClick={() => apply(s)} className="h-9 rounded-full border border-border px-3 text-xs hover:border-primary">{s.label}</button>)}
        </div>
      )}

      <div className="flex items-end gap-2">
        <Textarea ref={areaRef} rows={2} value={text} onChange={(e) => handleChange(e.target.value)} onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); void submit(); } }} placeholder="Escreva... @ chama alguém, # cita uma guia" className="min-h-11 resize-none" />
        <Button size="icon" variant="hero" className="size-11" onClick={submit} disabled={send.isPending} aria-label="Enviar mensagem"><Send /></Button>
      </div>
      </>}
    </section>
  );
}
