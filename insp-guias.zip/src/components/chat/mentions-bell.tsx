import { Link } from "@tanstack/react-router";
import { AtSign, Bell } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { useMemberMap } from "@/hooks/use-members";
import { useMentions } from "@/hooks/use-mentions";
import { useProjects } from "@/hooks/use-projects";
import { memberName } from "@/lib/chat-types";

export function MentionsBell() {
  const { items, unreadCount } = useMentions();
  const { data: projects = [] } = useProjects();
  const { map } = useMemberMap();
  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button size="icon" variant="ghost" className="relative" aria-label={`Menções${unreadCount ? ` (${unreadCount} novas)` : ""}`}>
          <Bell />
          {unreadCount > 0 && <span className="absolute right-1 top-1 grid min-w-4 place-items-center rounded-full bg-primary px-1 text-[10px] font-bold text-primary-foreground">{unreadCount > 9 ? "9+" : unreadCount}</span>}
        </Button>
      </PopoverTrigger>
      <PopoverContent align="end" className="w-80 p-0">
        <p className="border-b border-border px-3 py-2 text-xs uppercase text-muted-foreground">Menções a você</p>
        <div className="max-h-96 overflow-y-auto">
          {items.length === 0 && <p className="p-4 text-sm text-muted-foreground">Ninguém te mencionou ainda.</p>}
          {items.map((m) => (
            <Link key={m.id} to="/projeto/$id" params={{ id: m.project_id }} hash="chat" className={`block border-b border-border px-3 py-2 text-sm hover:bg-muted/50 ${m.unread ? "bg-primary/10" : ""}`}>
              <span className="flex items-center gap-1 text-[11px] uppercase text-muted-foreground"><AtSign className="size-3" />{memberName(map.get(m.author_id))} · {projects.find((p) => p.id === m.project_id)?.title ?? "música"}</span>
              <span className="line-clamp-2">{m.body}</span>
            </Link>
          ))}
        </div>
      </PopoverContent>
    </Popover>
  );
}
