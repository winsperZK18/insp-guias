import { SmilePlus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { QUICK_EMOJIS, type Reaction } from "@/lib/chat-types";

export function ReactionBar({
  reactions,
  userId,
  onToggle,
  compact = false,
}: {
  reactions: Reaction[];
  userId: string | null;
  onToggle: (emoji: string, existingId: string | null) => void;
  compact?: boolean;
}) {
  const grouped = new Map<string, Reaction[]>();
  for (const reaction of reactions) {
    grouped.set(reaction.emoji, [...(grouped.get(reaction.emoji) ?? []), reaction]);
  }

  return (
    <div className="flex flex-wrap items-center gap-1">
      {[...grouped.entries()].map(([emoji, list]) => {
        const mine = list.find((item) => item.user_id === userId) ?? null;
        return (
          <button
            key={emoji}
            type="button"
            onClick={() => onToggle(emoji, mine?.id ?? null)}
            className={`flex h-8 min-w-11 items-center justify-center gap-1 rounded-full border px-2 text-xs transition-colors ${
              mine ? "border-primary bg-primary/15 text-primary" : "border-border bg-muted/40 text-muted-foreground hover:border-primary/60"
            }`}
            aria-label={`Reagir com ${emoji}`}
          >
            <span className="text-sm leading-none">{emoji}</span>
            <span>{list.length}</span>
          </button>
        );
      })}
      <Popover>
        <PopoverTrigger asChild>
          <Button size="icon" variant="ghost" className={compact ? "size-8" : "size-9"} aria-label="Adicionar reação">
            <SmilePlus className="size-4" />
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-auto p-2" align="start">
          <div className="flex gap-1">
            {QUICK_EMOJIS.map((emoji) => {
              const mine = reactions.find((item) => item.emoji === emoji && item.user_id === userId) ?? null;
              return (
                <button
                  key={emoji}
                  type="button"
                  className="grid size-11 place-items-center rounded-md text-xl hover:bg-muted"
                  onClick={() => onToggle(emoji, mine?.id ?? null)}
                >
                  {emoji}
                </button>
              );
            })}
          </div>
        </PopoverContent>
      </Popover>
    </div>
  );
}
