import { useEffect, useRef, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Globe, Lock } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { useAccess } from "@/hooks/use-access";
import { useMemberMap } from "@/hooks/use-members";
import { memberName } from "@/lib/chat-types";

type Note = { author_id: string; body: string; is_public: boolean; updated_at: string };
const t = () => supabase.from("artist_notes" as never) as any;

/** Cada artista tem sua nota privada e escolhe quando publicar para o grupo. */
export function ProjectNotes({ projectId }: { projectId: string }) {
  const { userId } = useAccess();
  const { map } = useMemberMap();
  const qc = useQueryClient();
  const key = ["artist-notes", projectId];
  const { data: notes = [] } = useQuery({
    queryKey: key,
    queryFn: async () => ((await t().select("author_id, body, is_public, updated_at").eq("project_id", projectId).order("updated_at", { ascending: false })).data ?? []) as Note[],
  });
  const mine = notes.find((n) => n.author_id === userId);
  const others = notes.filter((n) => n.author_id !== userId && n.is_public);
  const [text, setText] = useState<string | null>(null);
  const [isPublic, setIsPublic] = useState(false);
  const [status, setStatus] = useState("");
  const timer = useRef<ReturnType<typeof setTimeout> | undefined>(undefined);
  useEffect(() => { if (text === null && userId && notes) { setText(mine?.body ?? ""); setIsPublic(mine?.is_public ?? false); } }, [mine, userId, notes, text]);

  const save = async (body: string, pub: boolean) => {
    const { error } = await t().upsert({ project_id: projectId, author_id: userId, body, is_public: pub, updated_at: new Date().toISOString() });
    setStatus(error ? "Não salvou. Tente de novo." : "Salvo");
    if (!error) void qc.invalidateQueries({ queryKey: key });
  };
  const change = (v: string) => {
    setText(v); setStatus("Salvando...");
    clearTimeout(timer.current);
    timer.current = setTimeout(() => void save(v, isPublic), 800);
  };
  const togglePublic = () => { const next = !isPublic; setIsPublic(next); clearTimeout(timer.current); void save(text ?? "", next); };

  return (
    <div className="space-y-4">
      <div>
        <div className="mb-2 flex items-center justify-between gap-2">
          <span className="flex items-center gap-1 text-xs uppercase text-muted-foreground">{isPublic ? <><Globe className="size-3" /> Publicada para o grupo</> : <><Lock className="size-3" /> Só você vê</>}</span>
          <Button size="sm" variant={isPublic ? "outline" : "hero"} className="h-9" onClick={togglePublic}>{isPublic ? "Voltar a privada" : "Publicar pro grupo"}</Button>
        </div>
        <Textarea value={text ?? ""} onChange={(e) => change(e.target.value)} rows={10} placeholder="Sua nota: letras, rimas, ideias de refrão..." className="min-h-56" />
        <p className="mt-1 text-right text-xs text-muted-foreground">{status}</p>
      </div>
      {others.length > 0 && (
        <div className="space-y-2">
          <p className="text-xs uppercase text-primary">Notas publicadas</p>
          {others.map((n) => (
            <div key={n.author_id} className="border border-border bg-muted/30 p-3">
              <p className="mb-1 text-xs font-semibold">{memberName(map.get(n.author_id))}</p>
              <p className="whitespace-pre-wrap text-sm">{n.body || "(vazia)"}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
