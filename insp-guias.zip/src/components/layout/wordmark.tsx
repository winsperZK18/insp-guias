export function Wordmark({ className = "" }: { className?: string }) {
  return (
    <span
      className={`font-display leading-none tracking-[0.08em] text-white ${className}`}
      aria-label="INSPMUSIC"
    >
      INSPMUSIC
    </span>
  );
}
