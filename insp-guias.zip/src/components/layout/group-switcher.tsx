import { useState } from "react";
import { Check, ChevronsUpDown, Plus, User, Users } from "lucide-react";
import { toast } from "sonner";
import { useNavigate } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Input } from "@/components/ui/input";
import { setCurrentGroupId, useCreateGroup, useCurrentGroup } from "@/hooks/use-groups";

const ROLE = { admin: "admin", producer: "produtor", member: "artista" } as const;

/** Troca entre "Meu espaço" e os grupos; cria grupo novo. */
export function GroupSwitcher() {
  const { group, groups } = useCurrentGroup();
  const create = useCreateGroup();
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);
  const [name, setName] = useState("");
  const label = (g: { is_personal: boolean; name: string }) => (g.is_personal ? "Meu espaço" : g.name);
  const pick = (id: string) => { setCurrentGroupId(id); void navigate({ to: "/central" }); };

  return (
    <>
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="outline" className="h-10 max-w-[7.5rem] gap-2 px-2 sm:max-w-[11rem] sm:px-3">
            {group?.is_personal ? <User className="size-4" /> : <Users className="size-4" />}
            <span className="truncate">{group ? label(group) : "..."}</span>
            <ChevronsUpDown className="size-3.5 opacity-60" />
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end" className="w-64">
          {groups.map((g) => (
            <DropdownMenuItem key={g.id} onClick={() => pick(g.id)} className="gap-2">
              {g.is_personal ? <User className="size-4" /> : <Users className="size-4" />}
              <span className="min-w-0 flex-1 truncate">{label(g)}</span>
              <span className="text-[10px] uppercase text-muted-foreground">{ROLE[g.role]}</span>
              {g.id === group?.id && <Check className="size-4 text-primary" />}
            </DropdownMenuItem>
          ))}
          <DropdownMenuSeparator />
          <DropdownMenuItem onClick={() => setOpen(true)} className="gap-2"><Plus className="size-4" /> Criar grupo</DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>CRIAR GRUPO</DialogTitle></DialogHeader>
          <p className="text-sm text-muted-foreground">Banda, coletivo ou projeto. Você será o administrador e poderá convidar os integrantes.</p>
          <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Nome do grupo" maxLength={80} aria-label="Nome do grupo" />
          <DialogFooter>
            <Button variant="hero" className="h-11" disabled={!name.trim() || create.isPending} onClick={() => create.mutate(name.trim(), {
              onSuccess: () => { setOpen(false); setName(""); toast.success("Grupo criado. Convide os integrantes na central."); void navigate({ to: "/central" }); },
              onError: () => toast.error("Não foi possível criar o grupo."),
            })}>Criar</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
