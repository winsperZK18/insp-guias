import { Link, useNavigate } from "@tanstack/react-router";
import { useQueryClient } from "@tanstack/react-query";
import { ChevronLeft, History, LogOut } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useAccess } from "@/hooks/use-access";
import { supabase } from "@/integrations/supabase/client";
import { MentionsBell } from "@/components/chat/mentions-bell";
import { Wordmark } from "@/components/layout/wordmark";
import { GroupSwitcher } from "@/components/layout/group-switcher";

export function AppHeader({ back = false }: { back?: boolean }) {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const access = useAccess();

  async function signOut() {
    await queryClient.cancelQueries();
    queryClient.clear();
    await supabase.auth.signOut();
    await navigate({ to: "/", replace: true });
  }

  return (
    <header className="sticky top-0 z-40 border-b border-border/80 bg-background/90 backdrop-blur-xl">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between gap-2 px-3 sm:px-6">
        <div className="flex min-w-0 items-center gap-2 sm:gap-3">
          {back && <Button asChild size="icon" variant="ghost" className="size-8 sm:size-10"><Link to="/central" aria-label="Voltar para a central"><ChevronLeft /></Link></Button>}
          <Link to="/central" className="flex min-w-0 items-center gap-3">
            <Wordmark className="text-xl sm:text-3xl" />
            <span className="hidden text-[10px] uppercase text-muted-foreground sm:block">Central de guias</span>
          </Link>
        </div>
        <div className="flex min-w-0 items-center gap-1 sm:gap-2">
          <GroupSwitcher />
          <MentionsBell />
          {access.isAdmin && (
            <Button asChild size="icon" variant="ghost" className="hidden sm:inline-flex" aria-label="Histórico de alterações">
              <Link to="/auditoria"><History /></Link>
            </Button>
          )}
          <Button size="icon" variant="ghost" className="size-9 sm:size-10" onClick={signOut} aria-label="Sair"><LogOut /></Button>
        </div>
      </div>
    </header>
  );
}
