export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      artist_notes: {
        Row: {
          author_id: string
          body: string
          is_public: boolean
          project_id: string
          updated_at: string
        }
        Insert: {
          author_id?: string
          body?: string
          is_public?: boolean
          project_id: string
          updated_at?: string
        }
        Update: {
          author_id?: string
          body?: string
          is_public?: boolean
          project_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "artist_notes_project_id_fkey"
            columns: ["project_id"]
            isOneToOne: false
            referencedRelation: "projects"
            referencedColumns: ["id"]
          },
        ]
      }
      audit_logs: {
        Row: {
          action: string
          actor_id: string | null
          created_at: string
          details: Json
          entity_id: string | null
          entity_label: string | null
          entity_type: string
          group_id: string | null
          id: string
        }
        Insert: {
          action: string
          actor_id?: string | null
          created_at?: string
          details?: Json
          entity_id?: string | null
          entity_label?: string | null
          entity_type: string
          group_id?: string | null
          id?: string
        }
        Update: {
          action?: string
          actor_id?: string | null
          created_at?: string
          details?: Json
          entity_id?: string | null
          entity_label?: string | null
          entity_type?: string
          group_id?: string | null
          id?: string
        }
        Relationships: []
      }
      chat_reads: {
        Row: {
          last_read_at: string
          project_id: string
          user_id: string
        }
        Insert: {
          last_read_at?: string
          project_id: string
          user_id?: string
        }
        Update: {
          last_read_at?: string
          project_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "chat_reads_project_id_fkey"
            columns: ["project_id"]
            isOneToOne: false
            referencedRelation: "projects"
            referencedColumns: ["id"]
          },
        ]
      }
      group_invitations: {
        Row: {
          created_at: string
          email: string
          group_id: string
          id: string
          invited_by: string
          role: Database["public"]["Enums"]["app_role"]
        }
        Insert: {
          created_at?: string
          email: string
          group_id: string
          id?: string
          invited_by?: string
          role?: Database["public"]["Enums"]["app_role"]
        }
        Update: {
          created_at?: string
          email?: string
          group_id?: string
          id?: string
          invited_by?: string
          role?: Database["public"]["Enums"]["app_role"]
        }
        Relationships: [
          {
            foreignKeyName: "group_invitations_group_id_fkey"
            columns: ["group_id"]
            isOneToOne: false
            referencedRelation: "groups"
            referencedColumns: ["id"]
          },
        ]
      }
      group_invites: {
        Row: {
          claimed_at: string | null
          claimed_by: string | null
          created_at: string
          email: string
          id: string
          invited_by: string
          role: Database["public"]["Enums"]["app_role"]
        }
        Insert: {
          claimed_at?: string | null
          claimed_by?: string | null
          created_at?: string
          email: string
          id?: string
          invited_by: string
          role?: Database["public"]["Enums"]["app_role"]
        }
        Update: {
          claimed_at?: string | null
          claimed_by?: string | null
          created_at?: string
          email?: string
          id?: string
          invited_by?: string
          role?: Database["public"]["Enums"]["app_role"]
        }
        Relationships: []
      }
      group_members: {
        Row: {
          created_at: string
          group_id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string
          group_id: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string
          group_id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "group_members_group_id_fkey"
            columns: ["group_id"]
            isOneToOne: false
            referencedRelation: "groups"
            referencedColumns: ["id"]
          },
        ]
      }
      group_settings: {
        Row: {
          group_name: string | null
          id: number
          updated_at: string
          updated_by: string | null
        }
        Insert: {
          group_name?: string | null
          id?: number
          updated_at?: string
          updated_by?: string | null
        }
        Update: {
          group_name?: string | null
          id?: number
          updated_at?: string
          updated_by?: string | null
        }
        Relationships: []
      }
      group_timeline_editors: {
        Row: {
          created_at: string
          granted_by: string | null
          group_id: string
          user_id: string
        }
        Insert: {
          created_at?: string
          granted_by?: string | null
          group_id: string
          user_id: string
        }
        Update: {
          created_at?: string
          granted_by?: string | null
          group_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "group_timeline_editors_group_id_fkey"
            columns: ["group_id"]
            isOneToOne: false
            referencedRelation: "groups"
            referencedColumns: ["id"]
          },
        ]
      }
      groups: {
        Row: {
          created_at: string
          id: string
          is_personal: boolean
          name: string
          owner_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          is_personal?: boolean
          name: string
          owner_id: string
        }
        Update: {
          created_at?: string
          id?: string
          is_personal?: boolean
          name?: string
          owner_id?: string
        }
        Relationships: []
      }
      guide_comments: {
        Row: {
          author_id: string
          body: string
          created_at: string
          guide_id: string
          id: string
          mentions: string[]
          project_id: string
          reply_to_id: string | null
        }
        Insert: {
          author_id?: string
          body: string
          created_at?: string
          guide_id: string
          id?: string
          mentions?: string[]
          project_id: string
          reply_to_id?: string | null
        }
        Update: {
          author_id?: string
          body?: string
          created_at?: string
          guide_id?: string
          id?: string
          mentions?: string[]
          project_id?: string
          reply_to_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "guide_comments_guide_id_fkey"
            columns: ["guide_id"]
            isOneToOne: false
            referencedRelation: "guides"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "guide_comments_project_id_fkey"
            columns: ["project_id"]
            isOneToOne: false
            referencedRelation: "projects"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "guide_comments_reply_to_id_fkey"
            columns: ["reply_to_id"]
            isOneToOne: false
            referencedRelation: "guide_comments"
            referencedColumns: ["id"]
          },
        ]
      }
      guides: {
        Row: {
          artist_name: string
          audio_path: string
          audio_url: string
          created_at: string
          detected_offset_seconds: number | null
          duration_seconds: number | null
          entry_seconds: number
          file_name: string | null
          id: string
          notes: string | null
          owner_id: string | null
          part_label: string | null
          position: number
          processed_path: string | null
          processed_url: string | null
          project_id: string
          section_id: string | null
          status: string
          trim_end_seconds: number | null
          trim_start_seconds: number
        }
        Insert: {
          artist_name: string
          audio_path: string
          audio_url: string
          created_at?: string
          detected_offset_seconds?: number | null
          duration_seconds?: number | null
          entry_seconds?: number
          file_name?: string | null
          id?: string
          notes?: string | null
          owner_id?: string | null
          part_label?: string | null
          position?: number
          processed_path?: string | null
          processed_url?: string | null
          project_id: string
          section_id?: string | null
          status?: string
          trim_end_seconds?: number | null
          trim_start_seconds?: number
        }
        Update: {
          artist_name?: string
          audio_path?: string
          audio_url?: string
          created_at?: string
          detected_offset_seconds?: number | null
          duration_seconds?: number | null
          entry_seconds?: number
          file_name?: string | null
          id?: string
          notes?: string | null
          owner_id?: string | null
          part_label?: string | null
          position?: number
          processed_path?: string | null
          processed_url?: string | null
          project_id?: string
          section_id?: string | null
          status?: string
          trim_end_seconds?: number | null
          trim_start_seconds?: number
        }
        Relationships: [
          {
            foreignKeyName: "guides_project_id_fkey"
            columns: ["project_id"]
            isOneToOne: false
            referencedRelation: "projects"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "guides_section_id_fkey"
            columns: ["section_id"]
            isOneToOne: false
            referencedRelation: "track_sections"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          avatar_url: string | null
          created_at: string
          display_name: string | null
          email: string
          id: string
          updated_at: string
        }
        Insert: {
          avatar_url?: string | null
          created_at?: string
          display_name?: string | null
          email: string
          id: string
          updated_at?: string
        }
        Update: {
          avatar_url?: string | null
          created_at?: string
          display_name?: string | null
          email?: string
          id?: string
          updated_at?: string
        }
        Relationships: []
      }
      project_guests: {
        Row: {
          created_at: string
          email: string
          invited_by: string
          project_id: string
          user_id: string | null
        }
        Insert: {
          created_at?: string
          email: string
          invited_by?: string
          project_id: string
          user_id?: string | null
        }
        Update: {
          created_at?: string
          email?: string
          invited_by?: string
          project_id?: string
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "project_guests_project_id_fkey"
            columns: ["project_id"]
            isOneToOne: false
            referencedRelation: "projects"
            referencedColumns: ["id"]
          },
        ]
      }
      project_messages: {
        Row: {
          author_id: string
          body: string
          created_at: string
          guide_refs: string[]
          id: string
          mentions: string[]
          project_id: string
          reply_to_id: string | null
        }
        Insert: {
          author_id?: string
          body: string
          created_at?: string
          guide_refs?: string[]
          id?: string
          mentions?: string[]
          project_id: string
          reply_to_id?: string | null
        }
        Update: {
          author_id?: string
          body?: string
          created_at?: string
          guide_refs?: string[]
          id?: string
          mentions?: string[]
          project_id?: string
          reply_to_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "project_messages_project_id_fkey"
            columns: ["project_id"]
            isOneToOne: false
            referencedRelation: "projects"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "project_messages_reply_to_id_fkey"
            columns: ["reply_to_id"]
            isOneToOne: false
            referencedRelation: "project_messages"
            referencedColumns: ["id"]
          },
        ]
      }
      project_notes: {
        Row: {
          body: string
          project_id: string
          updated_at: string
          updated_by: string | null
        }
        Insert: {
          body?: string
          project_id: string
          updated_at?: string
          updated_by?: string | null
        }
        Update: {
          body?: string
          project_id?: string
          updated_at?: string
          updated_by?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "project_notes_project_id_fkey"
            columns: ["project_id"]
            isOneToOne: true
            referencedRelation: "projects"
            referencedColumns: ["id"]
          },
        ]
      }
      projects: {
        Row: {
          beat_duration_seconds: number | null
          beat_file_name: string | null
          beat_path: string | null
          beat_url: string | null
          bpm: number | null
          created_at: string
          group_id: string | null
          id: string
          musical_key: string | null
          notes: string | null
          owner_id: string | null
          parent_project_id: string | null
          preview_created_at: string | null
          preview_path: string | null
          preview_url: string | null
          release_kind: string
          release_title: string | null
          status: string
          title: string
        }
        Insert: {
          beat_duration_seconds?: number | null
          beat_file_name?: string | null
          beat_path?: string | null
          beat_url?: string | null
          bpm?: number | null
          created_at?: string
          group_id?: string | null
          id?: string
          musical_key?: string | null
          notes?: string | null
          owner_id?: string | null
          parent_project_id?: string | null
          preview_created_at?: string | null
          preview_path?: string | null
          preview_url?: string | null
          release_kind?: string
          release_title?: string | null
          status?: string
          title: string
        }
        Update: {
          beat_duration_seconds?: number | null
          beat_file_name?: string | null
          beat_path?: string | null
          beat_url?: string | null
          bpm?: number | null
          created_at?: string
          group_id?: string | null
          id?: string
          musical_key?: string | null
          notes?: string | null
          owner_id?: string | null
          parent_project_id?: string | null
          preview_created_at?: string | null
          preview_path?: string | null
          preview_url?: string | null
          release_kind?: string
          release_title?: string | null
          status?: string
          title?: string
        }
        Relationships: [
          {
            foreignKeyName: "projects_group_id_fkey"
            columns: ["group_id"]
            isOneToOne: false
            referencedRelation: "groups"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "projects_parent_project_id_fkey"
            columns: ["parent_project_id"]
            isOneToOne: false
            referencedRelation: "projects"
            referencedColumns: ["id"]
          },
        ]
      }
      reactions: {
        Row: {
          comment_id: string | null
          created_at: string
          emoji: string
          guide_id: string | null
          id: string
          message_id: string | null
          user_id: string
        }
        Insert: {
          comment_id?: string | null
          created_at?: string
          emoji: string
          guide_id?: string | null
          id?: string
          message_id?: string | null
          user_id?: string
        }
        Update: {
          comment_id?: string | null
          created_at?: string
          emoji?: string
          guide_id?: string | null
          id?: string
          message_id?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "reactions_comment_id_fkey"
            columns: ["comment_id"]
            isOneToOne: false
            referencedRelation: "guide_comments"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "reactions_guide_id_fkey"
            columns: ["guide_id"]
            isOneToOne: false
            referencedRelation: "guides"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "reactions_message_id_fkey"
            columns: ["message_id"]
            isOneToOne: false
            referencedRelation: "project_messages"
            referencedColumns: ["id"]
          },
        ]
      }
      timeline_editors: {
        Row: {
          created_at: string
          granted_by: string | null
          user_id: string
        }
        Insert: {
          created_at?: string
          granted_by?: string | null
          user_id: string
        }
        Update: {
          created_at?: string
          granted_by?: string | null
          user_id?: string
        }
        Relationships: []
      }
      track_sections: {
        Row: {
          confidence: number | null
          created_at: string
          end_seconds: number
          id: string
          is_suggested: boolean
          kind: string
          label: string
          position: number
          project_id: string
          start_seconds: number
        }
        Insert: {
          confidence?: number | null
          created_at?: string
          end_seconds?: number
          id?: string
          is_suggested?: boolean
          kind: string
          label: string
          position?: number
          project_id: string
          start_seconds?: number
        }
        Update: {
          confidence?: number | null
          created_at?: string
          end_seconds?: number
          id?: string
          is_suggested?: boolean
          kind?: string
          label?: string
          position?: number
          project_id?: string
          start_seconds?: number
        }
        Relationships: [
          {
            foreignKeyName: "track_sections_project_id_fkey"
            columns: ["project_id"]
            isOneToOne: false
            referencedRelation: "projects"
            referencedColumns: ["id"]
          },
        ]
      }
      track_tasks: {
        Row: {
          created_at: string
          done: boolean
          done_at: string | null
          done_by: string | null
          id: string
          position: number
          project_id: string
          title: string
        }
        Insert: {
          created_at?: string
          done?: boolean
          done_at?: string | null
          done_by?: string | null
          id?: string
          position?: number
          project_id: string
          title: string
        }
        Update: {
          created_at?: string
          done?: boolean
          done_at?: string | null
          done_by?: string | null
          id?: string
          position?: number
          project_id?: string
          title?: string
        }
        Relationships: [
          {
            foreignKeyName: "track_tasks_project_id_fkey"
            columns: ["project_id"]
            isOneToOne: false
            referencedRelation: "projects"
            referencedColumns: ["id"]
          },
        ]
      }
      user_roles: {
        Row: {
          created_at: string
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      admins_group: { Args: { _group: string; _uid: string }; Returns: boolean }
      can_manage_audio: {
        Args: { _path: string; _uid: string }
        Returns: boolean
      }
      can_manage_guide: {
        Args: { _owner_id: string; _status: string; _user_id: string }
        Returns: boolean
      }
      can_manage_projects: { Args: { _user_id: string }; Returns: boolean }
      can_read_audio: {
        Args: { _path: string; _uid: string }
        Returns: boolean
      }
      claim_group_access: {
        Args: { _avatar_url?: string; _display_name?: string }
        Returns: Database["public"]["Enums"]["app_role"]
      }
      claim_project_invites: { Args: never; Returns: undefined }
      create_group: { Args: { _name: string }; Returns: string }
      has_group_access: { Args: { _user_id: string }; Returns: boolean }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      in_project: { Args: { _project: string; _uid: string }; Returns: boolean }
      is_group_member: { Args: { _user_id: string }; Returns: boolean }
      is_member_of: { Args: { _group: string; _uid: string }; Returns: boolean }
      manages_group: {
        Args: { _group: string; _uid: string }
        Returns: boolean
      }
      manages_project: {
        Args: { _project: string; _uid: string }
        Returns: boolean
      }
      member_role: {
        Args: { _group: string; _uid: string }
        Returns: Database["public"]["Enums"]["app_role"]
      }
      project_group: { Args: { _project: string }; Returns: string }
      shares_group: { Args: { _a: string; _b: string }; Returns: boolean }
    }
    Enums: {
      app_role: "admin" | "member" | "producer"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "member", "producer"],
    },
  },
} as const
