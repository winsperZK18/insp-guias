import { supabase } from "@/integrations/supabase/client";

export const BUCKET = "guias-audio";
export const MAX_AUDIO_BYTES = 100 * 1024 * 1024;

export const ACCEPTED_AUDIO_TYPES = [
  "audio/mpeg",
  "audio/mp3",
  "audio/wav",
  "audio/x-wav",
  "audio/wave",
  "audio/mp4",
  "audio/aac",
  "audio/ogg",
  "audio/webm",
];

export function validateAudioFile(file: File): string | null {
  const okType =
    ACCEPTED_AUDIO_TYPES.includes(file.type) ||
    /\.(mp3|wav|m4a|aac|ogg|webm|mp4)$/i.test(file.name);
  if (!okType) return "Esse arquivo não é um áudio aceito (mp3, wav, m4a, aac, ogg ou webm).";
  if (file.size > MAX_AUDIO_BYTES) return "O arquivo passa de 100 MB. Envie um áudio menor.";
  return null;
}

function extensionOf(name: string, fallback = "wav") {
  const match = /\.([a-z0-9]+)$/i.exec(name);
  return match?.[1]?.toLowerCase() ?? fallback;
}

export function buildObjectName(prefix: string, fileName: string) {
  return `${prefix}/${crypto.randomUUID()}.${extensionOf(fileName)}`;
}

export async function uploadAudio(prefix: string, file: Blob, fileName: string) {
  const path = buildObjectName(prefix, fileName);
  const { error } = await supabase.storage.from(BUCKET).upload(path, file, {
    contentType: file.type || "audio/wav",
    upsert: true,
  });
  if (error) throw new Error(`Falha ao enviar o áudio: ${error.message}`);
  return path;
}

export async function uploadAudioAt(path: string, file: Blob, contentType = "audio/wav") {
  const { error } = await supabase.storage
    .from(BUCKET)
    .upload(path, file, { contentType, upsert: true });
  if (error) throw new Error(`Falha ao salvar o áudio: ${error.message}`);
  return path;
}

export async function getAudioUrl(path: string | null | undefined) {
  if (!path) return null;
  const { data, error } = await supabase.storage.from(BUCKET).createSignedUrl(path, 60 * 60 * 24 * 7);
  if (error) return null;
  return data?.signedUrl ?? null;
}

export async function downloadAudio(path: string): Promise<Blob> {
  const { data, error } = await supabase.storage.from(BUCKET).download(path);
  if (error || !data) throw new Error(`Não foi possível baixar o áudio: ${error?.message ?? ""}`);
  return data;
}

export async function removeAudio(paths: (string | null | undefined)[]) {
  const valid = paths.filter((p): p is string => Boolean(p));
  if (!valid.length) return;
  await supabase.storage.from(BUCKET).remove(valid);
}
