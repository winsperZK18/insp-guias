import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const schema = z.object({
  bpm: z.number().nullable(),
  entrySeconds: z.number(),
  voiceDuration: z.number(),
  beatOnsets: z.array(z.number()).max(500),
  voiceOnsets: z.array(z.number()).max(300),
});

export const analyzeGuideSync = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data) => schema.parse(data))
  .handler(async ({ data }) => {
    const { analyzeSync } = await import("./sync-analysis.server");
    return analyzeSync(data);
  });
