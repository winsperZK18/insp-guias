/** Grade musical: converte BPM em tempos (batidas) e compassos de 4/4. */
export const DEFAULT_BPM = 90;

export function secondsPerBeat(bpm: number | null | undefined) {
  const safe = Number(bpm) > 0 ? Number(bpm) : DEFAULT_BPM;
  return 60 / safe;
}

export function secondsPerBar(bpm: number | null | undefined) {
  return secondsPerBeat(bpm) * 4;
}

export function barsToSeconds(bars: number, bpm: number | null | undefined) {
  return bars * secondsPerBar(bpm);
}

/** Cola o tempo na cabeça do compasso mais próximo. */
export function snapToBar(seconds: number, bpm: number | null | undefined) {
  const bar = secondsPerBar(bpm);
  return Math.max(0, Math.round(seconds / bar) * bar);
}

/** Rótulo amigável: "compasso 5 · tempo 2". */
export function barLabel(seconds: number, bpm: number | null | undefined) {
  const beat = secondsPerBeat(bpm);
  const totalBeats = Math.max(0, Math.round(seconds / beat));
  return `compasso ${Math.floor(totalBeats / 4) + 1} · tempo ${(totalBeats % 4) + 1}`;
}

export type StructureBlock = { kind: string; label: string; bars: number };

export const STRUCTURE_PRESETS: { id: string; name: string; blocks: StructureBlock[] }[] = [
  {
    id: "rap",
    name: "Rap padrão",
    blocks: [
      { kind: "intro", label: "Intro", bars: 4 },
      { kind: "verso", label: "Verso 1", bars: 16 },
      { kind: "refrao", label: "Refrão", bars: 8 },
      { kind: "verso", label: "Verso 2", bars: 16 },
      { kind: "refrao", label: "Refrão 2", bars: 8 },
      { kind: "final", label: "Final", bars: 4 },
    ],
  },
  {
    id: "cypher",
    name: "Cypher (3 versos)",
    blocks: [
      { kind: "intro", label: "Intro", bars: 2 },
      { kind: "verso", label: "Verso 1", bars: 12 },
      { kind: "verso", label: "Verso 2", bars: 12 },
      { kind: "verso", label: "Verso 3", bars: 12 },
      { kind: "final", label: "Final", bars: 2 },
    ],
  },
  {
    id: "hit",
    name: "Refrão na frente",
    blocks: [
      { kind: "intro", label: "Intro", bars: 4 },
      { kind: "refrao", label: "Refrão", bars: 8 },
      { kind: "verso", label: "Verso 1", bars: 16 },
      { kind: "refrao", label: "Refrão 2", bars: 8 },
      { kind: "verso", label: "Verso 2", bars: 16 },
      { kind: "refrao", label: "Refrão 3", bars: 8 },
    ],
  },
];

/** Partes básicas quando o produtor ainda não desenhou a estrutura. */
export const BASIC_PARTS = ["Intro", "Verso 1", "Refrão", "Verso 2", "Ponte", "Final"];
