import { loadAudioBuffer } from "./buffer-cache";
import { downloadBlob, encodeMp3 } from "./mp3";
import { renderPreview } from "./render-preview";
import { processGuide } from "../dsp/process-guide";
import type { Guide } from "../types";

export type MixOptions = { beatGain?: number; voiceGain?: number; onProgress?: (ratio: number, label: string) => void };

const slug = (s: string) => s.normalize("NFD").replace(/[^\w]+/g, "-").replace(/^-|-$/g, "").toLowerCase() || "faixa";

/** Carrega a voz limpa: usa a tratada salva ou limpa na hora usando o beat como referência. */
async function cleanVoice(guide: Guide, beat: AudioBuffer | null) {
  if (guide.processed_path) return loadAudioBuffer(guide.processed_path);
  const raw = await loadAudioBuffer(guide.audio_path);
  const { buffer } = await processGuide(raw, beat, { offsetSeconds: guide.detected_offset_seconds != null ? Number(guide.detected_offset_seconds) : null });
  return buffer;
}

/** Limpa todas as vozes, posiciona cada uma no seu tempo de entrada sobre o beat e baixa um MP3. */
export async function exportMixMp3(title: string, beatPath: string | null, guides: Guide[], opts: MixOptions = {}) {
  const { onProgress } = opts;
  onProgress?.(0.02, "Carregando o beat");
  const beat = beatPath ? await loadAudioBuffer(beatPath) : null;
  const layers = [];
  for (const [i, guide] of guides.entries()) {
    onProgress?.(0.05 + (0.6 * i) / Math.max(1, guides.length), `Limpando voz de ${guide.artist_name}`);
    layers.push({ buffer: await cleanVoice(guide, beat), entrySeconds: Number(guide.entry_seconds) || 0, trimStart: Number(guide.trim_start_seconds) || 0, trimEnd: guide.trim_end_seconds != null ? Number(guide.trim_end_seconds) : null, gain: opts.voiceGain ?? 1 });
  }
  onProgress?.(0.7, "Mixando");
  const mix = await renderPreview(beat, layers, { beatGain: opts.beatGain ?? 0.85 });
  let peak = 0;
  for (let c = 0; c < mix.numberOfChannels; c++) for (const s of mix.getChannelData(c)) peak = Math.max(peak, Math.abs(s));
  if (peak > 0.98) for (let c = 0; c < mix.numberOfChannels; c++) { const d = mix.getChannelData(c); for (let i = 0; i < d.length; i++) d[i] = (d[i] ?? 0) * (0.98 / peak); }
  const blob = await encodeMp3(mix, (r) => onProgress?.(0.75 + r * 0.24, "Gerando MP3"));
  const name = guides.length === 1 ? `${slug(title)}-${slug(guides[0]?.artist_name ?? "voz")}.mp3` : `${slug(title)}-mix-completo.mp3`;
  downloadBlob(blob, name);
  onProgress?.(1, "Pronto");
}
