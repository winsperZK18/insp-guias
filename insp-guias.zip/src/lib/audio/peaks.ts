import { bufferToMono } from "./decode";

/** Retorna pares [min, max] por coluna para desenhar a waveform. */
export function computePeaks(buffer: AudioBuffer, columns: number): Float32Array {
  const mono = bufferToMono(buffer);
  const out = new Float32Array(columns * 2);
  const step = Math.max(1, Math.floor(mono.length / columns));
  for (let i = 0; i < columns; i++) {
    const start = i * step;
    const end = Math.min(mono.length, start + step);
    let min = 0;
    let max = 0;
    for (let j = start; j < end; j++) {
      const v = mono[j] ?? 0;
      if (v < min) min = v;
      if (v > max) max = v;
    }
    out[i * 2] = min;
    out[i * 2 + 1] = max;
  }
  return out;
}
