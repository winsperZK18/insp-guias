import { decodeAudioBuffer } from "./decode";
import { downloadAudio } from "../storage";

const cache = new Map<string, Promise<AudioBuffer>>();

export function loadAudioBuffer(path: string): Promise<AudioBuffer> {
  const cached = cache.get(path);
  if (cached) return cached;
  const promise = downloadAudio(path).then(decodeAudioBuffer);
  cache.set(path, promise);
  promise.catch(() => cache.delete(path));
  return promise;
}

export function clearAudioBuffer(path: string | null | undefined) {
  if (path) cache.delete(path);
}
