import { Mp3Encoder } from "@breezystack/lamejs";

const toInt16 = (data: Float32Array, start: number, end: number) => {
  const out = new Int16Array(end - start);
  for (let i = start; i < end; i++) {
    const s = Math.max(-1, Math.min(1, data[i] ?? 0));
    out[i - start] = s < 0 ? s * 0x8000 : s * 0x7fff;
  }
  return out;
};

/** Codifica um AudioBuffer em MP3 (192 kbps) no navegador. */
export async function encodeMp3(buffer: AudioBuffer, onProgress?: (ratio: number) => void): Promise<Blob> {
  const stereo = buffer.numberOfChannels > 1;
  const left = buffer.getChannelData(0);
  const right = stereo ? buffer.getChannelData(1) : left;
  const encoder = new Mp3Encoder(stereo ? 2 : 1, buffer.sampleRate, 192);
  const chunks: BlobPart[] = [];
  const block = 1152 * 40;
  for (let i = 0; i < left.length; i += block) {
    const end = Math.min(left.length, i + block);
    const l = toInt16(left, i, end);
    const out = stereo ? encoder.encodeBuffer(l, toInt16(right, i, end)) : encoder.encodeBuffer(l);
    if (out.length) chunks.push(new Uint8Array(out));
    if ((i / block) % 20 === 0) {
      onProgress?.(i / left.length);
      await new Promise((r) => setTimeout(r, 0));
    }
  }
  const tail = encoder.flush();
  if (tail.length) chunks.push(new Uint8Array(tail));
  return new Blob(chunks, { type: "audio/mpeg" });
}

export function downloadBlob(blob: Blob, fileName: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = fileName;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 5000);
}
