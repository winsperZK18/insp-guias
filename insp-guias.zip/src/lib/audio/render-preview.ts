export type PreviewLayer = {
  buffer: AudioBuffer;
  entrySeconds: number;
  gain?: number;
  /** Trecho do arquivo que toca (corte de início/fim), em segundos do próprio áudio. */
  trimStart?: number;
  trimEnd?: number | null;
};

/** Mistura o beat com as vozes posicionadas nos respectivos tempos de entrada. */
export async function renderPreview(
  beat: AudioBuffer | null,
  layers: PreviewLayer[],
  options: { beatGain?: number } = {},
): Promise<AudioBuffer> {
  const sampleRate = beat?.sampleRate ?? layers[0]?.buffer.sampleRate ?? 44100;
  const beatLength = beat ? beat.duration : 0;
  const layersEnd = layers.reduce(
    (max, layer) => Math.max(max, layer.entrySeconds + layer.buffer.duration),
    0,
  );
  const totalSeconds = Math.max(1, beatLength, layersEnd) + 0.5;
  const frames = Math.ceil(totalSeconds * sampleRate);

  const ctx = new OfflineAudioContext(2, frames, sampleRate);

  if (beat) {
    const source = ctx.createBufferSource();
    source.buffer = beat;
    const gain = ctx.createGain();
    gain.gain.value = options.beatGain ?? 0.85;
    source.connect(gain).connect(ctx.destination);
    source.start(0);
  }

  for (const layer of layers) {
    const source = ctx.createBufferSource();
    source.buffer = layer.buffer;
    const gain = ctx.createGain();
    gain.gain.value = layer.gain ?? 1;
    source.connect(gain).connect(ctx.destination);
    const a = Math.max(0, layer.trimStart ?? 0);
    const b = Math.min(layer.buffer.duration, layer.trimEnd ?? layer.buffer.duration);
    if (b <= a) continue;
    source.start(Math.max(0, layer.entrySeconds + a), a, b - a);
  }

  return await ctx.startRendering();
}
