import type { Guide } from "./types";

export type MappingPreset = {
  id: string;
  label: string;
  description: string;
  build: (guides: Guide[]) => { id: string; entry_seconds: number; position: number }[];
};

function sequential(guides: Guide[], reverse = false) {
  const ordered = [...guides].sort((a, b) => a.position - b.position);
  const list = reverse ? ordered.reverse() : ordered;
  let cursor = 0;
  return list.map((guide, index) => {
    const entry = cursor;
    cursor += (guide.duration_seconds ?? 16) + 0.5;
    return { id: guide.id, entry_seconds: Number(entry.toFixed(2)), position: index };
  });
}

export const MAPPING_PRESETS: MappingPreset[] = [
  {
    id: "sequencial",
    label: "Sequencial do início",
    description: "As partes entram uma depois da outra, começando no zero.",
    build: (guides) => sequential(guides),
  },
  {
    id: "detectado",
    label: "Entradas detectadas",
    description: "Usa o tempo encontrado no alinhamento de cada guia com o beat.",
    build: (guides) =>
      [...guides]
        .sort((a, b) => (a.detected_offset_seconds ?? 0) - (b.detected_offset_seconds ?? 0))
        .map((guide, index) => ({
          id: guide.id,
          entry_seconds: Number((guide.detected_offset_seconds ?? guide.entry_seconds ?? 0).toFixed(2)),
          position: index,
        })),
  },
  {
    id: "inversa",
    label: "Ordem inversa",
    description: "Inverte a ordem das partes para testar outro arranjo.",
    build: (guides) => sequential(guides, true),
  },
];
