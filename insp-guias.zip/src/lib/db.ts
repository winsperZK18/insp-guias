import { supabase } from "@/integrations/supabase/client";
import type { Guide, Project, TrackSection } from "./types";

/** Acesso tipado às tabelas do app. */
export const projectsTable = () => supabase.from("projects") as any;
export const guidesTable = () => supabase.from("guides") as any;
export const trackSectionsTable = () => supabase.from("track_sections") as any;

export function asProject(row: unknown): Project {
  return row as Project;
}

export function asProjects(rows: unknown): Project[] {
  return (rows ?? []) as Project[];
}

export function asGuides(rows: unknown): Guide[] {
  return (rows ?? []) as Guide[];
}

export function asTrackSections(rows: unknown): TrackSection[] {
  return (rows ?? []) as TrackSection[];
}
