import { createOpenAI } from "@ai-sdk/openai";
import { streamText } from "ai";

export type SyncIssue = { start: number; end: number; offsetMs: number; note: string };
export type SyncReport = { summary: string; explanation: string; suggestedEntryShift: number; issues: SyncIssue[] };

const PROMPT = `Você é um engenheiro de áudio de rap. Recebe tempos (segundos, já na linha do tempo do beat) de ataques do beat e de ataques da voz, o BPM informado e o ponto de entrada da voz.
Monte a grade de tempos a partir do BPM (ou dos ataques do beat se o BPM faltar), compare os ataques da voz com a grade e identifique trechos onde a voz está consistentemente adiantada ou atrasada.
Responda SOMENTE um JSON, sem markdown, no formato:
{"summary": "texto curto em português do Brasil (máx. 2 frases)", "explanation": "2 a 4 frases explicando como a voz casa com a grade do beat e por que o deslocamento recomendado é esse", "suggestedEntryShift": número em segundos para somar ao ponto de entrada (negativo adianta, 0 se já está bom, limite ±2), "issues": [{"start": s, "end": s, "offsetMs": ms (positivo = voz atrasada), "note": "sugestão curta em PT-BR"}]}
No máximo 8 trechos. Se estiver tudo no tempo, devolva issues vazio. Lembre que é uma estimativa por ataques, não certeza.`;

export async function analyzeSync(features: unknown): Promise<SyncReport> {
  const apiKey = process.env['LOVABLE_API_KEY'];
  if (!apiKey) throw new Error("IA não configurada.");
  const provider = createOpenAI({
    baseURL: "https://ai.gateway.lovable.dev/v1",
    apiKey,
    headers: { "Lovable-API-Key": apiKey, "X-Lovable-AIG-SDK": "vercel-ai-sdk" },
  });
  const result = streamText({
    model: provider.responses("openai/gpt-6-astra"),
    system: PROMPT,
    prompt: JSON.stringify(features),
    providerOptions: {
      openai: { forceReasoning: true, reasoningEffort: "low", reasoningSummary: "auto", store: false, include: ["reasoning.encrypted_content"] },
    },
  });
  let text: string;
  try {
    text = await result.text;
  } catch (error) {
    const status = (error as { statusCode?: number }).statusCode;
    if (status === 402) throw new Error("Os créditos de IA acabaram. Recarregue em Configurações → Planos e créditos.");
    if (status === 429) throw new Error("Muitas análises ao mesmo tempo. Tente de novo em instantes.");
    throw new Error("A análise com IA falhou. Tente novamente mais tarde.");
  }
  const json = text.slice(text.indexOf("{"), text.lastIndexOf("}") + 1);
  const parsed = JSON.parse(json || "{}") as Partial<SyncReport>;
  return {
    summary: String(parsed.summary ?? "Sem conclusão."),
    explanation: String(parsed.explanation ?? ""),
    suggestedEntryShift: Math.max(-2, Math.min(2, Number(parsed.suggestedEntryShift) || 0)),
    issues: (Array.isArray(parsed.issues) ? parsed.issues : []).slice(0, 8).map((i) => ({
      start: Number(i.start) || 0,
      end: Number(i.end) || 0,
      offsetMs: Math.round(Number(i.offsetMs) || 0),
      note: String(i.note ?? ""),
    })),
  };
}
