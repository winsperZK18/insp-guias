export type Member = {
  id: string;
  email: string;
  display_name: string | null;
  avatar_url: string | null;
  role: string | null;
};

export type GuideComment = {
  id: string;
  guide_id: string;
  project_id: string;
  author_id: string;
  body: string;
  reply_to_id: string | null;
  mentions: string[];
  created_at: string;
};

export type ProjectMessage = {
  id: string;
  project_id: string;
  author_id: string;
  body: string;
  reply_to_id: string | null;
  mentions: string[];
  guide_refs: string[];
  created_at: string;
};

export type Reaction = {
  id: string;
  message_id?: string | null;
  comment_id: string | null;
  guide_id: string | null;
  user_id: string;
  emoji: string;
  created_at: string;
};

export type TrackTask = {
  id: string;
  project_id: string;
  title: string;
  position: number;
  done: boolean;
  done_by: string | null;
  done_at: string | null;
  created_at: string;
};

export type AuditLog = {
  id: string;
  actor_id: string | null;
  action: string;
  entity_type: string;
  entity_id: string | null;
  entity_label: string | null;
  details: Record<string, unknown>;
  created_at: string;
};

export const QUICK_EMOJIS = ["🔥", "🎤", "👏", "💯", "🔁", "❤️"];

export function memberName(member: Member | undefined, fallback = "Integrante") {
  if (!member) return fallback;
  return member.display_name?.trim() || member.email.split("@")[0] || fallback;
}
