export type ProjectStatus = "ideia" | "gravando" | "mixando" | "pronto";
export type GuideStatus = "novo_take" | "em_teste" | "regravar" | "fechada";
export type ReleaseKind = "single" | "ep" | "album";
export type AppRole = "admin" | "producer" | "member";
export type TrackSectionKind = "intro" | "verso" | "pre_refrao" | "refrao" | "ponte" | "final" | "personalizada";

export const PROJECT_STATUS_LABELS: Record<ProjectStatus, string> = {
  ideia: "Ideia",
  gravando: "Gravando",
  mixando: "Mixando",
  pronto: "Pronto",
};

export const GUIDE_STATUS_LABELS: Record<GuideStatus, string> = {
  novo_take: "Novo Take",
  em_teste: "Em Teste",
  regravar: "Regravar",
  fechada: "Guia Fechada",
};

export const REDO_REASONS = ["🎧 Vazou beat no microfone (gravar de fone)"];

export const RELEASE_KIND_LABELS: Record<ReleaseKind, string> = {
  single: "Avulsa (single)",
  ep: "EP",
  album: "Álbum",
};

export const PROJECT_STATUSES = Object.keys(PROJECT_STATUS_LABELS) as ProjectStatus[];
export const GUIDE_STATUSES = Object.keys(GUIDE_STATUS_LABELS) as GuideStatus[];
export const RELEASE_KINDS = Object.keys(RELEASE_KIND_LABELS) as ReleaseKind[];

export const TRACK_SECTION_LABELS: Record<TrackSectionKind, string> = {
  intro: "Intro",
  verso: "Verso",
  pre_refrao: "Pré-refrão",
  refrao: "Refrão",
  ponte: "Ponte",
  final: "Final",
  personalizada: "Outra parte",
};

export const TRACK_SECTION_KINDS = Object.keys(TRACK_SECTION_LABELS) as TrackSectionKind[];

export type Project = {
  id: string;
  title: string;
  status: ProjectStatus;
  bpm: number | null;
  musical_key: string | null;
  notes: string | null;
  release_kind: ReleaseKind;
  release_title: string | null;
  beat_path: string | null;
  beat_url: string | null;
  beat_file_name: string | null;
  beat_duration_seconds: number | null;
  preview_path: string | null;
  preview_url: string | null;
  preview_created_at: string | null;
  owner_id: string | null;
  group_id: string | null;
  parent_project_id: string | null;
  created_at: string;
};

export type Guide = {
  id: string;
  project_id: string;
  artist_name: string;
  part_label: string | null;
  status: GuideStatus;
  audio_path: string;
  audio_url: string;
  file_name: string | null;
  duration_seconds: number | null;
  processed_path: string | null;
  processed_url: string | null;
  detected_offset_seconds: number | null;
  entry_seconds: number;
  position: number;
  notes: string | null;
  owner_id: string | null;
  section_id: string | null;
  trim_start_seconds: number;
  trim_end_seconds: number | null;
  created_at: string;
};

export type TrackSection = {
  id: string;
  project_id: string;
  kind: TrackSectionKind;
  label: string;
  start_seconds: number;
  end_seconds: number;
  is_suggested: boolean;
  confidence: number | null;
  position: number;
  created_at: string;
};

export type ProjectInput = Partial<Omit<Project, "id" | "created_at">> & { title: string };
export type GuideInput = Partial<Omit<Guide, "id" | "created_at">> & {
  project_id: string;
  artist_name: string;
  audio_path: string;
  audio_url: string;
};
