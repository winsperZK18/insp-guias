/** FFT radix-2 in-place (arrays de tamanho potência de 2). */
export function fft(re: Float32Array, im: Float32Array, inverse = false) {
  const n = re.length;
  if (n <= 1) return;

  for (let i = 1, j = 0; i < n; i++) {
    let bit = n >> 1;
    for (; j & bit; bit >>= 1) j ^= bit;
    j ^= bit;
    if (i < j) {
      const reI = re[i] ?? 0;
      const imI = im[i] ?? 0;
      re[i] = re[j] ?? 0;
      re[j] = reI;
      im[i] = im[j] ?? 0;
      im[j] = imI;
    }
  }

  for (let len = 2; len <= n; len <<= 1) {
    const ang = ((inverse ? 2 : -2) * Math.PI) / len;
    const wRe = Math.cos(ang);
    const wIm = Math.sin(ang);
    for (let i = 0; i < n; i += len) {
      let curRe = 1;
      let curIm = 0;
      for (let k = 0; k < len / 2; k++) {
        const uRe = re[i + k] ?? 0;
        const uIm = im[i + k] ?? 0;
        const vRe = (re[i + k + len / 2] ?? 0) * curRe - (im[i + k + len / 2] ?? 0) * curIm;
        const vIm = (re[i + k + len / 2] ?? 0) * curIm + (im[i + k + len / 2] ?? 0) * curRe;
        re[i + k] = uRe + vRe;
        im[i + k] = uIm + vIm;
        re[i + k + len / 2] = uRe - vRe;
        im[i + k + len / 2] = uIm - vIm;
        const nextRe = curRe * wRe - curIm * wIm;
        curIm = curRe * wIm + curIm * wRe;
        curRe = nextRe;
      }
    }
  }

  if (inverse) {
    for (let i = 0; i < n; i++) {
      re[i] = (re[i] ?? 0) / n;
      im[i] = (im[i] ?? 0) / n;
    }
  }
}
