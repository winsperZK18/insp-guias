import { bufferToMono } from "../audio/decode";
import { energyEnvelope } from "./envelope";

const HOP_SECONDS = 0.01;

/** Detecta ataques (onsets) por fluxo positivo de energia. Tempos em segundos. */
function onsets(buffer: AudioBuffer, maxCount: number): number[] {
  const hop = Math.round(buffer.sampleRate * HOP_SECONDS);
  const env = energyEnvelope(bufferToMono(buffer), hop);
  const flux = new Float32Array(env.length);
  for (let i = 1; i < env.length; i++) flux[i] = Math.max(0, (env[i] ?? 0) - (env[i - 1] ?? 0));
  const out: { t: number; s: number }[] = [];
  const win = 15;
  for (let i = win; i < flux.length - win; i++) {
    let mean = 0;
    let isMax = true;
    for (let j = i - win; j <= i + win; j++) { mean += flux[j] ?? 0; if ((flux[j] ?? 0) > (flux[i] ?? 0)) isMax = false; }
    mean /= win * 2 + 1;
    if (isMax && (flux[i] ?? 0) > mean * 1.8 && (flux[i] ?? 0) > 0.002) out.push({ t: i * HOP_SECONDS, s: flux[i] ?? 0 });
  }
  return out.sort((a, b) => b.s - a.s).slice(0, maxCount).map((o) => Math.round(o.t * 100) / 100).sort((a, b) => a - b);
}

export type TimingFeatures = {
  bpm: number | null;
  entrySeconds: number;
  voiceDuration: number;
  beatOnsets: number[];
  voiceOnsets: number[];
};

/** Resumo numérico local (nenhum áudio sai do navegador) para a análise de sincronia. */
export function extractTimingFeatures(beat: AudioBuffer, voice: AudioBuffer, entrySeconds: number, bpm: number | null): TimingFeatures {
  const end = entrySeconds + voice.duration;
  return {
    bpm,
    entrySeconds,
    voiceDuration: Math.round(voice.duration * 100) / 100,
    beatOnsets: onsets(beat, 400).filter((t) => t >= entrySeconds - 2 && t <= end + 2),
    voiceOnsets: onsets(voice, 200).map((t) => Math.round((t + entrySeconds) * 100) / 100),
  };
}
