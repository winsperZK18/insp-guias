import { fft } from "./fft";

export const FRAME_SIZE = 2048;
export const HOP_SIZE = 512;

export function hannWindow(size: number): Float32Array {
  const w = new Float32Array(size);
  for (let i = 0; i < size; i++) w[i] = 0.5 - 0.5 * Math.cos((2 * Math.PI * i) / size);
  return w;
}

export type Frame = { re: Float32Array; im: Float32Array };

export function frameCount(length: number) {
  return Math.max(1, Math.ceil(length / HOP_SIZE));
}

export function analyzeFrame(signal: Float32Array, start: number, window: Float32Array): Frame {
  const re = new Float32Array(FRAME_SIZE);
  const im = new Float32Array(FRAME_SIZE);
  for (let i = 0; i < FRAME_SIZE; i++) {
    const idx = start + i;
    re[i] = (idx >= 0 && idx < signal.length ? (signal[idx] ?? 0) : 0) * (window[i] ?? 0);
  }
  fft(re, im);
  return { re, im };
}

export function synthesizeFrame(frame: Frame, out: Float32Array, norm: Float32Array, start: number, window: Float32Array) {
  fft(frame.re, frame.im, true);
  for (let i = 0; i < FRAME_SIZE; i++) {
    const idx = start + i;
    if (idx < 0 || idx >= out.length) continue;
    out[idx] = (out[idx] ?? 0) + (frame.re[i] ?? 0) * (window[i] ?? 0);
    norm[idx] = (norm[idx] ?? 0) + (window[i] ?? 0) * (window[i] ?? 0);
  }
}

export function finalizeOverlapAdd(out: Float32Array, norm: Float32Array) {
  for (let i = 0; i < out.length; i++) {
    if ((norm[i] ?? 0) > 1e-6) out[i] = (out[i] ?? 0) / (norm[i] ?? 1);
  }
}

/** Subtração espectral: reduz `magRef` de `frame`, com oversubtração e piso. */
export function spectralSubtract(
  frame: Frame,
  magRef: Float32Array,
  oversubtraction: number,
  floorFactor: number,
) {
  for (let k = 0; k < FRAME_SIZE; k++) {
    const re = frame.re[k] ?? 0;
    const im = frame.im[k] ?? 0;
    const mag = Math.hypot(re, im);
    if (mag < 1e-9) {
      frame.re[k] = 0;
      frame.im[k] = 0;
      continue;
    }
    const target = Math.max(mag - oversubtraction * (magRef[k] ?? 0), floorFactor * mag);
    const gain = target / mag;
    frame.re[k] = re * gain;
    frame.im[k] = im * gain;
  }
}

export function magnitudes(frame: Frame): Float32Array {
  const out = new Float32Array(FRAME_SIZE);
  for (let k = 0; k < FRAME_SIZE; k++) out[k] = Math.hypot(frame.re[k] ?? 0, frame.im[k] ?? 0);
  return out;
}
