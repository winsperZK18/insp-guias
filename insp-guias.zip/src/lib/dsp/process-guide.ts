import { bufferToMono, getAudioContext } from "../audio/decode";
import { estimateOffsetSeconds } from "./envelope";
import {
  FRAME_SIZE,
  HOP_SIZE,
  analyzeFrame,
  finalizeOverlapAdd,
  hannWindow,
  magnitudes,
  synthesizeFrame,
} from "./stft";

export type ProcessOptions = {
  /** Força da remoção do beat (1 = suave, 3 = agressivo). */
  strength?: number;
  /** Offset conhecido em segundos (pula a detecção). */
  offsetSeconds?: number | null;
  onProgress?: (ratio: number, label: string) => void;
};

export type ProcessResult = {
  buffer: AudioBuffer;
  offsetSeconds: number;
};

const HIGH_PASS_HZ = 90;

function percentile(values: number[], p: number) {
  if (!values.length) return 0;
  const sorted = [...values].sort((a, b) => a - b);
  const idx = Math.min(sorted.length - 1, Math.max(0, Math.floor(sorted.length * p)));
  return sorted[idx] ?? 0;
}

const nextTick = () => new Promise<void>((resolve) => setTimeout(resolve, 0));

/**
 * Alinha a guia ao beat, subtrai o espectro do beat, aplica piso de ruído
 * por bin e um high-pass leve. Devolve a voz aproximada.
 */
export async function processGuide(
  guideBuffer: AudioBuffer,
  beatBuffer: AudioBuffer | null,
  options: ProcessOptions = {},
): Promise<ProcessResult> {
  const { strength = 1.8, onProgress } = options;
  const sampleRate = guideBuffer.sampleRate;
  const guide = bufferToMono(guideBuffer);

  onProgress?.(0.05, "Analisando a guia");
  await nextTick();

  let beat: Float32Array | null = null;
  let offsetSeconds = options.offsetSeconds ?? 0;

  if (beatBuffer) {
    beat = bufferToMono(beatBuffer);
    if (beatBuffer.sampleRate !== sampleRate) {
      const ratio = beatBuffer.sampleRate / sampleRate;
      const resampled = new Float32Array(Math.floor(beat.length / ratio));
      for (let i = 0; i < resampled.length; i++) resampled[i] = beat[Math.floor(i * ratio)] ?? 0;
      beat = resampled;
    }
    if (options.offsetSeconds == null) {
      onProgress?.(0.15, "Alinhando com o beat");
      await nextTick();
      offsetSeconds = estimateOffsetSeconds(guide, beat, sampleRate);
    }
  }

  const offsetSamples = Math.round(offsetSeconds * sampleRate);
  const window = hannWindow(FRAME_SIZE);
  const out = new Float32Array(guide.length);
  const norm = new Float32Array(guide.length);
  const totalFrames = Math.ceil(guide.length / HOP_SIZE);

  // Piso de ruído por bin: percentil baixo das magnitudes da guia.
  onProgress?.(0.25, "Medindo o ruído de fundo");
  await nextTick();
  const sampleFrames = Math.min(totalFrames, 60);
  const perBin: number[][] = Array.from({ length: FRAME_SIZE }, () => []);
  for (let f = 0; f < sampleFrames; f++) {
    const start = Math.floor((f * (totalFrames - 1)) / Math.max(1, sampleFrames - 1)) * HOP_SIZE;
    const mag = magnitudes(analyzeFrame(guide, start, window));
    for (let k = 0; k < FRAME_SIZE; k++) perBin[k]?.push(mag[k] ?? 0);
  }
  const noiseFloor = new Float32Array(FRAME_SIZE);
  for (let k = 0; k < FRAME_SIZE; k++) noiseFloor[k] = percentile(perBin[k] ?? [], 0.12);

  const cutoffBin = Math.floor((HIGH_PASS_HZ * FRAME_SIZE) / sampleRate);

  // Faixa onde a voz mora: usada para medir quão alto o beat vazou no microfone.
  const lowBin = Math.max(1, Math.floor((150 * FRAME_SIZE) / sampleRate));
  const highBin = Math.floor((8000 * FRAME_SIZE) / sampleRate);
  const half = FRAME_SIZE / 2;
  let leak = 1; // escala do vazamento (celular grava o beat mais baixo/alto que o original)
  const prevMask = new Float32Array(half + 1).fill(1);

  for (let f = 0; f < totalFrames; f++) {
    const start = f * HOP_SIZE;
    const frame = analyzeFrame(guide, start, window);
    const mag = magnitudes(frame);

    const reference = new Float32Array(FRAME_SIZE);
    if (beat) {
      const beatMag = magnitudes(analyzeFrame(beat, start + offsetSamples, window));
      // Escala do vazamento por quadro (mínimos quadrados), suavizada no tempo.
      let gb = 0, bb = 0;
      for (let k = lowBin; k < highBin; k++) { gb += (mag[k] ?? 0) * (beatMag[k] ?? 0); bb += (beatMag[k] ?? 0) ** 2; }
      if (bb > 1e-9) leak = 0.85 * leak + 0.15 * Math.min(4, Math.max(0.05, gb / bb));
      for (let k = 0; k < FRAME_SIZE; k++) reference[k] = leak * (beatMag[k] ?? 0) + (noiseFloor[k] ?? 0);
    } else {
      reference.set(noiseFloor);
    }

    // Máscara tipo Wiener (subtração de potência), suavizada no tempo para evitar "chiado metálico".
    for (let k = 0; k <= half; k++) {
      const m = mag[k] ?? 0;
      const r = reference[k] ?? 0;
      let g = m < 1e-9 ? 0 : Math.max(0.015, 1 - (strength * r * r) / (m * m));
      g = Math.sqrt(g);
      g = 0.6 * g + 0.4 * Math.min(g * 1.5, prevMask[k] ?? 1);
      if (k < cutoffBin) g = 0;
      prevMask[k] = g;
      frame.re[k] = (frame.re[k] ?? 0) * g;
      frame.im[k] = (frame.im[k] ?? 0) * g;
      if (k > 0 && k < half) {
        const mk = FRAME_SIZE - k;
        frame.re[mk] = (frame.re[mk] ?? 0) * g;
        frame.im[mk] = (frame.im[mk] ?? 0) * g;
      }
    }

    synthesizeFrame(frame, out, norm, start, window);

    if (f % 40 === 0) {
      onProgress?.(0.3 + (0.6 * f) / totalFrames, "Limpando a voz");
      await nextTick();
    }
  }

  finalizeOverlapAdd(out, norm);

  // Portão de voz: abaixa o que sobrou do beat nos intervalos entre as frases.
  onProgress?.(0.93, "Tirando o resto do instrumental");
  await nextTick();
  const win = Math.max(1, Math.floor(sampleRate * 0.02));
  const blocks = Math.ceil(out.length / win);
  const rms = new Float32Array(blocks);
  for (let i = 0; i < blocks; i++) {
    let sum = 0; const s0 = i * win; const s1 = Math.min(out.length, s0 + win);
    for (let j = s0; j < s1; j++) sum += (out[j] ?? 0) ** 2;
    rms[i] = Math.sqrt(sum / Math.max(1, s1 - s0));
  }
  const threshold = Math.max(percentile(Array.from(rms), 0.35) * 1.8, percentile(Array.from(rms), 0.95) * 0.08);
  let env = 0;
  const gate = new Float32Array(blocks);
  for (let i = 0; i < blocks; i++) {
    const open = (rms[i] ?? 0) > threshold ? 1 : 0.08;
    env = open > env ? 0.6 * env + 0.4 * open : 0.9 * env + 0.1 * open; // abre rápido, fecha devagar
    gate[i] = env;
  }
  for (let i = 0; i < out.length; i++) {
    const p = i / win; const i0 = Math.floor(p); const t = p - i0;
    out[i] = (out[i] ?? 0) * ((gate[i0] ?? 1) * (1 - t) + (gate[i0 + 1] ?? gate[i0] ?? 1) * t);
  }

  let peak = 0;
  for (let i = 0; i < out.length; i++) peak = Math.max(peak, Math.abs(out[i] ?? 0));
  if (peak > 0) {
    const gain = Math.min(4, 0.95 / peak);
    for (let i = 0; i < out.length; i++) out[i] = (out[i] ?? 0) * gain;
  }

  const ctx = getAudioContext();
  const result = ctx.createBuffer(1, out.length, sampleRate);
  result.copyToChannel(out, 0);

  onProgress?.(1, "Pronto");
  return { buffer: result, offsetSeconds };
}
