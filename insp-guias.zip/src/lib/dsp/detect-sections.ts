import { bufferToMono } from "@/lib/audio/decode";

export type SuggestedSection = {
  startSeconds: number;
  endSeconds: number;
  confidence: number;
};

export function suggestChorusSections(buffer: AudioBuffer): SuggestedSection[] {
  const signal = bufferToMono(buffer);
  const windowSeconds = 8;
  const hopSeconds = 4;
  const windowSamples = Math.max(1, Math.round(windowSeconds * buffer.sampleRate));
  const hopSamples = Math.max(1, Math.round(hopSeconds * buffer.sampleRate));
  const windows: Float32Array[] = [];
  const energy: number[] = [];

  for (let start = 0; start + windowSamples <= signal.length; start += hopSamples) {
    const bins = new Float32Array(32);
    let sum = 0;
    for (let i = 0; i < windowSamples; i++) {
      const sample = signal[start + i] ?? 0;
      sum += sample * sample;
      const bin = Math.min(31, Math.floor((i / windowSamples) * 32));
      bins[bin] = (bins[bin] ?? 0) + Math.abs(sample);
    }
    let norm = 0;
    for (const value of bins) norm += value * value;
    norm = Math.sqrt(norm) || 1;
    for (let i = 0; i < bins.length; i++) bins[i] = (bins[i] ?? 0) / norm;
    windows.push(bins);
    energy.push(Math.sqrt(sum / windowSamples));
  }

  if (windows.length < 3) return [];
  const maxEnergy = Math.max(...energy, 0.0001);
  const candidates = windows.map((window, index) => {
    let repetition = 0;
    for (let other = 0; other < windows.length; other++) {
      if (Math.abs(other - index) < 2) continue;
      let score = 0;
      const comparison = windows[other];
      if (!comparison) continue;
      for (let bin = 0; bin < window.length; bin++) score += (window[bin] ?? 0) * (comparison[bin] ?? 0);
      repetition = Math.max(repetition, score);
    }
    return { index, score: 0.55 * ((energy[index] ?? 0) / maxEnergy) + 0.45 * repetition };
  }).sort((a, b) => b.score - a.score);

  const selected: SuggestedSection[] = [];
  for (const candidate of candidates) {
    const startSeconds = candidate.index * hopSeconds;
    if (selected.some((item) => Math.abs(item.startSeconds - startSeconds) < windowSeconds)) continue;
    selected.push({ startSeconds, endSeconds: Math.min(buffer.duration, startSeconds + windowSeconds), confidence: Math.min(0.95, candidate.score) });
    if (selected.length === 2) break;
  }
  return selected.sort((a, b) => a.startSeconds - b.startSeconds);
}