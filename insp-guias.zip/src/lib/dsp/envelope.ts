/** Envelope de energia (RMS) com janelas de `hop` amostras. */
export function energyEnvelope(signal: Float32Array, hop: number): Float32Array {
  const frames = Math.floor(signal.length / hop);
  const env = new Float32Array(Math.max(1, frames));
  for (let f = 0; f < frames; f++) {
    let sum = 0;
    const start = f * hop;
    for (let i = start; i < start + hop; i++) {
      const sample = signal[i] ?? 0;
      sum += sample * sample;
    }
    env[f] = Math.sqrt(sum / hop);
  }
  return env;
}

function normalize(input: Float32Array): Float32Array {
  let mean = 0;
  for (let i = 0; i < input.length; i++) mean += input[i] ?? 0;
  mean /= Math.max(1, input.length);
  const out = new Float32Array(input.length);
  let energy = 0;
  for (let i = 0; i < input.length; i++) {
    out[i] = (input[i] ?? 0) - mean;
    const value = out[i] ?? 0;
    energy += value * value;
  }
  const norm = Math.sqrt(energy) || 1;
  for (let i = 0; i < out.length; i++) out[i] = (out[i] ?? 0) / norm;
  return out;
}

/**
 * Estima em segundos o quanto a guia está adiantada/atrasada em relação ao beat,
 * por correlação cruzada normalizada dos envelopes.
 */
export function estimateOffsetSeconds(
  guide: Float32Array,
  beat: Float32Array,
  sampleRate: number,
  hop = 512,
  maxOffsetSeconds = 60,
): number {
  const a = normalize(energyEnvelope(guide, hop));
  const b = normalize(energyEnvelope(beat, hop));
  const maxLag = Math.min(Math.floor((maxOffsetSeconds * sampleRate) / hop), b.length - 1);
  let bestLag = 0;
  let bestScore = -Infinity;
  for (let lag = 0; lag <= maxLag; lag++) {
    let score = 0;
    const len = Math.min(a.length, b.length - lag);
    if (len < 8) break;
    for (let i = 0; i < len; i++) score += (a[i] ?? 0) * (b[i + lag] ?? 0);
    score /= Math.sqrt(len);
    if (score > bestScore) {
      bestScore = score;
      bestLag = lag;
    }
  }
  return (bestLag * hop) / sampleRate;
}
