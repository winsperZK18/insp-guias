import { createFileRoute, Outlet, redirect } from "@tanstack/react-router";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/_authenticated")({
  ssr: false,
  beforeLoad: async () => {
    const { data, error } = await supabase.auth.getUser();
    if (error || !data.user) throw redirect({ to: "/" });
    await supabase.rpc("claim_group_access", {
      _display_name: data.user.user_metadata?.['full_name'] ?? data.user.user_metadata?.['name'] ?? null,
      _avatar_url: data.user.user_metadata?.['avatar_url'] ?? null,
    });
    await supabase.rpc("claim_project_invites" as never);
    return { user: data.user };
  },
  component: () => <Outlet />,
});