import { createFileRoute } from "@tanstack/react-router";
import { AuditLogPage } from "@/pages/admin/audit-log-page";

export const Route = createFileRoute("/_authenticated/auditoria")({
  head: () => ({
    meta: [
      { title: "Histórico de alterações — INSP MUSIC" },
      { name: "description", content: "Registro de quem alterou projetos, guias e permissões na Central de Guias." },
      { property: "og:title", content: "Histórico de alterações — INSP MUSIC" },
      { property: "og:description", content: "Registro de quem alterou projetos, guias e permissões na Central de Guias." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: AuditLogPage,
});
