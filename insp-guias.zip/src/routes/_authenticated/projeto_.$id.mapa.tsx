import { createFileRoute } from "@tanstack/react-router";
import { MapPage } from "@/pages/project/map";

export const Route = createFileRoute("/_authenticated/projeto_/$id/mapa")({
  head: () => ({
    meta: [
      { title: "Mapa da faixa — INSP MUSIC" },
      { name: "description", content: "Monte os blocos da música, arraste as guias entre eles e baixe o MP3 final." },
      { property: "og:title", content: "Mapa da faixa — INSP MUSIC" },
      { property: "og:description", content: "Monte os blocos da música, arraste as guias entre eles e baixe o MP3 final." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: MapRoute,
});

function MapRoute() {
  const { id } = Route.useParams();
  return <MapPage id={id} />;
}
