import { createFileRoute } from "@tanstack/react-router";
import { ProjectPage } from "@/pages/project";

export const Route = createFileRoute("/_authenticated/projeto/$id")({
  head: () => ({
    meta: [
      { title: "Projeto de música — INSP MUSIC" },
      { name: "description", content: "Organize as guias, monte a ordem das vozes e gere a prévia da faixa." },
      { property: "og:title", content: "Projeto de música — INSP MUSIC" },
      { property: "og:description", content: "Organize as guias, monte a ordem das vozes e gere a prévia da faixa." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: ProjectRoute,
});

function ProjectRoute() {
  const { id } = Route.useParams();
  return <ProjectPage id={id} />;
}