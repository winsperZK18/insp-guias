import { createFileRoute } from "@tanstack/react-router";
import { HomePage } from "@/pages/home";

export const Route = createFileRoute("/_authenticated/central")({
  head: () => ({
    meta: [
      { title: "Central de Guias — INSP MUSIC" },
      { name: "description", content: "Organize beats, guias, responsáveis e versões das faixas do grupo." },
      { property: "og:title", content: "Central de Guias — INSP MUSIC" },
      { property: "og:description", content: "Organize beats, guias, responsáveis e versões das faixas do grupo." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: HomePage,
});