import { useEffect, useState } from "react";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { LoaderCircle, LockKeyhole } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { lovable } from "@/integrations/lovable";
import { supabase } from "@/integrations/supabase/client";
import { Wordmark } from "@/components/layout/wordmark";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Entrar na Central de Guias — INSP MUSIC" },
      { name: "description", content: "Crie sua conta, monte grupos e organize as guias das suas faixas." },
      { property: "og:title", content: "Entrar na Central de Guias — INSP MUSIC" },
      { property: "og:description", content: "Crie sua conta, monte grupos e organize as guias das suas faixas." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: SignInPage,
});

function SignInPage() {
  const navigate = useNavigate();
  const [busy, setBusy] = useState(true);

  useEffect(() => {
    let active = true;
    void (async () => {
      const { data } = await supabase.auth.getUser();
      if (!active) return;
      if (data.user) {
        await supabase.rpc("claim_group_access", {
          _display_name: data.user.user_metadata?.['full_name'] ?? data.user.user_metadata?.['name'] ?? null,
          _avatar_url: data.user.user_metadata?.['avatar_url'] ?? null,
        });
        await navigate({ to: "/central", replace: true });
        return;
      }
      setBusy(false);
    })();
    return () => { active = false; };
  }, [navigate]);

  async function signIn() {
    setBusy(true);
    const result = await lovable.auth.signInWithOAuth("google", {
      redirect_uri: window.location.origin,
      extraParams: { prompt: "select_account" },
    });
    if (result.error) {
      toast.error("Não foi possível entrar com o Google.");
      setBusy(false);
      return;
    }
    if (!result.redirected) window.location.reload();
  }

  return (
    <main className="grid min-h-screen place-items-center bg-background px-4">
      <section className="w-full max-w-md border border-border bg-card p-8 text-center shadow-elegant sm:p-10">
        <Wordmark className="block text-center text-6xl sm:text-7xl" />
        <p className="mt-7 text-xs font-semibold uppercase text-primary">Primeiro módulo</p>
        <h1 className="mt-2 text-5xl leading-none">CENTRAL DE GUIAS</h1>
        <p className="mx-auto mt-4 max-w-sm text-sm text-muted-foreground">Entre com sua conta Google. Você ganha um espaço particular, pode criar grupos e aceitar convites.</p>
        <Button className="mt-8 w-full" size="lg" variant="hero" onClick={signIn} disabled={busy}>
          {busy ? <LoaderCircle className="animate-spin" /> : <LockKeyhole />}
          {busy ? "Verificando acesso..." : "Entrar com Google"}
        </Button>
        <p className="mt-4 text-xs text-muted-foreground">Grátis para artistas, bandas e produtores.</p>
      </section>
    </main>
  );
}