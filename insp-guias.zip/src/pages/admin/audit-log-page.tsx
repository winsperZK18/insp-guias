import { useState } from "react";
import { AppHeader } from "@/components/layout/app-header";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useAccess } from "@/hooks/use-access";
import { useAuditLogs, type AuditFilters } from "@/hooks/use-audit-logs";
import { useMemberMap } from "@/hooks/use-members";
import { memberName } from "@/lib/chat-types";

const ENTITY_LABELS: Record<string, string> = {
  todos: "Tudo",
  projeto: "Projetos",
  guia: "Guias",
  integrante: "Permissões",
};

export function AuditLogPage() {
  const access = useAccess();
  const { data: members = [], map: memberById } = useMemberMap();
  const [filters, setFilters] = useState<AuditFilters>({ entityType: "todos", actorId: "todos", from: "", to: "" });
  const { data: logs = [], isLoading } = useAuditLogs(filters, access.isAdmin);

  if (!access.isLoading && !access.isAdmin) {
    return (
      <div className="min-h-screen">
        <AppHeader back />
        <main className="mx-auto max-w-2xl px-6 py-28 text-center">
          <h1 className="text-4xl">ÁREA DO ADMINISTRADOR</h1>
          <p className="mt-3 text-muted-foreground">Só o administrador do grupo pode ver o histórico de alterações.</p>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen">
      <AppHeader back />
      <main className="mx-auto max-w-5xl px-4 py-8 sm:px-6 sm:py-10">
        <p className="text-xs uppercase text-primary">Administração</p>
        <h1 className="mb-6 text-4xl">HISTÓRICO DE ALTERAÇÕES</h1>

        <div className="mb-6 grid gap-3 border border-border bg-card p-4 sm:grid-cols-4">
          <label className="space-y-1">
            <Label>O que</Label>
            <Select value={filters.entityType} onValueChange={(value) => setFilters((f) => ({ ...f, entityType: value }))}>
              <SelectTrigger className="h-11"><SelectValue /></SelectTrigger>
              <SelectContent>
                {Object.entries(ENTITY_LABELS).map(([value, label]) => <SelectItem key={value} value={value}>{label}</SelectItem>)}
              </SelectContent>
            </Select>
          </label>
          <label className="space-y-1">
            <Label>Quem</Label>
            <Select value={filters.actorId} onValueChange={(value) => setFilters((f) => ({ ...f, actorId: value }))}>
              <SelectTrigger className="h-11"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="todos">Todos</SelectItem>
                {members.map((member) => <SelectItem key={member.id} value={member.id}>{memberName(member)}</SelectItem>)}
              </SelectContent>
            </Select>
          </label>
          <label className="space-y-1">
            <Label>De</Label>
            <Input className="h-11" type="date" value={filters.from} onChange={(event) => setFilters((f) => ({ ...f, from: event.target.value }))} />
          </label>
          <label className="space-y-1">
            <Label>Até</Label>
            <Input className="h-11" type="date" value={filters.to} onChange={(event) => setFilters((f) => ({ ...f, to: event.target.value }))} />
          </label>
        </div>

        {isLoading && <p className="text-muted-foreground">Carregando histórico...</p>}
        {!isLoading && logs.length === 0 && <p className="text-muted-foreground">Nenhuma alteração registrada nesse filtro.</p>}

        <ul className="grid gap-2">
          {logs.map((log) => (
            <li key={log.id} className="border border-border bg-card p-3">
              <div className="flex flex-wrap items-center gap-2 text-sm">
                <span className="font-semibold">{log.actor_id ? memberName(memberById.get(log.actor_id)) : "Sistema"}</span>
                <span className="text-muted-foreground">{log.action}</span>
                <span className="text-xs uppercase text-primary">{log.entity_type}</span>
                <span className="truncate">{log.entity_label}</span>
                <span className="ml-auto text-xs text-muted-foreground">
                  {new Date(log.created_at).toLocaleString("pt-BR", { day: "2-digit", month: "2-digit", year: "2-digit", hour: "2-digit", minute: "2-digit" })}
                </span>
              </div>
            </li>
          ))}
        </ul>
      </main>
    </div>
  );
}
