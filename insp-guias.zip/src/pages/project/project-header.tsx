import { useNavigate } from "@tanstack/react-router";
import { Disc3, Edit3, Layers3, Music, Trash2, WandSparkles } from "lucide-react";
import { AudioPlayer } from "@/components/audio/audio-player";
import { ConfirmDeleteDialog } from "@/components/common/confirm-delete-dialog";
import { StatusBadge } from "@/components/common/status-badge";
import { Button } from "@/components/ui/button";
import { useAudioUrl } from "@/hooks/use-audio-url";
import { useDeleteProject } from "@/hooks/use-projects";
import type { Guide, Project } from "@/lib/types";
import { ProjectFormDialog } from "@/pages/home/project-form-dialog";

export function ProjectHeader({ project, guides, processing, canManage, onProcessAll }: { project: Project; guides: Guide[]; processing: boolean; canManage: boolean; onProcessAll: () => void }) {
  const beatUrl = useAudioUrl(project.beat_path);
  const remove = useDeleteProject();
  const navigate = useNavigate();

  return (
    <section className="border-b border-border bg-gradient-subtle">
      <div className="mx-auto max-w-7xl px-4 py-6 sm:px-6 sm:py-8">
        <div className="flex flex-col justify-between gap-5 lg:flex-row lg:items-start">
          <div className="min-w-0">
            <div className="mb-2 flex flex-wrap items-center gap-3">
              <StatusBadge status={project.status} />
              <span className="flex items-center gap-1 text-xs text-muted-foreground"><Disc3 className="size-3" /> {project.release_kind === "single" ? "Single" : project.release_title || project.release_kind}</span>
            </div>
            <h1 className="text-4xl leading-none sm:text-7xl">{project.title}</h1>
            <div className="mt-3 flex flex-wrap gap-5 text-sm">
              <span><b className="text-primary">{project.bpm ?? "—"}</b> BPM</span>
              <span><b className="text-primary">{project.musical_key ?? "—"}</b> Tom</span>
              <span><b className="text-primary">{guides.length}</b> Guias</span>
            </div>
            {project.notes && <p className="mt-3 max-w-2xl text-sm text-muted-foreground">{project.notes}</p>}
          </div>
          {canManage && (
            <div className="flex flex-wrap gap-2">
              <Button className="h-11" variant="hero" onClick={onProcessAll} disabled={processing || guides.length === 0}>
                <WandSparkles /> {processing ? "Processando..." : "Processar guias"}
              </Button>
              <ProjectFormDialog project={project} releaseSuggestions={[]} trigger={<Button className="h-11" variant="outline"><Edit3 /> Editar</Button>} />
              <ConfirmDeleteDialog
                title="Apagar este projeto?"
                description="Todas as guias e os dados da faixa serão apagados."
                onConfirm={() => remove.mutate(project, { onSuccess: () => navigate({ to: "/central" }) })}
                trigger={<Button size="icon" variant="ghost" className="size-11 text-destructive" aria-label="Apagar projeto"><Trash2 /></Button>}
              />
            </div>
          )}
        </div>
        <div className="mt-6 flex max-w-2xl items-center gap-3 border border-border bg-card p-3">
          {project.beat_path ? (
            <>
              <Music className="size-5 shrink-0 text-primary" />
              <div className="min-w-0 flex-1">
                <p className="mb-2 truncate text-xs text-muted-foreground">{project.beat_file_name || "Beat"}</p>
                <AudioPlayer src={beatUrl} />
              </div>
            </>
          ) : (
            <>
              <Layers3 className="size-5 text-muted-foreground" />
              <span className="text-sm text-muted-foreground">Nenhum beat enviado</span>
            </>
          )}
        </div>
      </div>
    </section>
  );
}
