import { useEffect, useState, type ReactNode } from "react";
import { toast } from "sonner";
import { AudioFileField } from "@/components/common/audio-file-field";
import { AudioRecorder } from "@/components/common/audio-recorder";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { useAccess } from "@/hooks/use-access";
import { useMemberMap } from "@/hooks/use-members";
import { useAudioUrl } from "@/hooks/use-audio-url";
import { useCreateGuide } from "@/hooks/use-guides";
import { decodeAudioBuffer } from "@/lib/audio/decode";
import { BASIC_PARTS } from "@/lib/bars";
import { formatDuration } from "@/lib/format";
import { uploadAudio } from "@/lib/storage";
import type { TrackSection } from "@/lib/types";

export function GuideFormDialog({
  projectId,
  nextPosition,
  sections = [],
  beatPath = null,
  defaultEntrySeconds = 0,
  trigger,
}: {
  projectId: string;
  nextPosition: number;
  sections?: TrackSection[];
  beatPath?: string | null;
  /** Onde a guia entra quando não tem parte escolhida: colada no fim do que já existe. */
  defaultEntrySeconds?: number;
  trigger: ReactNode;
}) {
  const [open, setOpen] = useState(false);
  const [artist, setArtist] = useState("");
  const [sectionId, setSectionId] = useState("livre");
  const [customPart, setCustomPart] = useState("");
  const [notes, setNotes] = useState("");
  const [file, setFile] = useState<File | null>(null);
  const [mode, setMode] = useState("gravar");
  const create = useCreateGuide(projectId);
  const beatUrl = useAudioUrl(beatPath);
  const access = useAccess();
  const { map } = useMemberMap();

  // Puxa o nome artístico do perfil de quem está enviando.
  useEffect(() => {
    if (!open || artist.trim()) return;
    const me = access.userId ? map.get(access.userId) : null;
    const name = me?.display_name?.trim() || me?.email?.split("@")[0] || "";
    if (name) setArtist(name);
  }, [open, access.userId, map, artist]);

  const submit = async () => {
    if (!artist.trim()) {
      toast.error("Informe quem gravou a guia.");
      return;
    }
    if (!file) {
      toast.error(mode === "gravar" ? "Grave a guia antes de enviar." : "Escolha o arquivo da guia.");
      return;
    }
    const section = sections.find((item) => item.id === sectionId) ?? null;
    const basicPart = sectionId.startsWith("parte:") ? sectionId.slice(6) : null;
    const newPart = sectionId === "nova" ? customPart.trim() : null;
    if (sectionId === "nova" && !newPart) {
      toast.error("Dê um nome para a parte nova.");
      return;
    }
    try {
      const path = await uploadAudio("guias", file, file.name);
      const duration = (await decodeAudioBuffer(file)).duration;
      await create.mutateAsync({
        project_id: projectId,
        artist_name: artist.trim(),
        part_label: section ? section.label : newPart ?? basicPart,
        section_id: section ? section.id : null,
        status: "novo_take",
        notes: notes.trim() || null,
        audio_path: path,
        audio_url: path,
        file_name: file.name,
        duration_seconds: duration,
        entry_seconds: section ? Number(section.start_seconds) : Math.max(0, Number(defaultEntrySeconds) || 0),
        position: nextPosition,
      });
      toast.success("Guia recebida.");
      setOpen(false);
      setSectionId("livre");
      setCustomPart("");
      setNotes("");
      setFile(null);
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Não foi possível enviar a guia.");
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>{trigger}</DialogTrigger>
      <DialogContent className="max-h-[92vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Enviar guia</DialogTitle>
          <DialogDescription>Grave aqui mesmo ou envie um MP3 gravado no celular.</DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-2">
          <label className="space-y-2">
            <Label>Quem gravou</Label>
            <Input className="h-11" value={artist} onChange={(e) => setArtist(e.target.value)} placeholder="Nome do artista" />
          </label>
          <label className="space-y-2">
            <Label>Onde você vai rimar</Label>
            <Select value={sectionId} onValueChange={setSectionId}>
              <SelectTrigger className="h-11"><SelectValue placeholder="Escolher parte" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="livre">Ainda não sei</SelectItem>
                {sections.map((section) => (
                  <SelectItem key={section.id} value={section.id}>
                    {section.label} · começa em {formatDuration(Number(section.start_seconds))}
                  </SelectItem>
                ))}
                {BASIC_PARTS.filter((part) => !sections.some((s) => s.label.toLowerCase() === part.toLowerCase())).map((part) => (
                  <SelectItem key={part} value={`parte:${part}`}>{part}</SelectItem>
                ))}
                <SelectItem value="nova">Criar outra parte...</SelectItem>
              </SelectContent>
            </Select>
            {sectionId === "nova" && (
              <Input className="h-11" value={customPart} onChange={(e) => setCustomPart(e.target.value)} placeholder="Ex.: Verso 4, Ponte 2, Interlúdio" />
            )}
            {sectionId !== "livre" && !sections.some((s) => s.id === sectionId) && (
              <p className="text-xs text-muted-foreground">Entra colada no fim do que já existe ({formatDuration(Math.max(0, Number(defaultEntrySeconds) || 0))}). Depois é só avançar ou voltar compassos.</p>
            )}
          </label>

          <Tabs value={mode} onValueChange={(value) => { setMode(value); setFile(null); }}>
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="gravar" className="h-10">Gravar agora</TabsTrigger>
              <TabsTrigger value="arquivo" className="h-10">Enviar arquivo</TabsTrigger>
            </TabsList>
            <TabsContent value="gravar" className="mt-3">
              <AudioRecorder beatUrl={beatUrl} onRecorded={setFile} />
            </TabsContent>
            <TabsContent value="arquivo" className="mt-3">
              <AudioFileField value={file} onChange={setFile} label="Áudio da guia" />
            </TabsContent>
          </Tabs>

          <label className="space-y-2">
            <Label>Observações</Label>
            <Textarea value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="O que precisa ser ouvido ou revisado?" />
          </label>
        </div>
        <DialogFooter className="gap-2">
          <Button className="h-11" variant="outline" onClick={() => setOpen(false)}>Cancelar</Button>
          <Button className="h-11" variant="hero" disabled={create.isPending} onClick={submit}>{create.isPending ? "Enviando..." : "Enviar guia"}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
