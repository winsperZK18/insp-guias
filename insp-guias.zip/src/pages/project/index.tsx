import { useEffect } from "react";
import { Link } from "@tanstack/react-router";
import { Map as MapIcon, Plus } from "lucide-react";
import { setCurrentGroupId } from "@/hooks/use-groups";
import { AppHeader } from "@/components/layout/app-header";
import { Button } from "@/components/ui/button";
import { useAccess } from "@/hooks/use-access";
import { useGuides } from "@/hooks/use-guides";
import { useGuideProcessing } from "@/hooks/use-guide-processing";
import { useProject } from "@/hooks/use-projects";
import { GuideFormDialog } from "./guide-form-dialog";
import { GuideList } from "./guide-list";
import { useTrackSections } from "@/hooks/use-track-sections";
import { ProjectChat } from "@/components/chat/project-chat";
import { ProjectHeader } from "./project-header";
import { TrackGuests } from "./track-guests";

export function ProjectPage({ id }: { id: string }) {
  const { data: project, isLoading } = useProject(id);
  const { data: guides = [] } = useGuides(id);
  const { data: sections = [] } = useTrackSections(id);
  const access = useAccess();
  const processor = useGuideProcessing(project);
  useEffect(() => { if (project?.group_id) setCurrentGroupId(project.group_id); }, [project?.group_id]);

  if (isLoading) {
    return <div className="min-h-screen"><AppHeader back /><div className="py-32 text-center text-muted-foreground">Carregando projeto...</div></div>;
  }
  if (!project) {
    return (
      <div className="min-h-screen">
        <AppHeader back />
        <main className="mx-auto max-w-2xl px-6 py-28 text-center">
          <h1 className="text-5xl">PROJETO NÃO ENCONTRADO</h1>
          <p className="mt-3 text-muted-foreground">Esse projeto não existe ou foi apagado.</p>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen">
      <AppHeader back />
      <ProjectHeader
        project={project}
        guides={guides}
        processing={processor.isProcessing}
        canManage={access.canManageProjects}
        onProcessAll={() => processor.processAll(guides)}
      />
      <main className="mx-auto grid max-w-7xl grid-cols-[minmax(0,1fr)] gap-8 px-4 pb-28 pt-8 sm:px-6 sm:pt-10 lg:pb-10">
        <Link to="/projeto/$id/mapa" params={{ id: project.id }} className="flex items-center justify-between gap-3 border border-primary/50 bg-card p-4 transition-colors hover:border-primary">
          <span className="flex items-center gap-3"><MapIcon className="text-primary" /><span><strong className="block text-xl">MAPA DA FAIXA</strong><span className="text-xs text-muted-foreground">{sections.length ? `${sections.length} blocos` : "Monte intro, versos, refrãos e pontes"} · arraste as guias · MP3 final</span></span></span>
          <span className="text-sm font-semibold text-primary">Abrir</span>
        </Link>

        <GuideList
          guides={guides}
          projectId={project.id}
          processing={processor.state}
          sections={sections}
          canManage={access.canManageProjects}
          userId={access.userId}
          beatPath={project.beat_path}
          projectTitle={project.title}
          bpm={project.bpm}
          onProcess={processor.process}
        />

        <ProjectChat projectId={project.id} guides={guides} />

        {access.canManageProjects && <TrackGuests projectId={project.id} />}

      </main>

      <div className="fixed inset-x-0 bottom-0 z-30 border-t border-border bg-background/95 p-3 backdrop-blur lg:hidden">
        <GuideFormDialog
          projectId={project.id}
          nextPosition={guides.length}
          sections={sections}
          beatPath={project.beat_path}
          defaultEntrySeconds={guides.reduce((end, g) => Math.max(end, (Number(g.entry_seconds) || 0) + (Number(g.duration_seconds) || 0)), 0)}
          trigger={<Button variant="hero" className="h-12 w-full"><Plus /> Enviar guia</Button>}
        />
      </div>
    </div>
  );
}
