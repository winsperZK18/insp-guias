import { useState } from "react";
import { Download, Headphones, Mic2, Plus } from "lucide-react";
import { FullGuidePanel } from "@/components/audio/full-guide-panel";
import { useCanUseTimeline } from "@/hooks/use-timeline-access";
import { toast } from "sonner";
import { ProgressField } from "@/components/common/progress-field";
import { exportMixMp3 } from "@/lib/audio/export-mix";
import { EmptyState } from "@/components/common/empty-state";
import { Button } from "@/components/ui/button";
import type { ProcessingState } from "@/hooks/use-guide-processing";
import { useReorderGuides } from "@/hooks/use-guides";
import { useMarkTesting } from "@/hooks/use-guide-status";
import type { Guide, TrackSection } from "@/lib/types";
import { GuideFormDialog } from "./guide-form-dialog";
import { GuideItem } from "./guide-item";

export function GuideList({
  guides,
  projectId,
  processing,
  sections,
  canManage,
  userId,
  beatPath = null,
  projectTitle = "faixa",
  bpm = null,
  onProcess,
}: {
  bpm?: number | null;
  projectTitle?: string;
  guides: Guide[];
  projectId: string;
  processing: ProcessingState;
  sections: TrackSection[];
  canManage: boolean;
  userId: string | null;
  beatPath?: string | null;
  onProcess: (guide: Guide, options?: { strength?: number; offsetSeconds?: number | null }) => void;
}) {
  const reorder = useReorderGuides(projectId);
  const canTimeline = useCanUseTimeline();
  const markTesting = useMarkTesting(projectId, canManage);
  const [fullOpen, setFullOpen] = useState(false);
  const [exporting, setExporting] = useState<{ ratio: number; label: string } | null>(null);
  // Nova guia entra colada no fim do que já foi enviado.
  const nextEntry = guides.reduce((end, g) => Math.max(end, (Number(g.entry_seconds) || 0) + (Number(g.duration_seconds) || 0)), 0);
  const exportAll = async () => {
    try {
      await exportMixMp3(projectTitle, beatPath, guides, { onProgress: (ratio, label) => setExporting({ ratio, label }) });
      toast.success("Mix completo baixado.");
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Não deu para gerar o mix.");
    } finally {
      setExporting(null);
    }
  };
  // Trocar a ordem também troca o lugar das vozes na música (tempos em cascata).
  const move = (index: number, direction: -1 | 1) => {
    const next = index + direction;
    if (next < 0 || next >= guides.length) return;
    const current = guides[index];
    const target = guides[next];
    if (!current || !target) return;
    reorder.mutate([
      { id: current.id, position: target.position, entry_seconds: Number(target.entry_seconds) || 0 },
      { id: target.id, position: current.position, entry_seconds: Number(current.entry_seconds) || 0 },
    ]);
  };

  return (
    <section>
      <div className="mb-4 grid grid-cols-[minmax(0,1fr)_auto] items-end gap-3">
        <div className="min-w-0">
          <p className="text-xs uppercase text-primary">Vozes recebidas</p>
          <h2 className="text-3xl">GUIAS DA FAIXA</h2>
        </div>
        {guides.length > 0 && (
          <div className="flex gap-2">
          <Button variant="outline" className="h-11" disabled={Boolean(exporting)} onClick={exportAll}><Download /> <span className="hidden sm:inline">Baixar mix completo</span><span className="sm:hidden">Mix</span></Button>
          <GuideFormDialog projectId={projectId} nextPosition={guides.length} sections={sections} beatPath={beatPath} defaultEntrySeconds={nextEntry} trigger={<Button className="h-11"><Plus /> Enviar</Button>} />
          </div>
        )}
      </div>
      {exporting && <div className="mb-4"><ProgressField value={exporting.ratio} label={exporting.label} /></div>}
      {guides.length === 0 ? (
        <GuideFormDialog
          projectId={projectId}
          nextPosition={0}
          sections={sections}
          beatPath={beatPath}
          trigger={<span className="block"><EmptyState icon={Mic2} title="Nenhuma guia ainda" description="Envie o primeiro verso para começar a montar a faixa." action="Enviar guia" onAction={() => {}} /></span>}
        />
      ) : (
        <div className="space-y-3 pb-20 lg:pb-0">
          {guides.map((guide, i) => (
            <GuideItem
              key={guide.id}
              guide={guide}
              projectId={projectId}
              processing={processing}
              sections={sections}
              canManage={canManage}
              canEditOwn={Boolean(userId && guide.owner_id === userId && guide.status !== "fechada")}
              onProcess={onProcess}
              onMove={(direction) => move(i, direction)}
            />
          ))}
          <Button variant={fullOpen ? "hero" : "secondary"} className="h-12 w-full" onClick={() => setFullOpen((v) => { if (!v) markTesting(guides); return !v; })}><Headphones /> {fullOpen ? "Fechar guia completa" : "Ouvir toda a guia com o beat"}</Button>
          {fullOpen && (
            <FullGuidePanel
              guides={guides}
              beatPath={beatPath}
              bpm={bpm}
              title={projectTitle}
              canAdjust={canManage || canTimeline}
              userId={userId}
              onSave={(updates) => reorder.mutate(updates, { onSuccess: () => toast.success("Ajustes da guia completa salvos.") })}
            />
          )}
        </div>
      )}
    </section>
  );
}
