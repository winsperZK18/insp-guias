import { WandSparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { MAPPING_PRESETS } from "@/lib/mapping-presets";
import type { Guide } from "@/lib/types";

export function MappingPresetsMenu({ guides, onApply }: { guides: Guide[]; onApply: (updates: { id: string; entry_seconds: number; position: number }[]) => void }) {
  return <DropdownMenu><DropdownMenuTrigger asChild><Button size="sm" variant="outline"><WandSparkles /> Presets</Button></DropdownMenuTrigger><DropdownMenuContent align="end" className="w-64">{MAPPING_PRESETS.map((preset) => <DropdownMenuItem key={preset.id} className="block py-2" onClick={() => onApply(preset.build(guides))}><strong className="block text-sm">{preset.label}</strong><span className="text-xs text-muted-foreground">{preset.description}</span></DropdownMenuItem>)}</DropdownMenuContent></DropdownMenu>;
}