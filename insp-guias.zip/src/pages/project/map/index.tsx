import { useEffect, useMemo, useState } from "react";
import { Link } from "@tanstack/react-router";
import { ArrowDown, ArrowLeft, ArrowUp, Download, GripVertical, Magnet, Pause, Play, Plus, Trash2, Wand2 } from "lucide-react";
import { toast } from "sonner";
import { AppHeader } from "@/components/layout/app-header";
import { WaveformCanvas } from "@/components/audio/waveform-canvas";
import { ProgressField } from "@/components/common/progress-field";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useAccess } from "@/hooks/use-access";
import { useGuides, useReorderGuides } from "@/hooks/use-guides";
import { useMultiLiveMix } from "@/hooks/use-multi-live-mix";
import { useProject } from "@/hooks/use-projects";
import { setCurrentGroupId } from "@/hooks/use-groups";
import { useSaveTrackSections, useTrackSections, type SectionDraft } from "@/hooks/use-track-sections";
import { loadAudioBuffer } from "@/lib/audio/buffer-cache";
import { exportMixMp3 } from "@/lib/audio/export-mix";
import { STRUCTURE_PRESETS, barLabel, barsToSeconds, secondsPerBar, secondsPerBeat } from "@/lib/bars";
import { formatTimelineTime } from "@/lib/format";
import { cn } from "@/lib/utils";
import type { Guide, TrackSection, TrackSectionKind } from "@/lib/types";
import { MappingPresetsMenu } from "../timeline/mapping-presets-menu";

type Block = { id?: string | undefined; kind: string; label: string; bars: number };
const KINDS: { kind: TrackSectionKind; label: string }[] = [
  { kind: "intro", label: "Intro" }, { kind: "verso", label: "Verso" }, { kind: "refrao", label: "Refrão" },
  { kind: "ponte", label: "Ponte" }, { kind: "personalizada", label: "Interlúdio" }, { kind: "final", label: "Final" },
];

export function MapPage({ id }: { id: string }) {
  const { data: project } = useProject(id);
  const { data: guides = [] } = useGuides(id);
  const { data: sections = [] } = useTrackSections(id);
  const access = useAccess();
  const save = useSaveTrackSections(id);
  const reorder = useReorderGuides(id);
  const [beat, setBeat] = useState<AudioBuffer | null>(null);
  const [dragOver, setDragOver] = useState<string | null>(null);
  const [exporting, setExporting] = useState<{ ratio: number; label: string } | null>(null);
  const bpm = project?.bpm ?? null;
  const bar = secondsPerBar(bpm);
  const canManage = access.canManageProjects;
  const voices = useMemo(() => guides.map((g) => ({ id: g.id, path: g.processed_path ?? g.audio_path })), [guides]);
  const mix = useMultiLiveMix(project?.beat_path, voices);
  useEffect(() => {
    for (const g of guides) mix.setLayer(g.id, { entry: Number(g.entry_seconds) || 0, trimStart: Number(g.trim_start_seconds) || 0, trimEnd: g.trim_end_seconds == null ? null : Number(g.trim_end_seconds), gain: 1, muted: false });
  }, [guides, mix.setLayer]); // eslint-disable-line react-hooks/exhaustive-deps
  const playFrom = (t: number) => void mix.play(Math.max(0, t));
  const seekAt = (e: React.PointerEvent<HTMLDivElement>, total: number) => {
    const r = e.currentTarget.getBoundingClientRect();
    const t = Math.min(total, Math.max(0, ((e.clientX - r.left) / r.width) * total));
    if (mix.playing) mix.seek(t); else mix.seek(t);
  };

  useEffect(() => { if (project?.group_id) setCurrentGroupId(project.group_id); }, [project?.group_id]);
  useEffect(() => { let on = true; if (project?.beat_path) loadAudioBuffer(project.beat_path).then((b) => on && setBeat(b)).catch(() => {}); return () => { on = false; }; }, [project?.beat_path]);

  const blocks: Block[] = useMemo(() => sections.map((s) => ({ id: s.id, kind: s.kind, label: s.label, bars: Math.max(1, Math.round((Number(s.end_seconds) - Number(s.start_seconds)) / bar)) })), [sections, bar]);
  const byId = useMemo(() => new Map(sections.map((s) => [s.id, s])), [sections]);

  /** Salva blocos e leva junto as guias de cada bloco (mantém a distância para o começo do bloco). */
  const persist = async (next: Block[]) => {
    let cursor = 0;
    const rows: SectionDraft[] = next.map((b, position) => {
      const start = barsToSeconds(cursor, bpm); cursor += b.bars;
      return { id: b.id, project_id: id, kind: b.kind as TrackSectionKind, label: b.label.trim() || "Parte", start_seconds: +start.toFixed(3), end_seconds: +barsToSeconds(cursor, bpm).toFixed(3), is_suggested: false, confidence: null, position };
    });
    const keep = new Set(next.map((b) => b.id).filter(Boolean));
    const removed = sections.filter((s) => !keep.has(s.id)).map((s) => s.id);
    try {
      await save.mutateAsync({ blocks: rows, removed });
      const moves = guides.flatMap((g) => {
        const old = g.section_id ? byId.get(g.section_id) : null;
        const row = rows.find((r) => r.id && r.id === g.section_id);
        if (!old || !row || row.start_seconds === Number(old.start_seconds)) return [];
        return [{ id: g.id, entry_seconds: +Math.max(0, row.start_seconds + (Number(g.entry_seconds) - Number(old.start_seconds))).toFixed(3) }];
      });
      if (moves.length) reorder.mutate(moves);
    } catch (e) { toast.error(e instanceof Error ? e.message : "Não deu para salvar os blocos."); }
  };

  const edit = (i: number, patch: Partial<Block>) => persist(blocks.map((b, j) => (j === i ? { ...b, ...patch } : b)));
  const moveBlock = (i: number, d: -1 | 1) => { const n = [...blocks]; const t = i + d; if (t < 0 || t >= n.length) return; [n[i], n[t]] = [n[t]!, n[i]!]; void persist(n); };
  const addBlock = (kind: TrackSectionKind, label: string) => {
    const count = blocks.filter((b) => b.label.startsWith(label)).length;
    void persist([...blocks, { kind, label: count ? `${label} ${count + 1}` : label, bars: kind === "verso" ? 16 : kind === "refrao" ? 8 : 4 }]);
  };

  const placeIn = (guide: Guide, section: TrackSection | null) => {
    reorder.mutate([{ id: guide.id, section_id: section?.id ?? null, ...(section ? { entry_seconds: Number(section.start_seconds), part_label: section.label } : {}) } as any]);
  };
  const swap = (a: Guide, b: Guide) => {
    if (a.id === b.id) return;
    reorder.mutate([
      { id: a.id, section_id: b.section_id, entry_seconds: Number(b.entry_seconds), position: b.position, part_label: b.part_label } as any,
      { id: b.id, section_id: a.section_id, entry_seconds: Number(a.entry_seconds), position: a.position, part_label: a.part_label } as any,
    ]);
    toast.success(`${a.artist_name} ⇄ ${b.artist_name}`);
  };
  const nudge = (g: Guide, d: number) => reorder.mutate([{ id: g.id, entry_seconds: +Math.max(0, Number(g.entry_seconds) + d).toFixed(3) }]);
  const snapAll = () => reorder.mutate(guides.filter((g) => g.section_id && byId.get(g.section_id)).map((g) => ({ id: g.id, entry_seconds: Number(byId.get(g.section_id!)!.start_seconds) })));
  const dropOn = (e: React.DragEvent, onSection: TrackSection | null, onGuide?: Guide) => {
    e.preventDefault(); e.stopPropagation(); setDragOver(null);
    const g = guides.find((x) => x.id === e.dataTransfer.getData("text/guide"));
    if (!g) return;
    if (onGuide) swap(g, onGuide); else placeIn(g, onSection);
  };

  const exportAll = async () => {
    if (!project) return;
    try { await exportMixMp3(project.title, project.beat_path, guides, { onProgress: (ratio, label) => setExporting({ ratio, label }) }); toast.success("MP3 final baixado."); }
    catch (e) { toast.error(e instanceof Error ? e.message : "Não deu para gerar o MP3."); }
    finally { setExporting(null); }
  };

  if (!project) return <div className="min-h-screen"><AppHeader back /><p className="py-32 text-center text-muted-foreground">Carregando mapa...</p></div>;

  const total = Math.max(beat?.duration ?? project.beat_duration_seconds ?? 60, ...guides.map((g) => Number(g.entry_seconds) + Number(g.duration_seconds ?? 10)), barsToSeconds(blocks.reduce((s, b) => s + b.bars, 0), bpm));
  const pct = (s: number) => `${(s / total) * 100}%`;
  const loose = guides.filter((g) => !g.section_id || !byId.has(g.section_id));

  const GuideCard = ({ g }: { g: Guide }) => (
    <div
      draggable={canManage}
      onDragStart={(e) => e.dataTransfer.setData("text/guide", g.id)}
      onDragOver={(e) => canManage && e.preventDefault()}
      onDrop={(e) => dropOn(e, null, g)}
      className="flex flex-wrap items-center gap-1 border border-primary/50 bg-primary/10 p-2 text-sm"
    >
      {canManage && <GripVertical className="size-4 shrink-0 cursor-grab text-muted-foreground" />}
      <div className="min-w-0 flex-1"><strong className="block truncate">{g.artist_name}</strong><span className="text-[11px] text-muted-foreground">{barLabel(Number(g.entry_seconds), bpm)}</span></div>
      {canManage && (
        <div className="flex flex-wrap items-center gap-1">
          <Button size="sm" variant="ghost" className="h-9 px-2 text-xs" onClick={() => nudge(g, -bar)}>−comp.</Button>
          <Button size="sm" variant="ghost" className="h-9 px-2 text-xs" onClick={() => nudge(g, -secondsPerBeat(bpm))}>−tempo</Button>
          <Button size="sm" variant="ghost" className="h-9 px-2 text-xs" onClick={() => nudge(g, secondsPerBeat(bpm))}>+tempo</Button>
          <Button size="sm" variant="ghost" className="h-9 px-2 text-xs" onClick={() => nudge(g, bar)}>+comp.</Button>
          <Select value={g.section_id ?? "none"} onValueChange={(v) => placeIn(g, v === "none" ? null : byId.get(v) ?? null)}>
            <SelectTrigger className="h-9 w-32 text-xs" aria-label="Mover para bloco"><SelectValue placeholder="Mover para" /></SelectTrigger>
            <SelectContent><SelectItem value="none">Sem bloco</SelectItem>{sections.map((s) => <SelectItem key={s.id} value={s.id}>{s.label}</SelectItem>)}</SelectContent>
          </Select>
        </div>
      )}
    </div>
  );

  return (
    <div className="min-h-screen">
      <AppHeader back />
      <main className="mx-auto max-w-6xl space-y-6 px-4 py-6 sm:px-6">
        <div className="flex flex-wrap items-end justify-between gap-3">
          <div>
            <Link to="/projeto/$id" params={{ id }} className="mb-1 flex items-center gap-1 text-xs uppercase text-primary"><ArrowLeft className="size-3" /> {project.title}</Link>
            <h1 className="text-4xl">MAPA DA FAIXA</h1>
            <p className="text-xs text-muted-foreground">{bpm ?? 90} BPM · 1 compasso = {bar.toFixed(2)}s{canManage && " · arraste as guias entre os blocos ou solte uma guia sobre outra para trocar de lugar"}</p>
          </div>
          <div className="flex flex-wrap gap-2">
            <Button variant="secondary" className="h-11" onClick={() => (mix.playing ? mix.stop() : playFrom(mix.time))}>{mix.playing ? <Pause /> : <Play />} {mix.playing ? "Pausar" : "Tocar"}</Button>
            {canManage && guides.length > 1 && <MappingPresetsMenu guides={guides} onApply={(u) => reorder.mutate(u)} />}
            <Button variant="hero" className="h-11" disabled={Boolean(exporting) || !guides.length} onClick={exportAll}><Download /> Baixar MP3 final</Button>
          </div>
        </div>
        {exporting && <ProgressField value={exporting.ratio} label={exporting.label} />}

        {/* Visão geral */}
        <div className="sticky top-0 z-20 flex items-center gap-3 border border-primary/50 bg-background/95 px-3 py-2 backdrop-blur">
          <Button size="icon" variant="hero" className="size-11" onClick={() => (mix.playing ? mix.stop() : playFrom(mix.time))} aria-label={mix.playing ? "Pausar" : "Tocar"}>{mix.playing ? <Pause /> : <Play />}</Button>
          <div className="text-sm"><strong className="block text-lg leading-none">{formatTimelineTime(mix.time)}</strong><span className="text-[11px] uppercase text-muted-foreground">{barLabel(mix.time, bpm)}{sections.find((s) => mix.time >= Number(s.start_seconds) && mix.time < Number(s.end_seconds)) ? ` · ${sections.find((s) => mix.time >= Number(s.start_seconds) && mix.time < Number(s.end_seconds))!.label}` : ""}</span></div>
          <div className="ml-auto flex gap-1">
            <Button size="sm" variant="outline" className="h-10" onClick={() => mix.seek(Math.max(0, mix.time - bar))}>−1 comp.</Button>
            <Button size="sm" variant="outline" className="h-10" onClick={() => mix.seek(mix.time + bar)}>+1 comp.</Button>
          </div>
        </div>
        <div className="relative touch-none select-none border border-border" onPointerDown={(e) => { e.currentTarget.setPointerCapture(e.pointerId); seekAt(e, total); }} onPointerMove={(e) => { if (e.buttons) seekAt(e, total); }}>
          <div className="pointer-events-none absolute inset-y-0 z-10 w-0.5 bg-primary shadow-[0_0_8px_hsl(var(--primary))]" style={{ left: pct(Math.min(mix.time, total)) }} />
          <div className="relative h-14 bg-muted/30"><WaveformCanvas buffer={beat} className="opacity-70" /></div>
          <div className="relative h-7 border-y border-border">
            {sections.map((s, i) => <div key={s.id} className={cn("absolute inset-y-0 truncate border-r border-background px-1 text-[10px] uppercase leading-7", i % 2 ? "bg-secondary/40" : "bg-accent/30")} style={{ left: pct(Number(s.start_seconds)), width: pct(Number(s.end_seconds) - Number(s.start_seconds)) }}>{s.label}</div>)}
          </div>
          <div className="relative bg-muted/10" style={{ height: Math.max(40, guides.length * 20 + 8) }}>
            {guides.map((g, i) => <div key={g.id} className="absolute h-4 truncate border border-primary bg-primary/30 px-1 text-[10px] leading-4" style={{ top: 4 + i * 20, left: pct(Number(g.entry_seconds) + Number(g.trim_start_seconds || 0)), width: pct(Math.max(1, (g.trim_end_seconds ?? Number(g.duration_seconds ?? 10)) - Number(g.trim_start_seconds || 0))) }}>{g.artist_name}</div>)}
          </div>
          <div className="flex justify-between px-2 py-1 text-[10px] text-muted-foreground"><span>0:00</span><span>{formatTimelineTime(total)}</span></div>
        </div>

        {canManage && (
          <div className="flex flex-wrap gap-2">
            {blocks.length === 0 && STRUCTURE_PRESETS.map((p) => <Button key={p.id} variant="outline" className="h-10" onClick={() => persist(p.blocks.map((b) => ({ ...b })))}><Wand2 /> {p.name}</Button>)}
            {KINDS.map((k) => <Button key={k.kind + k.label} variant="outline" className="h-10" onClick={() => addBlock(k.kind, k.label)}><Plus /> {k.label}</Button>)}
            {guides.some((g) => g.section_id) && <Button variant="secondary" className="h-10" onClick={snapAll}><Magnet /> Encaixar tudo no início dos blocos</Button>}
          </div>
        )}

        <div className="space-y-3">
          {sections.map((s, i) => {
            const inside = guides.filter((g) => g.section_id === s.id);
            const b = blocks[i]!;
            return (
              <section key={s.id} onDragOver={(e) => { if (canManage) { e.preventDefault(); setDragOver(s.id); } }} onDragLeave={() => setDragOver(null)} onDrop={(e) => dropOn(e, s)}
                className={cn("border bg-card p-3", dragOver === s.id || (mix.playing && mix.time >= Number(s.start_seconds) && mix.time < Number(s.end_seconds)) ? "border-primary" : "border-border")}>
                <div className="mb-2 flex flex-wrap items-center gap-2">
                  <Button size="icon" variant="secondary" className="size-10 shrink-0" onClick={() => playFrom(Number(s.start_seconds))} aria-label={`Tocar a partir de ${s.label}`}><Play /></Button>
                  {canManage ? <Input className="h-10 w-40" defaultValue={s.label} onBlur={(e) => e.target.value !== s.label && edit(i, { label: e.target.value })} aria-label="Nome do bloco" /> : <h2 className="text-xl">{s.label}</h2>}
                  <span className="text-xs text-muted-foreground">começa no compasso {Math.round(Number(s.start_seconds) / bar) + 1} · {formatTimelineTime(Number(s.start_seconds))}</span>
                  {canManage && (
                    <div className="ml-auto flex items-center gap-1">
                      <Button size="icon" variant="outline" className="size-9" onClick={() => edit(i, { bars: Math.max(1, b.bars - 1) })} aria-label="Menos um compasso">−</Button>
                      <span className="w-16 text-center text-sm">{b.bars} comp.</span>
                      <Button size="icon" variant="outline" className="size-9" onClick={() => edit(i, { bars: b.bars + 1 })} aria-label="Mais um compasso">+</Button>
                      <Button size="icon" variant="ghost" className="size-9" onClick={() => moveBlock(i, -1)} aria-label="Subir bloco"><ArrowUp /></Button>
                      <Button size="icon" variant="ghost" className="size-9" onClick={() => moveBlock(i, 1)} aria-label="Descer bloco"><ArrowDown /></Button>
                      <Button size="icon" variant="ghost" className="size-9 text-destructive" onClick={() => persist(blocks.filter((_, j) => j !== i))} aria-label="Apagar bloco"><Trash2 /></Button>
                    </div>
                  )}
                </div>
                <div className="grid gap-2">{inside.length ? inside.map((g) => <GuideCard key={g.id} g={g} />) : <p className="border border-dashed border-border p-3 text-center text-xs text-muted-foreground">{canManage ? "Solte uma guia aqui" : "Sem guia neste bloco"}</p>}</div>
              </section>
            );
          })}
          {sections.length === 0 && <p className="border border-dashed border-border p-6 text-center text-sm text-muted-foreground">{canManage ? "Escolha um formato pronto ou adicione blocos acima." : "O produtor ainda não desenhou a estrutura."}</p>}
        </div>

        {loose.length > 0 && (
          <section onDragOver={(e) => canManage && e.preventDefault()} onDrop={(e) => dropOn(e, null)} className="border border-border bg-card p-3">
            <h2 className="mb-2 text-xl">GUIAS SEM BLOCO</h2>
            <div className="grid gap-2">{loose.map((g) => <GuideCard key={g.id} g={g} />)}</div>
          </section>
        )}
      </main>
    </div>
  );
}
