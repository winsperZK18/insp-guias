import { useState } from "react";
import { toast } from "sonner";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { useMarkTesting, useRequestRedo } from "@/hooks/use-guide-status";
import { REDO_REASONS } from "@/lib/types";
import { Pause, Play, ArrowDown, ArrowUp, RotateCcw, SlidersHorizontal, Trash2 } from "lucide-react";
import { AudioPlayer } from "@/components/audio/audio-player";
import { ReactionBar } from "@/components/chat/reaction-bar";
import { ConfirmDeleteDialog } from "@/components/common/confirm-delete-dialog";
import { ProgressField } from "@/components/common/progress-field";
import { StatusBadge } from "@/components/common/status-badge";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { useAccess } from "@/hooks/use-access";
import { supabase } from "@/integrations/supabase/client";
import { useAudioUrl } from "@/hooks/use-audio-url";
import { LiveSyncPanel } from "@/components/audio/live-sync-panel";
import { useCanUseTimeline } from "@/hooks/use-timeline-access";
import { useProject } from "@/hooks/use-projects";
import { useReactions, useToggleReaction } from "@/hooks/use-guide-chat";
import { useDeleteGuide, useUpdateGuide } from "@/hooks/use-guides";
import type { ProcessingState } from "@/hooks/use-guide-processing";
import { formatDuration } from "@/lib/format";
import { barLabel, secondsPerBar, secondsPerBeat, snapToBar } from "@/lib/bars";
import { GUIDE_STATUSES, GUIDE_STATUS_LABELS, type Guide, type GuideStatus, type TrackSection } from "@/lib/types";

export function GuideItem({
  guide,
  projectId,
  processing,
  sections,
  canManage,
  canEditOwn,
  onProcess,
  onMove,
}: {
  guide: Guide;
  projectId: string;
  processing: ProcessingState;
  sections: TrackSection[];
  canManage: boolean;
  canEditOwn: boolean;
  onProcess: (guide: Guide, options?: { strength?: number; offsetSeconds?: number | null }) => void;
  onMove: (direction: -1 | 1) => void;
}) {
  const [showOriginal, setShowOriginal] = useState(false);
  const [strength, setStrength] = useState(1.8);
  const [entry, setEntry] = useState(String(Number(guide.entry_seconds) || 0));
  const { data: project } = useProject(projectId);
  const [listening, setListening] = useState(false);
  const canTimeline = useCanUseTimeline();
  const update = useUpdateGuide(projectId);
  const remove = useDeleteGuide(projectId);
  const activePath = !showOriginal && guide.processed_path ? guide.processed_path : guide.audio_path;
  const url = useAudioUrl(activePath);
  const isProcessing = processing.guideId === guide.id;
  const editable = canManage || canEditOwn;
  const access = useAccess();
    const { data: reactions = [] } = useReactions(guide.id, []);
  const toggleReaction = useToggleReaction(guide.id);
  const guideReactions = reactions.filter((item) => item.guide_id === guide.id);
  const [redoOpen, setRedoOpen] = useState(false);
  const [otherReason, setOtherReason] = useState("");
  const markTesting = useMarkTesting(projectId, canManage);
  const requestRedo = useRequestRedo(projectId);
  const askRedo = async (reason: string) => {
    const text = reason.trim();
    if (!text) return;
    await requestRedo(guide, text);
    setRedoOpen(false);
    setOtherReason("");
    toast.success("Pedido de regravação enviado para o artista.");
  };

  const saveEntry = (value: number) => {
    const safe = Math.max(0, Math.round(value * 100) / 100);
    setEntry(String(safe));
    update.mutate({ id: guide.id, entry_seconds: safe });
  };
  const bpm = project?.bpm ?? null;
  const step = (delta: number) => saveEntry((Number(entry) || 0) + delta);
  const stepBeat = (count: number) => step(count * secondsPerBeat(bpm));
  const stepBar = (count: number) => step(count * secondsPerBar(bpm));

  return (
    <article id={`guia-${guide.id}`} className="border border-border bg-card p-4 transition-shadow">
      <div className="grid grid-cols-[minmax(0,1fr)_auto] items-start gap-3">
        <div className="min-w-0">
          <div className="mb-2 flex flex-wrap items-center gap-2">
            <h3 className="truncate text-xl">{guide.artist_name}</h3>
            <StatusBadge status={guide.status} />
            {guide.processed_path && <span className="text-xs text-success">voz tratada</span>}
          </div>
          <p className="mb-3 text-xs uppercase text-muted-foreground">
            {guide.part_label || "Parte não definida"} · entra em {formatDuration(Number(guide.entry_seconds) || 0)}
            {guide.detected_offset_seconds != null && ` · sugestão ${formatDuration(Number(guide.detected_offset_seconds))}`}
          </p>
          <AudioPlayer src={url} />
        </div>
        {canManage && (
          <div className="flex flex-col">
            <Button size="icon" variant="ghost" className="size-11" onClick={() => onMove(-1)} aria-label="Subir guia"><ArrowUp /></Button>
            <Button size="icon" variant="ghost" className="size-11" onClick={() => onMove(1)} aria-label="Descer guia"><ArrowDown /></Button>
          </div>
        )}
      </div>

      {editable && (
        <div className="mt-4 grid gap-4 sm:grid-cols-2">
          <div className="space-y-1">
            <Label>Entrada na música</Label>
            <p className="text-xs text-muted-foreground">Começa no {barLabel(Number(entry) || 0, bpm)}</p>
            <div className="grid grid-cols-4 gap-2">
              <Button variant="outline" className="h-11 px-0 text-xs" onClick={() => stepBar(-1)}>−1 comp.</Button>
              <Button variant="outline" className="h-11 px-0 text-xs" onClick={() => stepBeat(-1)}>−1 tempo</Button>
              <Button variant="outline" className="h-11 px-0 text-xs" onClick={() => stepBeat(1)}>+1 tempo</Button>
              <Button variant="outline" className="h-11 px-0 text-xs" onClick={() => stepBar(1)}>+1 comp.</Button>
            </div>
            <Button variant="secondary" className="mt-1 h-11 w-full" onClick={() => saveEntry(snapToBar(Number(entry) || 0, bpm))}>Colar no compasso</Button>
          </div>

          {canManage && (
            <label className="space-y-1">
              <Label>Status</Label>
              <Select
                value={guide.status}
                onValueChange={(v) => {
                  if (v === "regravar") { setRedoOpen(true); return; }
                  update.mutate({ id: guide.id, status: v as GuideStatus }, { onSuccess: () => { void supabase.from("project_messages").insert({ project_id: projectId, body: `Status da guia #${guide.artist_name.replace(/\s+/g, "_")} → ${GUIDE_STATUS_LABELS[v as GuideStatus]}`, guide_refs: [guide.id] }); } });
                }}
              >
                <SelectTrigger className="h-11"><SelectValue /></SelectTrigger>
                <SelectContent>{GUIDE_STATUSES.map((v) => <SelectItem value={v} key={v}>{GUIDE_STATUS_LABELS[v]}</SelectItem>)}</SelectContent>
              </Select>
            </label>
          )}

          <div className="space-y-2">
            <div className="flex justify-between"><Label>Força da limpeza</Label><span className="text-xs text-muted-foreground">{strength.toFixed(1)}×</span></div>
            <Slider min={0.5} max={3} step={0.1} value={[strength]} onValueChange={(v) => setStrength(v[0] ?? 1.8)} />
          </div>
        </div>
      )}

      {isProcessing && <div className="mt-4"><ProgressField value={processing.ratio} label={processing.label} /></div>}

      <div className="mt-4 flex flex-wrap items-center gap-2 border-t border-border pt-3">
        <ReactionBar
          reactions={guideReactions}
          userId={access.userId}
          onToggle={(emoji, existingId) => toggleReaction.mutate({ emoji, existingId })}
        />
        {editable && (
          <Button size="sm" className="h-11" variant="secondary" onClick={() => onProcess(guide, { strength })} disabled={isProcessing}>
            <SlidersHorizontal /> {guide.processed_path ? "Refazer limpeza" : "Alinhar e limpar voz"}
          </Button>
        )}
        <Button size="sm" className="h-11" variant="hero" onClick={() => { setListening((v) => { if (!v) markTesting([guide]); return !v; }); }} disabled={!project?.beat_path}>
          {listening ? <Pause /> : <Play />} {listening ? "Fechar player" : "Ouvir com o beat"}
        </Button>
        {guide.processed_path && (
          <Button size="sm" className="h-11" variant="ghost" onClick={() => setShowOriginal((v) => !v)}>
            <RotateCcw /> {showOriginal ? "Ouvir tratada" : "Ouvir original"}
          </Button>
        )}
        {editable && (
          <ConfirmDeleteDialog
            title="Apagar esta guia?"
            description="O áudio original e a voz tratada serão removidos."
            onConfirm={() => remove.mutate(guide)}
            trigger={<Button size="sm" variant="ghost" className="ml-auto h-11 text-destructive"><Trash2 /> Apagar</Button>}
          />
        )}
      </div>

      {listening && (
        <div className="mt-3">
          <LiveSyncPanel
            guide={guide}
            beatPath={project?.beat_path}
            voicePath={activePath}
            bpm={bpm}
            title={project?.title ?? "faixa"}
            canAdjust={editable && canTimeline}
            onSave={(patch) => { setEntry(String(patch.entry_seconds)); update.mutate({ id: guide.id, ...patch }); }}
          />
        </div>
      )}

      <Dialog open={redoOpen} onOpenChange={setRedoOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle>Pedir para regravar</DialogTitle></DialogHeader>
          <p className="text-sm text-muted-foreground">O artista recebe o aviso no chat da música.</p>
          <div className="grid gap-2">
            {REDO_REASONS.map((reason) => (
              <Button key={reason} variant="outline" className="h-auto min-h-11 whitespace-normal py-2 text-left" onClick={() => void askRedo(reason)}>
                {reason}
              </Button>
            ))}
          </div>
          <div className="flex gap-2">
            <Input value={otherReason} onChange={(e) => setOtherReason(e.target.value)} placeholder="Outro motivo" className="h-11" />
            <Button className="h-11" disabled={!otherReason.trim()} onClick={() => void askRedo(otherReason)}>Enviar</Button>
          </div>
        </DialogContent>
      </Dialog>
    </article>
  );
}
