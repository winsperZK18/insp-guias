import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { UserPlus, X } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

const t = () => supabase.from("project_guests" as never) as any;

/** Convidar alguém só para esta música (feat), sem entrar no grupo. */
export function TrackGuests({ projectId }: { projectId: string }) {
  const qc = useQueryClient();
  const [email, setEmail] = useState("");
  const key = ["guests", projectId];
  const list = useQuery({
    queryKey: key,
    queryFn: async () => ((await t().select("email, user_id").eq("project_id", projectId)).data ?? []) as { email: string; user_id: string | null }[],
  });
  const add = useMutation({
    mutationFn: async (e: string) => { const { error } = await t().insert({ project_id: projectId, email: e }); if (error) throw error; },
    onSuccess: () => { setEmail(""); toast.success("Convite criado. Mande o link da faixa pra pessoa entrar com esse e-mail."); void qc.invalidateQueries({ queryKey: key }); },
    onError: () => toast.error("Não deu para convidar."),
  });
  const del = useMutation({
    mutationFn: async (e: string) => { await t().delete().eq("project_id", projectId).eq("email", e); },
    onSuccess: () => void qc.invalidateQueries({ queryKey: key }),
  });
  return (
    <section className="border border-border bg-card p-4">
      <p className="text-xs uppercase text-primary">Participação só nesta música</p>
      <form className="mt-2 flex gap-2" onSubmit={(ev) => { ev.preventDefault(); const e = email.trim().toLowerCase(); if (e.includes("@")) add.mutate(e); }}>
        <Input type="email" className="h-11" placeholder="e-mail do feat" value={email} onChange={(e) => setEmail(e.target.value)} />
        <Button className="h-11" disabled={add.isPending}><UserPlus /> Convidar</Button>
      </form>
      <ul className="mt-3 space-y-1 text-sm">
        {(list.data ?? []).map((g) => (
          <li key={g.email} className="flex items-center justify-between">
            <span>{g.email} <span className="text-muted-foreground">{g.user_id ? "· entrou" : "· pendente"}</span></span>
            <button aria-label="Remover" onClick={() => del.mutate(g.email)}><X className="size-4" /></button>
          </li>
        ))}
      </ul>
      <Button type="button" variant="outline" className="mt-3 h-10 w-full" onClick={() => { void navigator.clipboard.writeText(window.location.href); toast.success("Link copiado."); }}>Copiar link da faixa</Button>
    </section>
  );
}
