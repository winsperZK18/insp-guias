import { useState } from "react";
import { MailPlus, Trash2 } from "lucide-react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { supabase } from "@/integrations/supabase/client";
import { useAccess } from "@/hooks/use-access";
import { useMembers, useSetMemberRole } from "@/hooks/use-members";

type Role = "admin" | "producer" | "member";
const ROLE_LABEL: Record<Role, string> = { admin: "Administrador", producer: "Produtor", member: "Artista" };

/** Admin do grupo: convida por e-mail e define a função de cada integrante. */
export function MemberInvites() {
  const access = useAccess();
  const groupId = access.groupId;
  const qc = useQueryClient();
  const { data: members = [] } = useMembers();
  const setRole = useSetMemberRole();
  const [email, setEmail] = useState("");
  const [role, setNewRole] = useState<Role>("member");
  const [busy, setBusy] = useState(false);
  const invites = useQuery({
    queryKey: ["invitations", groupId],
    enabled: Boolean(groupId),
    queryFn: async () => (await supabase.from("group_invitations").select("id, email, role").eq("group_id", groupId!)).data ?? [],
  });

  if (!access.isAdmin || !groupId || access.group?.is_personal) return null;

  async function invite() {
    const normalized = email.trim().toLowerCase();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(normalized)) { toast.error("Digite um e-mail válido."); return; }
    setBusy(true);
    const { error } = await supabase.from("group_invitations").upsert({ group_id: groupId!, email: normalized, role }, { onConflict: "group_id,email" });
    setBusy(false);
    if (error) { toast.error("Não foi possível criar o convite."); return; }
    setEmail("");
    void qc.invalidateQueries({ queryKey: ["invitations"] });
    toast.success("Convite criado. Quando a pessoa entrar com esse Google, já cai no grupo.");
  }

  return (
    <Collapsible className="mb-4 border border-border bg-card">
      <CollapsibleTrigger asChild><Button variant="ghost" className="h-12 w-full justify-start px-4"><MailPlus className="text-primary" /> Integrantes e convites</Button></CollapsibleTrigger>
      <CollapsibleContent className="space-y-4 border-t border-border p-4">
        <div className="grid gap-2 sm:grid-cols-[minmax(0,1fr)_10rem_auto]">
          <Input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="integrante@gmail.com" aria-label="E-mail do integrante" />
          <Select value={role} onValueChange={(v) => setNewRole(v as Role)}><SelectTrigger className="h-11"><SelectValue /></SelectTrigger><SelectContent>{(Object.keys(ROLE_LABEL) as Role[]).map((r) => <SelectItem key={r} value={r}>{ROLE_LABEL[r]}</SelectItem>)}</SelectContent></Select>
          <Button className="h-11" onClick={invite} disabled={busy}>{busy ? "Salvando..." : "Convidar"}</Button>
        </div>
        {(invites.data ?? []).length > 0 && (
          <div><p className="mb-1 text-xs uppercase text-muted-foreground">Convites pendentes</p>
            <ul className="divide-y divide-border">{invites.data!.map((i) => (
              <li key={i.id} className="flex items-center gap-2 py-1 text-sm"><span className="min-w-0 flex-1 truncate">{i.email}</span><span className="text-xs text-muted-foreground">{ROLE_LABEL[i.role as Role]}</span>
                <Button size="icon" variant="ghost" className="size-9" aria-label="Cancelar convite" onClick={async () => { await supabase.from("group_invitations").delete().eq("id", i.id); void qc.invalidateQueries({ queryKey: ["invitations"] }); }}><Trash2 className="size-4" /></Button></li>
            ))}</ul>
          </div>
        )}
        <div><p className="mb-1 text-xs uppercase text-muted-foreground">No grupo</p>
          <ul className="divide-y divide-border">{members.map((m) => (
            <li key={m.id} className="flex items-center gap-2 py-1.5 text-sm">
              <span className="min-w-0 flex-1 truncate">{m.display_name || m.email}</span>
              {m.id === access.userId ? <span className="text-xs text-muted-foreground">{ROLE_LABEL[m.role as Role]} (você)</span> : (
                <>
                  <Select value={m.role ?? "member"} onValueChange={(v) => setRole.mutate({ groupId, userId: m.id, role: v as Role })}><SelectTrigger className="h-9 w-36"><SelectValue /></SelectTrigger><SelectContent>{(Object.keys(ROLE_LABEL) as Role[]).map((r) => <SelectItem key={r} value={r}>{ROLE_LABEL[r]}</SelectItem>)}</SelectContent></Select>
                  <Button size="icon" variant="ghost" className="size-9 text-destructive" aria-label="Remover do grupo" onClick={() => setRole.mutate({ groupId, userId: m.id, role: null })}><Trash2 className="size-4" /></Button>
                </>
              )}
            </li>
          ))}</ul>
        </div>
      </CollapsibleContent>
    </Collapsible>
  );
}
