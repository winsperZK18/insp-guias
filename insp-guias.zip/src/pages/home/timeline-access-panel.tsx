import { MoveHorizontal } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { Switch } from "@/components/ui/switch";
import { useMembers } from "@/hooks/use-members";
import { useTimelineEditors, useToggleTimelineAccess } from "@/hooks/use-timeline-access";

/** Admin/produtor libera o ajuste manual para artistas específicos. */
export function TimelineAccessPanel() {
  const { data: members = [] } = useMembers();
  const { data: editors } = useTimelineEditors();
  const toggle = useToggleTimelineAccess();
  const artists = members.filter((m) => m.role === "member");

  return (
    <Collapsible className="mb-8 border border-border bg-card">
      <CollapsibleTrigger asChild><Button variant="ghost" className="h-12 w-full justify-start px-4"><MoveHorizontal className="text-primary" /> Quem pode usar o ajuste manual</Button></CollapsibleTrigger>
      <CollapsibleContent className="border-t border-border p-4">
        <p className="mb-3 text-xs text-muted-foreground">Produtores e administradores sempre podem. Ligue para liberar um artista.</p>
        {artists.length === 0 && <p className="text-sm text-muted-foreground">Nenhum artista no grupo ainda.</p>}
        <ul className="divide-y divide-border">
          {artists.map((m) => (
            <li key={m.id} className="flex items-center justify-between gap-3 py-2">
              <span className="min-w-0 truncate text-sm">{m.display_name || m.email}</span>
              <Switch
                checked={Boolean(editors?.has(m.id))}
                aria-label={`Liberar ajuste manual para ${m.display_name || m.email}`}
                onCheckedChange={(allow) => toggle.mutate({ userId: m.id, allow }, { onError: () => toast.error("Não foi possível mudar a permissão.") })}
              />
            </li>
          ))}
        </ul>
      </CollapsibleContent>
    </Collapsible>
  );
}
