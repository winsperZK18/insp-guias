import { useEffect, useState, type ReactNode } from "react";
import { toast } from "sonner";
import { AudioFileField } from "@/components/common/audio-file-field";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useCreateProject, useUpdateProject } from "@/hooks/use-projects";
import { decodeAudioBuffer } from "@/lib/audio/decode";
import { uploadAudio } from "@/lib/storage";
import { PROJECT_STATUSES, PROJECT_STATUS_LABELS, RELEASE_KINDS, RELEASE_KIND_LABELS, type Project, type ProjectStatus, type ReleaseKind } from "@/lib/types";

export function ProjectFormDialog({ project, releaseSuggestions, trigger }: { project?: Project; releaseSuggestions: string[]; trigger: ReactNode }) {
  const [open, setOpen] = useState(false);
  const [title, setTitle] = useState(project?.title ?? "");
  const [bpm, setBpm] = useState(project?.bpm?.toString() ?? "");
  const [musicalKey, setMusicalKey] = useState(project?.musical_key ?? "");
  const [status, setStatus] = useState<ProjectStatus>(project?.status ?? "ideia");
  const [releaseKind, setReleaseKind] = useState<ReleaseKind>(project?.release_kind ?? "single");
  const [releaseTitle, setReleaseTitle] = useState(project?.release_title ?? "");
  const [notes, setNotes] = useState(project?.notes ?? "");
  const [file, setFile] = useState<File | null>(null);
  const create = useCreateProject();
  const update = useUpdateProject();

  useEffect(() => {
    if (!open) return;
    setTitle(project?.title ?? ""); setBpm(project?.bpm?.toString() ?? ""); setMusicalKey(project?.musical_key ?? "");
    setStatus(project?.status ?? "ideia"); setReleaseKind(project?.release_kind ?? "single"); setReleaseTitle(project?.release_title ?? ""); setNotes(project?.notes ?? ""); setFile(null);
  }, [open, project]);

  const submit = async () => {
    if (!title.trim()) {
      toast.error("Dê um nome para a música.");
      return;
    }
    try {
      let beat_path = project?.beat_path ?? null;
      let beat_file_name = project?.beat_file_name ?? null;
      let beat_duration_seconds = project?.beat_duration_seconds ?? null;
      if (file) {
        beat_path = await uploadAudio("beats", file, file.name);
        beat_file_name = file.name;
        beat_duration_seconds = (await decodeAudioBuffer(file)).duration;
      }
      const payload = { title: title.trim(), bpm: bpm ? Number(bpm) : null, musical_key: musicalKey.trim() || null, status, notes: notes.trim() || null, release_kind: releaseKind, release_title: releaseKind === "single" ? null : releaseTitle.trim() || null, beat_path, beat_url: beat_path, beat_file_name, beat_duration_seconds };
      if (project) await update.mutateAsync({ id: project.id, ...payload }); else await create.mutateAsync(payload);
      toast.success(project ? "Projeto atualizado." : "Projeto criado.");
      setOpen(false);
    } catch (error) { toast.error(error instanceof Error ? error.message : "Não foi possível salvar."); }
  };

  const busy = create.isPending || update.isPending;
  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>{trigger}</DialogTrigger>
      <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-xl">
        <DialogHeader><DialogTitle>{project ? "Editar projeto" : "Novo projeto"}</DialogTitle><DialogDescription>Cadastre a faixa e o beat que servirá de base para as guias.</DialogDescription></DialogHeader>
        <div className="grid gap-4 py-2 sm:grid-cols-2">
          <label className="space-y-2 sm:col-span-2"><Label>Nome da música</Label><Input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Ex.: Noite sem fim" autoFocus /></label>
          <label className="space-y-2"><Label>BPM</Label><Input type="number" min="1" max="400" value={bpm} onChange={(e) => setBpm(e.target.value)} placeholder="92" /></label>
          <label className="space-y-2"><Label>Tom</Label><Input value={musicalKey} onChange={(e) => setMusicalKey(e.target.value)} placeholder="Fá menor" /></label>
          <label className="space-y-2"><Label>Status</Label><Select value={status} onValueChange={(value) => setStatus(value as ProjectStatus)}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent>{PROJECT_STATUSES.map((v) => <SelectItem key={v} value={v}>{PROJECT_STATUS_LABELS[v]}</SelectItem>)}</SelectContent></Select></label>
          <label className="space-y-2"><Label>Lançamento</Label><Select value={releaseKind} onValueChange={(value) => setReleaseKind(value as ReleaseKind)}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent>{RELEASE_KINDS.map((v) => <SelectItem key={v} value={v}>{RELEASE_KIND_LABELS[v]}</SelectItem>)}</SelectContent></Select></label>
          {releaseKind !== "single" && <label className="space-y-2 sm:col-span-2"><Label>Nome do {releaseKind === "ep" ? "EP" : "álbum"}</Label><Input list="release-suggestions" value={releaseTitle} onChange={(e) => setReleaseTitle(e.target.value)} placeholder="Nome do lançamento" /><datalist id="release-suggestions">{releaseSuggestions.map((name) => <option key={name} value={name} />)}</datalist></label>}
          <div className="sm:col-span-2"><AudioFileField value={file} onChange={setFile} label={project?.beat_path ? "Trocar beat (opcional)" : "Beat (opcional)"} /></div>
          <label className="space-y-2 sm:col-span-2"><Label>Observações</Label><Textarea value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="Clima, referência, detalhes para o grupo..." /></label>
        </div>
        <DialogFooter><Button variant="outline" onClick={() => setOpen(false)}>Cancelar</Button><Button variant="hero" disabled={busy} onClick={submit}>{busy ? "Salvando..." : "Salvar projeto"}</Button></DialogFooter>
      </DialogContent>
    </Dialog>
  );
}