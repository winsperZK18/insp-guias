import { useEffect, useRef, useState } from "react";
import { Check, Pencil, X } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useAccess } from "@/hooks/use-access";
import { useGroupName, useSaveGroupName } from "@/hooks/use-group-name";

export function GroupNameLine() {
  const access = useAccess();
  const { data: groupName } = useGroupName();
  const save = useSaveGroupName();
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (editing) inputRef.current?.focus();
  }, [editing]);

  if (editing) {
    return (
      <form
        className="mt-3 flex max-w-sm items-center gap-2"
        onSubmit={(event) => {
          event.preventDefault();
          const name = draft.trim();
          save.mutate(name, {
            onSuccess: () => {
              setEditing(false);
              toast.success(name ? "Nome do grupo salvo." : "Nome do grupo removido.");
            },
            onError: () => toast.error("Não foi possível salvar o nome."),
          });
        }}
      >
        <Input
          ref={inputRef}
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          placeholder="Nome da banda, artista ou grupo"
          maxLength={80}
          className="h-10 bg-background/60"
          aria-label="Nome do grupo"
        />
        <Button type="submit" size="icon" className="size-10 shrink-0" disabled={save.isPending} aria-label="Salvar nome do grupo">
          <Check />
        </Button>
        <Button type="button" size="icon" variant="outline" className="size-10 shrink-0" onClick={() => setEditing(false)} aria-label="Cancelar edição">
          <X />
        </Button>
      </form>
    );
  }

  if (!groupName) return null;
  const canRename = access.isAdmin && !access.group?.is_personal;

  return (
    <div className="mt-3 flex items-center gap-2">
      <p className="text-lg font-medium uppercase tracking-wide text-foreground/70 sm:text-xl">
        {groupName || "Definir nome do grupo"}
      </p>
      {canRename && (
        <Button
          size="icon"
          variant="ghost"
          className="size-9 shrink-0 text-foreground/60"
          onClick={() => {
            setDraft(groupName ?? "");
            setEditing(true);
          }}
          aria-label="Editar nome do grupo"
        >
          <Pencil className="size-4" />
        </Button>
      )}
    </div>
  );
}
