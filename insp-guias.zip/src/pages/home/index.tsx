import { useMemo, useState } from "react";
import { Disc3, FolderPlus, Mic2, Plus, Radio } from "lucide-react";
import { AppHeader } from "@/components/layout/app-header";
import { EmptyState } from "@/components/common/empty-state";
import { Button } from "@/components/ui/button";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useAllGuides } from "@/hooks/use-guides";
import { useProjects } from "@/hooks/use-projects";
import { ProjectCard } from "./project-card";
import { ProjectFormDialog } from "./project-form-dialog";
import { MemberInvites } from "./member-invites";
import { TimelineAccessPanel } from "./timeline-access-panel";
import { useAccess } from "@/hooks/use-access";
import { GroupNameLine } from "./group-name-line";

export function HomePage() {
  const { data: projects = [], isLoading } = useProjects();
  const { data: allGuides = [] } = useAllGuides();
  const [filter, setFilter] = useState("all");
  const releaseSuggestions = useMemo(() => [...new Set(projects.map((p) => p.release_title).filter((v): v is string => Boolean(v)))], [projects]);
  const filtered = projects.filter((p) => !p.parent_project_id).filter((p) => filter === "all" || p.release_kind === filter || p.release_title === filter);
  const projectIds = new Set(projects.map((p) => p.id));
  const guides = allGuides.filter((g) => projectIds.has(g.project_id));
  const waiting = guides.filter((g) => g.status === "novo_take" || g.status === "em_teste").length;
  const access = useAccess();

  return (
    <div className="min-h-screen"><AppHeader />
      <main className="mx-auto max-w-7xl px-4 pb-16 pt-6 sm:px-6 sm:pt-10">
        <section className="mb-6 grid grid-cols-[minmax(0,1fr)_auto] items-end gap-4 border-b border-border pb-6 sm:mb-10 sm:flex sm:justify-between sm:gap-7 sm:pb-8">
          <div className="min-w-0"><p className="mb-2 flex items-center gap-2 text-xs font-semibold uppercase text-primary"><Radio className="size-4 animate-pulse-soft" /> Sala de criação</p><h1 className="text-4xl leading-none sm:max-w-3xl sm:text-7xl">CENTRAL DE GUIAS</h1><GroupNameLine /><p className="mt-3 hidden max-w-xl text-muted-foreground sm:block">Organize beats, receba as guias do grupo e teste o mapa completo de cada faixa.</p></div>
          {access.canManageProjects && <ProjectFormDialog releaseSuggestions={releaseSuggestions} trigger={<Button className="h-11" variant="hero"><Plus /> <span className="hidden sm:inline">Novo projeto</span><span className="sm:hidden">Novo</span></Button>} />}
        </section>
        {access.isAdmin && <MemberInvites />}
        {access.canManageProjects && !access.group?.is_personal && <TimelineAccessPanel />}
        <section className="mb-8 grid gap-px bg-border sm:grid-cols-3">
          {[{ icon: Disc3, value: projects.length, label: "Projetos" }, { icon: Mic2, value: guides.length, label: "Guias recebidas" }, { icon: Radio, value: waiting, label: "Aguardando aprovação" }].map(({ icon: Icon, value, label }) => <div key={label} className="flex items-center gap-4 bg-background p-5"><Icon className="size-5 text-primary" /><div><strong className="text-2xl">{value}</strong><p className="text-xs uppercase text-muted-foreground">{label}</p></div></div>)}
        </section>
        {projects.length > 0 && <div className="mb-6 overflow-x-auto"><Tabs value={filter} onValueChange={setFilter}><TabsList><TabsTrigger value="all">Todas</TabsTrigger><TabsTrigger value="single">Singles</TabsTrigger><TabsTrigger value="ep">EP</TabsTrigger><TabsTrigger value="album">Álbuns</TabsTrigger>{releaseSuggestions.map((name) => <TabsTrigger key={name} value={name}>{name}</TabsTrigger>)}</TabsList></Tabs></div>}
        {isLoading ? <div className="py-20 text-center text-muted-foreground">Carregando a central...</div> : projects.length === 0 ? access.canManageProjects ? <ProjectFormDialog releaseSuggestions={[]} trigger={<span className="block"><EmptyState icon={FolderPlus} title="A central está vazia" description="Crie o primeiro projeto, envie o beat e reúna as guias em um só lugar." action="Novo projeto" onAction={() => {}} /></span>} /> : <EmptyState icon={FolderPlus} title="A central está vazia" description="Um produtor precisa criar o primeiro projeto." /> : <div className="grid gap-5 md:grid-cols-2 xl:grid-cols-3">{filtered.map((project) => <ProjectCard key={project.id} project={project} projects={projects} guides={guides.filter((g) => g.project_id === project.id)} canManage={access.canManageProjects} />)}</div>}
      </main>
    </div>
  );
}