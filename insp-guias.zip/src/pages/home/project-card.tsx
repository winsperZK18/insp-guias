import { useState } from "react";
import { Link } from "@tanstack/react-router";
import { ArrowUpRight, Disc3, FolderInput, Music2, X } from "lucide-react";
import { toast } from "sonner";
import { AudioPlayer } from "@/components/audio/audio-player";
import { StatusBadge } from "@/components/common/status-badge";
import { Button } from "@/components/ui/button";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { useMentions } from "@/hooks/use-mentions";
import { useAudioUrl } from "@/hooks/use-audio-url";
import { useUpdateProject } from "@/hooks/use-projects";
import { cn } from "@/lib/utils";
import { RELEASE_KIND_LABELS, type Guide, type Project } from "@/lib/types";

export function ProjectCard({ project, projects, guides, canManage }: { project: Project; projects: Project[]; guides: Guide[]; canManage: boolean }) {
  const beatUrl = useAudioUrl(project.beat_path);
  const mentions = useMentions().unreadByProject(project.id);
  const update = useUpdateProject();
  const [over, setOver] = useState(false);
  const approved = guides.filter((g) => g.status === "fechada").length;
  const isRelease = project.release_kind !== "single";
  const children = projects.filter((p) => p.parent_project_id === project.id);
  const releases = projects.filter((p) => p.release_kind !== "single" && p.id !== project.id);
  const attach = (childId: string, parent: Project | null) =>
    update.mutate({ id: childId, parent_project_id: parent?.id ?? null }, {
      onSuccess: () => toast.success(parent ? `Faixa adicionada a ${parent.title}.` : "Faixa voltou a ser avulsa."),
      onError: () => toast.error("Não foi possível mover a faixa."),
    });

  return (
    <article
      draggable={canManage && !isRelease}
      onDragStart={(e) => e.dataTransfer.setData("text/project", project.id)}
      onDragOver={(e) => { if (canManage && isRelease) { e.preventDefault(); setOver(true); } }}
      onDragLeave={() => setOver(false)}
      onDrop={(e) => { setOver(false); const id = e.dataTransfer.getData("text/project"); if (id && id !== project.id) attach(id, project); }}
      className={cn("group animate-rise overflow-hidden border bg-card shadow-elegant transition-[transform,border-color] duration-200 hover:-translate-y-1 hover:border-primary/50", over ? "border-primary" : "border-border")}
    >
      <div className="h-1 bg-gradient-primary" />
      <div className="p-5">
        <div className="flex items-start justify-between gap-4">
          <div className="min-w-0"><p className="mb-2 flex items-center gap-2 text-xs uppercase text-muted-foreground"><Disc3 className="size-3.5" /> {project.release_kind === "single" ? RELEASE_KIND_LABELS.single : project.release_title || RELEASE_KIND_LABELS[project.release_kind]}</p><h2 className="truncate text-3xl">{project.title}</h2></div>
          <div className="flex items-center gap-1">
            <StatusBadge status={project.status} />
            {canManage && !isRelease && releases.length > 0 && (
              <DropdownMenu>
                <DropdownMenuTrigger asChild><Button size="icon" variant="ghost" className="size-9" aria-label="Adicionar a um EP ou álbum"><FolderInput className="size-4" /></Button></DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuLabel>Adicionar a um EP/Álbum</DropdownMenuLabel>
                  {releases.map((r) => <DropdownMenuItem key={r.id} onClick={() => attach(project.id, r)}>{r.title} · {RELEASE_KIND_LABELS[r.release_kind]}</DropdownMenuItem>)}
                </DropdownMenuContent>
              </DropdownMenu>
            )}
          </div>
        </div>
        <div className="my-5 grid grid-cols-3 divide-x divide-border border-y border-border py-3 text-center">
          <div><strong className="block text-lg">{project.bpm ?? "—"}</strong><small className="text-muted-foreground">BPM</small></div>
          <div><strong className="block text-lg">{project.musical_key ?? "—"}</strong><small className="text-muted-foreground">Tom</small></div>
          <div><strong className="block text-lg">{approved}/{guides.length}</strong><small className="text-muted-foreground">Aprovadas</small></div>
        </div>
        {isRelease && (
          <div className="mb-5 space-y-1">
            <p className="text-xs uppercase text-muted-foreground">Faixas {canManage && "· arraste um single para cá"}</p>
            {children.length === 0 && <p className="text-sm text-muted-foreground">Nenhuma faixa ainda.</p>}
            {children.map((c) => (
              <div key={c.id} className="flex items-center gap-2 border border-border px-2 py-1 text-sm">
                <Link to="/projeto/$id" params={{ id: c.id }} className="min-w-0 flex-1 truncate hover:text-primary">{c.title}</Link>
                {canManage && <Button size="icon" variant="ghost" className="size-8" aria-label="Tirar do lançamento" onClick={() => attach(c.id, null)}><X className="size-4" /></Button>}
              </div>
            ))}
          </div>
        )}
        {project.beat_path ? <div className="mb-5 flex items-center gap-3 rounded-md bg-muted/50 p-2"><Music2 className="size-4 shrink-0 text-primary" /><AudioPlayer src={beatUrl} compact /></div> : !isRelease && <div className="mb-5 flex h-12 items-center gap-2 text-xs text-muted-foreground"><Music2 className="size-4" /> Beat ainda não enviado</div>}
        <Link to="/projeto/$id" params={{ id: project.id }} className="flex items-center justify-between border-t border-border pt-4 text-sm font-semibold text-primary"><span className="flex items-center gap-2">Abrir projeto{mentions > 0 && <span className="rounded-full bg-primary px-2 text-[11px] text-primary-foreground">{mentions} @ nova{mentions > 1 ? "s" : ""}</span>}</span> <ArrowUpRight className="size-4 transition-transform group-hover:translate-x-1 group-hover:-translate-y-1" /></Link>
      </div>
    </article>
  );
}
