# Roadmap — Central de Guias INSPMUSIC

A Central de Guias é o primeiro módulo da INSPMUSIC: resolver bem a criação colaborativa antes de qualquer outra etapa. Royalties, contratos e distribuição estão fora do escopo por enquanto.

## Concluído

### Base do produto
- [x] Projetos, beats, guias, status, prévia e mapa da faixa.
- [x] Ciclo da guia: Novo Take, Em Teste (automático ao ouvir), Regravar com motivo avisado no chat e Guia Fechada travada para o artista.
- [x] Login Google somente por convite e arquivos de áudio privados.
- [x] Upload de MP3, WAV, M4A, AAC, OGG e WebM para beat e guia.
- [x] Três funções: administrador, produtor e artista, validadas no banco.
- [x] Partes editáveis da faixa e sugestão automática de refrão pelo beat.
- [x] Uso no celular: botão fixo de envio, campos grandes e mapa avançado recolhível.

### Rodada de colaboração
- [x] Logotipo flat "INSPMUSIC" em branco, sem fundo, nítido no cabeçalho e na entrada.
- [x] Gravar a guia direto no projeto, com o beat tocando e aviso para usar fone.
- [x] Ouvir a gravação, regravar ou enviar na hora escolhendo a parte da música.
- [x] Conversa dentro de cada guia, com resposta citada no estilo WhatsApp.
- [x] Menção a outro integrante com @ dentro da conversa.
- [x] Reações com emoji na guia e em cada mensagem.
- [x] Etapas da faixa criadas automaticamente e progresso "Falta:" no card da central.
- [x] Histórico de alterações para o administrador, com data e filtros por pessoa e tipo.

## P0 — Antes de abrir para o grupo
- [x] Estrutura da faixa em compassos, com formatos prontos (Rap padrão, Cypher, Refrão na frente) e blocos livres.
- [x] Nome artístico preenchido sozinho no envio da guia.
- [x] Escolher a parte no envio; sem estrutura montada, partes básicas (Intro, Verso 1, Refrão, Verso 2, Ponte, Final).
- [x] Ajuste por tempo e compasso (−1 tempo, +1 compasso) e botão "colar no compasso".
- [x] Trocar a ordem das guias reposiciona os tempos em cascata.
- [ ] Criar parte nova na hora do envio (Verso 4, Ponte 2, Interlúdio) sem depender do produtor.
- [ ] Guia nova entra colada no fim do que já existe e o artista ajusta a partir dali.
- [ ] Conta própria para qualquer pessoa: espaço particular + participar de vários grupos/bandas.
- [ ] Convidar integrantes para cada grupo, com função por grupo.
- [ ] Juntar singles dentro de um EP ou álbum.
- [ ] Testar sincronização e limpeza com beat e gravações reais de celular (vazamento alto, ruído, silêncio inicial).
- [ ] Testar com contas reais de produtor e de artista.
- [ ] Conferir a gravação pelo navegador no iPhone e no Android.
- [ ] Publicar e compartilhar o endereço definitivo.


## P1 — Depois do grupo operando
- [ ] Gerar opções de montagem trocando a ordem das vozes, ouvir e baixar cada opção.
- [ ] Enquete no grupo para votar na melhor montagem.
- [ ] Vários takes para a mesma parte, com escolha de qual vai para o mix.
- [ ] Alinhar sozinho usando o beat que vazou na gravação.
- [ ] Aviso para quem foi mencionado na conversa.
- [ ] Enviar instruções faladas em MP3 e gerar um guia organizado e editável.
- [ ] Versões de beat e comparação entre takes.
- [ ] Melhorar a precisão do alinhamento e da redução do beat com casos reais.

## P2 — Visão da plataforma (não agora)
- [ ] Créditos e divisão de royalties.
- [ ] Contratos e assinaturas.
- [ ] Metadados e distribuição digital.

## Fora do escopo atual
- Download de WAV e exportação em lote.
- Quadros de tarefas livres, editor de textos encadeados e setores extras.
- Qualquer automação de IA sem ação explícita do integrante.
- Promessa de separação de voz com qualidade de estúdio antes dos testes reais.

## Rodada concluída — sincronia, mix e menções (falta testar com áudio real)
- [x] Análise de sincronia com IA (trechos fora do tempo + sugestões)
- [x] Offset recomendado pela IA com explicação
- [x] Volumes independentes voz/beat + entrada precisa no player combinado
- [x] Baixar MP3 da guia com beat e mix completo com todas as guias limpas e mapeadas
- [x] Cursor de reprodução e clique para posicionar na timeline manual
- [x] Notificações e contador de não lidas para menções @ no chat da música

## Rodada tudo num lugar só (em andamento)
- [x] Grupos + espaço pessoal + login aberto + convites por grupo
- [x] Ouvir com o beat vira editor único (arrastar, volumes, zoom, MP3) e sai Ajuste manual
- [x] Corte de início/fim da voz arrastando
- [x] Tela Mapa da faixa (blocos, arrastar guias, MP3 final)
- [x] Singles em EP/Álbum

- [x] Celular: chat não corta mais, MP3 pelos Documentos, abas Conversa/Notas.
- [ ] Mapa com playhead ao vivo e play por bloco.
- [ ] Cadastro obrigatório (foto, nome artístico, WhatsApp, habilidades).
- [ ] Funções por projeto (artista, beatmaker, produtor...).
- [ ] Painel administrativo do app.
- [ ] Versões da faixa (V1, V2).
