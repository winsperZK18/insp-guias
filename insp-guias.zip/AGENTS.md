<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

## Project architecture

- Keep browser audio processing in `src/lib/audio` and `src/lib/dsp`; it runs locally to avoid uploading raw guides to third-party processors.
- Treat the audio bucket as private and resolve signed playback URLs; public buckets are blocked by workspace policy.
- Gate shared project data behind Google sign-in and membership in `user_roles`; the first authorized account becomes admin and later accounts require an email invitation.
- Model track structure as persisted project sections; audio analysis only proposes editable positions because real phone recordings vary.
- Enforce admin, producer, and artist capabilities in database and storage policies; UI visibility is never the security boundary.
- Posições de guias e partes derivam da grade de compassos em `src/lib/bars.ts` (BPM → tempo/compasso), porque artistas ajustam em música, não em segundos.
- Ajuste manual na timeline é liberado a admin/produtor ou a quem está em `timeline_editors`; o player ao vivo (`use-live-mix`) usa fontes separadas de beat e voz para reagendar a entrada em tempo real.
