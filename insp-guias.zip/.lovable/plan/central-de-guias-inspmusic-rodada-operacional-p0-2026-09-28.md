# Central de Guias INSPMUSIC — rodada operacional P0

## Objetivo
Deixar o módulo atual utilizável no celular para receber guias com beat de fundo, sugerir sincronização e organização musical, permitir correção manual e respeitar as funções do grupo. IA de instruções, download WAV e módulos futuros ficam fora desta rodada.

## Implementação

### 1. Roadmap e identidade
- Reescrever o roadmap em P0, P1 e P2, distinguindo concluído, implementado sem teste real e pendente.
- Registrar Central de Guias como primeiro módulo; royalties, contratos e distribuição apenas como visão futura.
- Incorporar o logotipo oficial enviado no acesso e no cabeçalho, ajustando a identidade aos tons preto, amarelo e laranja sem redesenhar o produto inteiro.

### 2. Experiência móvel
- Enxugar a primeira tela para mostrar projetos mais cedo e recolher a área administrativa.
- Adaptar cabeçalho, formulários e ações para telas pequenas, com alvos de toque de pelo menos 44 px.
- Manter “Enviar guia” sempre fácil de alcançar na página do projeto.
- Criar uma visão compacta de sincronização no celular; o mapa horizontal atual permanece como modo avançado.

### 3. Estrutura musical e sincronização
- Criar regiões persistentes por projeto: intro, verso, pré-refrão, refrão, ponte, final e personalizada.
- Analisar o beat localmente por energia e repetição para sugerir regiões prováveis, com destaque para refrão; toda sugestão será editável.
- Permitir escolher a parte ao enviar a guia e usar a região escolhida como auxílio de posicionamento.
- Melhorar a sugestão de entrada comparando a gravação suja ao beat original e mostrar o tempo detectado como resultado corrigível.
- Oferecer ajuste móvel por passos finos/maiores e campo numérico, mantendo comparação entre original e áudio tratado.
- Aceitar MP3 e demais formatos compatíveis tanto para beat quanto para guia; WAV continua apenas como formato técnico interno do resultado tratado, sem botão de download.

### 4. Funções e segurança
- Evoluir as funções para admin, produtor e artista.
- Registrar autoria de projetos e guias.
- Aplicar permissões reais nos dados e arquivos: admin administra tudo; produtor gerencia criação, beat, estrutura, processamento e status; artista gerencia apenas suas próprias guias enquanto não aprovadas.
- Refletir essas permissões nos controles visíveis sem depender somente da interface para segurança.

### 5. Validação
- Verificar acesso, central e projeto em 394 × 674 e desktop.
- Validar upload compatível, escolha de parte, ajustes de tempo, comparação original/tratada e restrições por função no que for possível com as contas disponíveis.
- Não declarar sincronização ou limpeza validadas em condições reais sem beat e gravações reais; manter esse teste marcado como pendência operacional.

## Fora desta rodada
- Transcrição e organização de instruções com IA.
- Download de WAV ou exportação em lote.
- Royalties, contratos e distribuição digital.
- Histórico, notificações e versões de beat.
