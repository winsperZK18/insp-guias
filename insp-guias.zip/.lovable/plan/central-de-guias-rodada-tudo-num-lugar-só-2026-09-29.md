# Central de Guias — Rodada "Tudo num lugar só"

Objetivo: juntar as funções repetidas, abrir o acesso para qualquer pessoa e criar a tela de mapeamento completo.

## 1. "Ouvir com o beat" vira o editor único (sai o "Ajuste manual")
- O botão "Ajuste manual na timeline" some. Tudo passa para o painel "Ouvir com o beat" de cada guia.
- No painel: ondas do beat e da voz, cursor andando, toque na régua para pular, **arrastar a voz** sobre o beat, botões −1 comp. / −1 tempo / ±0,02s / +1 tempo / +1 comp., volume da voz, volume do beat, zoom, **Baixar MP3** da guia e **Salvar posição**.
- Quem não tem permissão só ouve (sem arrastar nem salvar).
- A análise de sincronia com IA continua, como um botão dentro do mesmo painel.

## 2. Tela de mapeamento completo (substitui o "mapa avançado")
- Nova página por faixa: "Mapa da faixa".
- Blocos em fila (Intro, Verso 1, Refrão, Ponte, Verso 4, Interlúdio...): criar, renomear, mudar número de compassos, reordenar e apagar.
- Cada guia aparece como cartão dentro do bloco; **arrastar o cartão de um bloco para outro** (ou trocar dois cartões de lugar) recalcula a entrada pelo compasso na hora.
- Ajuste fino por compasso/tempo em cada cartão.
- Faixa visual com ondas do beat e as vozes posicionadas, play da mix completa ao vivo.
- **Baixar MP3 final** com todas as guias limpas e posicionadas.
- O painel "Estrutura da faixa" e o "mapa avançado" atuais são removidos da página do projeto (ficam só nessa tela). A página do projeto ganha um botão "Abrir mapa da faixa".

## 3. Login aberto + espaço particular + vários grupos
- Qualquer conta Google entra; a conta é criada na hora (fim do "você não é do grupo").
- Todo usuário ganha automaticamente o **Meu espaço** (particular, só ele vê).
- Pode **criar grupos** (banda, coletivo, projeto) e é o administrador deles.
- **Seletor de grupo no topo**: alterna entre Meu espaço e os grupos dos quais faz parte.
- **Convites por e-mail por grupo**: ao entrar, a pessoa vê o convite pendente e aceita.
- **Níveis de acesso por grupo**: Administrador, Produtor, Artista. Produtor/admin usam o arrasto e o mapa; artista só com liberação (a chave "Quem pode ajustar" passa a ser por grupo).
- Projetos, guias, chat, menções e histórico passam a pertencer a um grupo; ninguém vê nada de outro grupo.
- O grupo atual e os dados existentes viram o primeiro grupo, mantendo todos os integrantes e funções.

## 4. Singles dentro de EP/Álbum
- No cartão do projeto: "Adicionar a um EP/Álbum" (menu) e arrastar um single sobre um EP/álbum na central.

## 5. Limpeza e integrações internas
- Remover: botão Ajuste manual, editor antigo, "mapa avançado", controles duplicados de −1s/+1s, código de partes/etapas que não é mais usado.
- Integrações: citar uma guia no chat (#) abre direto o painel "Ouvir com o beat" dela; mudar status da guia e salvar posição gera aviso no chat da faixa; o histórico de alterações passa a filtrar por grupo.

## Detalhes técnicos
- Novas tabelas: `groups`, `group_members (group_id, user_id, role)`, convites por grupo; coluna `group_id` em projetos e `parent_project_id` para EP/álbum. Colunas novas nulas + preenchimento do grupo existente; políticas de acesso reescritas com funções `is_group_member(user, group)` / `group_role(user, group)`.
- `claim_group_access` deixa de barrar: só cria o perfil e o espaço pessoal.
- Tabela `user_roles` global fica marcada como obsoleta (mantida por compatibilidade).
- Arrasto no mapa com pointer events (sem biblioteca nova), posições derivadas de `src/lib/bars.ts`.
- `timeline_editors` ganha `group_id`.

## Fica pendente
- Testes com gravações reais de celular, contas reais de produtor/artista e gravação em iPhone/Android.
- Enquete de votação entre opções de mapeamento (próxima rodada).
