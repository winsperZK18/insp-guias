# Rodada: celular, mapa com playhead, perfil, funções, painel admin e versões

Ordem pensada para gastar poucos créditos: primeiro o que está quebrado, depois o que mais ajuda no dia a dia.

## Etapa 1 — Correções rápidas no celular (prioridade)
1. **Chat cortado no fim da tela**: a barra fixa "Enviar guia" no rodapé cobre o chat. Adicionar espaço no fim da página e ajustar a altura do chat no celular.
2. **Escolher MP3 nos Documentos**: o seletor de arquivo pede "qualquer áudio", e o Android abre o gravador. Trocar para aceitar arquivos (mp3, wav, m4a, aac, ogg) para abrir o gerenciador de arquivos/Documentos.
3. **Chat com abas "Conversa" e "Notas"**: Notas é um bloco de texto da faixa (letra, ideias) salvo automaticamente e visível para quem participa da música.

## Etapa 2 — Mapa da faixa com playhead ao vivo
- Linha vertical (playhead) andando sobre a onda em tempo real, com tempo e compasso atuais.
- Arrastar ou tocar na onda para voltar/avançar sem parar a música.
- Botão ▶ em cada bloco (Intro, Verso 2...) que toca a partir do início daquele bloco.
- Bloco que está tocando fica destacado.

## Etapa 3 — Meu Espaço / Perfil obrigatório
- Após o primeiro login: tela "Conclua seu cadastro" com foto, nome artístico, WhatsApp (obrigatório) e habilidades (MC, Beatmaker, Produtor, Cantor/Compositor, Intérprete, Compositor).
- Sem concluir, não entra no app.
- Em "Meu Espaço": editar perfil e, para quem é administrador do app, atalho para o painel admin.

## Etapa 4 — Funções por projeto (créditos da faixa)
- Em cada single/EP/álbum: lista de participantes com funções (Artista, Beatmaker, Produtor, Cantor/Compositor, Intérprete, Compositor). Uma pessoa pode ter várias.
- Só admin/produtor do projeto edita.

## Etapa 5 — Painel administrativo do app
- Página só para o dono do app: total de usuários, ativos nos últimos 7/30 dias, novos cadastros, grupos, projetos, guias enviadas, lista de usuários (nome, e-mail, WhatsApp, último acesso).
- Acesso protegido no banco, não só escondido na tela.

## Etapa 6 — Versões da faixa (V1, V2...)
- Botão "Salvar versão" no mapa/painel: guarda o arranjo atual (guias escolhidas, entradas, cortes, blocos) como V1, V2...
- Lista simples de versões com "Ouvir" e "Restaurar". Rascunho = estado atual não salvo.

## Detalhes técnicos
- Novas tabelas: `project_notes`, `project_credits` (project_id, user_id ou nome livre, roles text[]), `project_versions` (snapshot jsonb), colunas em `profiles` (whatsapp, skills text[], onboarded_at, last_seen_at). Todas com GRANT + RLS via `in_project`/`manages_project`.
- Admin do app: papel `app_owner` separado em tabela própria + função security definer; estatísticas via função SQL restrita.
- Playhead: reutilizar `use-multi-live-mix` com `seek(t)` e requestAnimationFrame.

## Custo estimado
Etapa 1 é barata. As etapas 2 a 6 são maiores; posso fazer em rodadas separadas conforme seus créditos.
