CREATE POLICY "guias_audio_select" ON storage.objects FOR SELECT TO anon, authenticated
USING (bucket_id = 'guias-audio' AND (name LIKE 'beats/%' OR name LIKE 'guias/%' OR name LIKE 'vozes/%' OR name LIKE 'previas/%'));

CREATE POLICY "guias_audio_insert" ON storage.objects FOR INSERT TO anon, authenticated
WITH CHECK (bucket_id = 'guias-audio' AND (name LIKE 'beats/%' OR name LIKE 'guias/%' OR name LIKE 'vozes/%' OR name LIKE 'previas/%'));

CREATE POLICY "guias_audio_update" ON storage.objects FOR UPDATE TO anon, authenticated
USING (bucket_id = 'guias-audio' AND (name LIKE 'beats/%' OR name LIKE 'guias/%' OR name LIKE 'vozes/%' OR name LIKE 'previas/%'))
WITH CHECK (bucket_id = 'guias-audio' AND (name LIKE 'beats/%' OR name LIKE 'guias/%' OR name LIKE 'vozes/%' OR name LIKE 'previas/%'));

CREATE POLICY "guias_audio_delete" ON storage.objects FOR DELETE TO anon, authenticated
USING (bucket_id = 'guias-audio' AND (name LIKE 'beats/%' OR name LIKE 'guias/%' OR name LIKE 'vozes/%' OR name LIKE 'previas/%'));