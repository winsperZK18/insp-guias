ALTER TABLE public.guides ADD COLUMN trim_start_seconds numeric NOT NULL DEFAULT 0;
ALTER TABLE public.guides ADD COLUMN trim_end_seconds numeric;