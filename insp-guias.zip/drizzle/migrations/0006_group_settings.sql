create table public.group_settings (id integer primary key default 1 check (id = 1), group_name text, updated_by uuid references auth.users (id) on delete set null, updated_at timestamptz not null default now());

GRANT SELECT, UPDATE ON public.group_settings TO authenticated;
GRANT ALL ON public.group_settings TO service_role;

alter table public.group_settings enable row level security;

create policy "Membros podem ver o nome do grupo"
  on public.group_settings for select
  to authenticated
  using (public.is_group_member(auth.uid()));

create policy "Admin pode definir o nome do grupo"
  on public.group_settings for update
  to authenticated
  using (public.has_role(auth.uid(), 'admin'))
  with check (public.has_role(auth.uid(), 'admin'));

insert into public.group_settings (id) values (1) on conflict (id) do nothing;