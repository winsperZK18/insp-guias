CREATE TABLE public.chat_reads (
  user_id uuid NOT NULL DEFAULT auth.uid(),
  project_id uuid NOT NULL REFERENCES public.projects(id) ON DELETE CASCADE,
  last_read_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (user_id, project_id)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.chat_reads TO authenticated;
GRANT ALL ON public.chat_reads TO service_role;
ALTER TABLE public.chat_reads ENABLE ROW LEVEL SECURITY;
CREATE POLICY "le propria leitura" ON public.chat_reads FOR SELECT TO authenticated USING (user_id = auth.uid());
CREATE POLICY "cria propria leitura" ON public.chat_reads FOR INSERT TO authenticated WITH CHECK (user_id = auth.uid() AND public.is_group_member(auth.uid()));
CREATE POLICY "atualiza propria leitura" ON public.chat_reads FOR UPDATE TO authenticated USING (user_id = auth.uid()) WITH CHECK (user_id = auth.uid());
CREATE INDEX project_messages_mentions_idx ON public.project_messages USING gin (mentions);