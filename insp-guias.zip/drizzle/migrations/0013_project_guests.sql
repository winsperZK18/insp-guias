CREATE TABLE public.project_guests (
  project_id uuid NOT NULL REFERENCES public.projects(id) ON DELETE CASCADE,
  email text NOT NULL,
  user_id uuid,
  invited_by uuid NOT NULL DEFAULT auth.uid(),
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (project_id, email)
);
GRANT SELECT, INSERT, DELETE ON public.project_guests TO authenticated;
GRANT ALL ON public.project_guests TO service_role;
ALTER TABLE public.project_guests ENABLE ROW LEVEL SECURITY;
CREATE POLICY "managers handle guests" ON public.project_guests FOR ALL TO authenticated
  USING (public.manages_project(auth.uid(), project_id)) WITH CHECK (public.manages_project(auth.uid(), project_id));
CREATE POLICY "guest sees own" ON public.project_guests FOR SELECT TO authenticated USING (user_id = auth.uid());

CREATE OR REPLACE FUNCTION public.in_project(_uid uuid, _project uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path TO 'public' AS $$
  SELECT public.is_member_of(_uid, public.project_group(_project))
    OR EXISTS (SELECT 1 FROM public.project_guests WHERE project_id = _project AND user_id = _uid)
$$;

CREATE POLICY "guests read project" ON public.projects FOR SELECT TO authenticated
  USING (EXISTS (SELECT 1 FROM public.project_guests g WHERE g.project_id = id AND g.user_id = auth.uid()));

CREATE OR REPLACE FUNCTION public.claim_project_invites()
RETURNS void LANGUAGE sql SECURITY DEFINER SET search_path TO 'public' AS $$
  UPDATE public.project_guests SET user_id = auth.uid()
  WHERE user_id IS NULL AND lower(email) = lower(auth.jwt() ->> 'email');
$$;
GRANT EXECUTE ON FUNCTION public.claim_project_invites() TO authenticated;