
-- Grupos
CREATE TABLE public.groups (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  is_personal boolean NOT NULL DEFAULT false,
  owner_id uuid NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX groups_one_personal ON public.groups(owner_id) WHERE is_personal;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.groups TO authenticated;
GRANT ALL ON public.groups TO service_role;

CREATE TABLE public.group_members (
  group_id uuid NOT NULL REFERENCES public.groups(id) ON DELETE CASCADE,
  user_id uuid NOT NULL,
  role public.app_role NOT NULL DEFAULT 'member',
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (group_id, user_id)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.group_members TO authenticated;
GRANT ALL ON public.group_members TO service_role;

CREATE TABLE public.group_invitations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  group_id uuid NOT NULL REFERENCES public.groups(id) ON DELETE CASCADE,
  email text NOT NULL,
  role public.app_role NOT NULL DEFAULT 'member',
  invited_by uuid NOT NULL DEFAULT auth.uid(),
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (group_id, email)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.group_invitations TO authenticated;
GRANT ALL ON public.group_invitations TO service_role;

CREATE TABLE public.group_timeline_editors (
  group_id uuid NOT NULL REFERENCES public.groups(id) ON DELETE CASCADE,
  user_id uuid NOT NULL,
  granted_by uuid DEFAULT auth.uid(),
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (group_id, user_id)
);
GRANT SELECT, INSERT, DELETE ON public.group_timeline_editors TO authenticated;
GRANT ALL ON public.group_timeline_editors TO service_role;

ALTER TABLE public.projects ADD COLUMN group_id uuid REFERENCES public.groups(id) ON DELETE CASCADE;
ALTER TABLE public.projects ADD COLUMN parent_project_id uuid REFERENCES public.projects(id) ON DELETE SET NULL;
ALTER TABLE public.audit_logs ADD COLUMN group_id uuid;

-- Funções de acesso
CREATE OR REPLACE FUNCTION public.member_role(_uid uuid, _group uuid) RETURNS public.app_role
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT role FROM public.group_members WHERE user_id = _uid AND group_id = _group
$$;
CREATE OR REPLACE FUNCTION public.is_member_of(_uid uuid, _group uuid) RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.group_members WHERE user_id = _uid AND group_id = _group)
$$;
CREATE OR REPLACE FUNCTION public.manages_group(_uid uuid, _group uuid) RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.group_members WHERE user_id = _uid AND group_id = _group AND role IN ('admin','producer'))
$$;
CREATE OR REPLACE FUNCTION public.admins_group(_uid uuid, _group uuid) RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.group_members WHERE user_id = _uid AND group_id = _group AND role = 'admin')
$$;
CREATE OR REPLACE FUNCTION public.project_group(_project uuid) RETURNS uuid
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT group_id FROM public.projects WHERE id = _project
$$;
CREATE OR REPLACE FUNCTION public.in_project(_uid uuid, _project uuid) RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT public.is_member_of(_uid, public.project_group(_project))
$$;
CREATE OR REPLACE FUNCTION public.manages_project(_uid uuid, _project uuid) RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT public.manages_group(_uid, public.project_group(_project))
$$;
CREATE OR REPLACE FUNCTION public.shares_group(_a uuid, _b uuid) RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT _a = _b OR EXISTS (SELECT 1 FROM public.group_members x JOIN public.group_members y ON x.group_id = y.group_id WHERE x.user_id = _a AND y.user_id = _b)
$$;
CREATE OR REPLACE FUNCTION public.can_read_audio(_uid uuid, _path text) RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.projects p WHERE (p.beat_path = _path OR p.preview_path = _path) AND public.is_member_of(_uid, p.group_id))
      OR EXISTS (SELECT 1 FROM public.guides g WHERE (g.audio_path = _path OR g.processed_path = _path) AND public.in_project(_uid, g.project_id))
$$;
CREATE OR REPLACE FUNCTION public.can_manage_audio(_uid uuid, _path text) RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.projects p WHERE (p.beat_path = _path OR p.preview_path = _path) AND public.manages_group(_uid, p.group_id))
      OR EXISTS (SELECT 1 FROM public.guides g WHERE (g.audio_path = _path OR g.processed_path = _path) AND public.manages_project(_uid, g.project_id))
$$;

-- Backfill: grupo atual vira o primeiro grupo
DO $$
DECLARE _gid uuid; _owner uuid; _name text;
BEGIN
  IF EXISTS (SELECT 1 FROM public.user_roles) THEN
    SELECT user_id INTO _owner FROM public.user_roles WHERE role = 'admin' ORDER BY created_at LIMIT 1;
    IF _owner IS NULL THEN SELECT user_id INTO _owner FROM public.user_roles ORDER BY created_at LIMIT 1; END IF;
    SELECT COALESCE(NULLIF(group_name,''), 'INSP MUSIC') INTO _name FROM public.group_settings LIMIT 1;
    INSERT INTO public.groups (name, owner_id) VALUES (COALESCE(_name,'INSP MUSIC'), _owner) RETURNING id INTO _gid;
    INSERT INTO public.group_members (group_id, user_id, role)
      SELECT DISTINCT ON (user_id) _gid, user_id, role FROM public.user_roles
      ORDER BY user_id, CASE role WHEN 'admin' THEN 0 WHEN 'producer' THEN 1 ELSE 2 END;
    UPDATE public.projects SET group_id = _gid WHERE group_id IS NULL;
    INSERT INTO public.group_invitations (group_id, email, role, invited_by)
      SELECT _gid, lower(email), role, invited_by FROM public.group_invites WHERE claimed_by IS NULL
      ON CONFLICT DO NOTHING;
    INSERT INTO public.group_timeline_editors (group_id, user_id, granted_by)
      SELECT _gid, user_id, granted_by FROM public.timeline_editors ON CONFLICT DO NOTHING;
  END IF;
END $$;

-- Espaço pessoal para quem já tem perfil
INSERT INTO public.groups (name, is_personal, owner_id)
  SELECT 'Meu espaço', true, id FROM public.profiles
  ON CONFLICT DO NOTHING;
INSERT INTO public.group_members (group_id, user_id, role)
  SELECT id, owner_id, 'admin' FROM public.groups WHERE is_personal
  ON CONFLICT DO NOTHING;

-- Entrada aberta: cria perfil, espaço pessoal e aceita convites
CREATE OR REPLACE FUNCTION public.claim_group_access(_display_name text DEFAULT NULL, _avatar_url text DEFAULT NULL)
RETURNS public.app_role LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  _uid uuid := auth.uid();
  _email text := lower(auth.jwt() ->> 'email');
  _gid uuid;
BEGIN
  IF _uid IS NULL OR _email IS NULL THEN RAISE EXCEPTION 'Authentication required'; END IF;
  INSERT INTO public.profiles (id, email, display_name, avatar_url)
  VALUES (_uid, _email, NULLIF(left(_display_name, 120), ''), NULLIF(left(_avatar_url, 2048), ''))
  ON CONFLICT (id) DO UPDATE SET email = EXCLUDED.email,
    display_name = COALESCE(public.profiles.display_name, EXCLUDED.display_name),
    avatar_url = COALESCE(EXCLUDED.avatar_url, public.profiles.avatar_url), updated_at = now();
  SELECT id INTO _gid FROM public.groups WHERE owner_id = _uid AND is_personal;
  IF _gid IS NULL THEN
    INSERT INTO public.groups (name, is_personal, owner_id) VALUES ('Meu espaço', true, _uid) RETURNING id INTO _gid;
    INSERT INTO public.group_members (group_id, user_id, role) VALUES (_gid, _uid, 'admin') ON CONFLICT DO NOTHING;
  END IF;
  INSERT INTO public.group_members (group_id, user_id, role)
    SELECT group_id, _uid, role FROM public.group_invitations WHERE lower(email) = _email
    ON CONFLICT DO NOTHING;
  DELETE FROM public.group_invitations WHERE lower(email) = _email;
  RETURN 'member';
END $$;

CREATE OR REPLACE FUNCTION public.create_group(_name text) RETURNS uuid
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE _gid uuid;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'Authentication required'; END IF;
  IF length(trim(coalesce(_name,''))) = 0 THEN RAISE EXCEPTION 'Nome obrigatório'; END IF;
  INSERT INTO public.groups (name, owner_id) VALUES (left(trim(_name), 80), auth.uid()) RETURNING id INTO _gid;
  INSERT INTO public.group_members (group_id, user_id, role) VALUES (_gid, auth.uid(), 'admin');
  RETURN _gid;
END $$;

-- RLS das novas tabelas
ALTER TABLE public.groups ENABLE ROW LEVEL SECURITY;
CREATE POLICY "membros veem grupo" ON public.groups FOR SELECT TO authenticated USING (public.is_member_of(auth.uid(), id));
CREATE POLICY "admin renomeia grupo" ON public.groups FOR UPDATE TO authenticated USING (public.admins_group(auth.uid(), id)) WITH CHECK (public.admins_group(auth.uid(), id));
CREATE POLICY "dono apaga grupo" ON public.groups FOR DELETE TO authenticated USING (owner_id = auth.uid() AND NOT is_personal);

ALTER TABLE public.group_members ENABLE ROW LEVEL SECURITY;
CREATE POLICY "membros veem integrantes" ON public.group_members FOR SELECT TO authenticated USING (public.is_member_of(auth.uid(), group_id));
CREATE POLICY "admin muda funcao" ON public.group_members FOR UPDATE TO authenticated USING (public.admins_group(auth.uid(), group_id)) WITH CHECK (public.admins_group(auth.uid(), group_id));
CREATE POLICY "admin remove ou sair" ON public.group_members FOR DELETE TO authenticated USING (public.admins_group(auth.uid(), group_id) OR user_id = auth.uid());

ALTER TABLE public.group_invitations ENABLE ROW LEVEL SECURITY;
CREATE POLICY "admin gerencia convites" ON public.group_invitations FOR ALL TO authenticated USING (public.admins_group(auth.uid(), group_id)) WITH CHECK (public.admins_group(auth.uid(), group_id));

ALTER TABLE public.group_timeline_editors ENABLE ROW LEVEL SECURITY;
CREATE POLICY "membros leem liberacoes" ON public.group_timeline_editors FOR SELECT TO authenticated USING (public.is_member_of(auth.uid(), group_id));
CREATE POLICY "gestor libera" ON public.group_timeline_editors FOR INSERT TO authenticated WITH CHECK (public.manages_group(auth.uid(), group_id));
CREATE POLICY "gestor revoga" ON public.group_timeline_editors FOR DELETE TO authenticated USING (public.manages_group(auth.uid(), group_id));

-- Reescrever políticas por grupo
DROP POLICY IF EXISTS "Group members can select projects" ON public.projects;
DROP POLICY IF EXISTS "Managers create projects" ON public.projects;
DROP POLICY IF EXISTS "Managers delete projects" ON public.projects;
DROP POLICY IF EXISTS "Managers update projects" ON public.projects;
CREATE POLICY "membros veem projetos" ON public.projects FOR SELECT TO authenticated USING (public.is_member_of(auth.uid(), group_id));
CREATE POLICY "gestores criam projetos" ON public.projects FOR INSERT TO authenticated WITH CHECK (public.manages_group(auth.uid(), group_id) AND owner_id = auth.uid());
CREATE POLICY "gestores editam projetos" ON public.projects FOR UPDATE TO authenticated USING (public.manages_group(auth.uid(), group_id)) WITH CHECK (public.manages_group(auth.uid(), group_id));
CREATE POLICY "gestores apagam projetos" ON public.projects FOR DELETE TO authenticated USING (public.manages_group(auth.uid(), group_id));

DROP POLICY IF EXISTS "Authorized members delete guides" ON public.guides;
DROP POLICY IF EXISTS "Authorized members update guides" ON public.guides;
DROP POLICY IF EXISTS "Group members can select guides" ON public.guides;
DROP POLICY IF EXISTS "Members create own guides" ON public.guides;
CREATE POLICY "membros veem guias" ON public.guides FOR SELECT TO authenticated USING (public.in_project(auth.uid(), project_id));
CREATE POLICY "membros enviam guias" ON public.guides FOR INSERT TO authenticated WITH CHECK (public.in_project(auth.uid(), project_id) AND owner_id = auth.uid() AND status = 'recebido');
CREATE POLICY "autor ou gestor edita guia" ON public.guides FOR UPDATE TO authenticated USING (public.manages_project(auth.uid(), project_id) OR (owner_id = auth.uid() AND status <> 'aprovado')) WITH CHECK (public.manages_project(auth.uid(), project_id) OR owner_id = auth.uid());
CREATE POLICY "autor ou gestor apaga guia" ON public.guides FOR DELETE TO authenticated USING (public.manages_project(auth.uid(), project_id) OR (owner_id = auth.uid() AND status <> 'aprovado'));

DROP POLICY IF EXISTS "Managers create track sections" ON public.track_sections;
DROP POLICY IF EXISTS "Managers delete track sections" ON public.track_sections;
DROP POLICY IF EXISTS "Managers update track sections" ON public.track_sections;
DROP POLICY IF EXISTS "Members view track sections" ON public.track_sections;
CREATE POLICY "membros veem blocos" ON public.track_sections FOR SELECT TO authenticated USING (public.in_project(auth.uid(), project_id));
CREATE POLICY "gestores criam blocos" ON public.track_sections FOR INSERT TO authenticated WITH CHECK (public.manages_project(auth.uid(), project_id));
CREATE POLICY "gestores editam blocos" ON public.track_sections FOR UPDATE TO authenticated USING (public.manages_project(auth.uid(), project_id)) WITH CHECK (public.manages_project(auth.uid(), project_id));
CREATE POLICY "gestores apagam blocos" ON public.track_sections FOR DELETE TO authenticated USING (public.manages_project(auth.uid(), project_id));

DROP POLICY IF EXISTS "membros escrevem mensagens" ON public.project_messages;
DROP POLICY IF EXISTS "membros leem mensagens" ON public.project_messages;
DROP POLICY IF EXISTS "autor ou admin apaga mensagem" ON public.project_messages;
CREATE POLICY "membros leem mensagens" ON public.project_messages FOR SELECT TO authenticated USING (public.in_project(auth.uid(), project_id));
CREATE POLICY "membros escrevem mensagens" ON public.project_messages FOR INSERT TO authenticated WITH CHECK (public.in_project(auth.uid(), project_id) AND author_id = auth.uid());
CREATE POLICY "autor ou admin apaga mensagem" ON public.project_messages FOR DELETE TO authenticated USING (author_id = auth.uid() OR public.admins_group(auth.uid(), public.project_group(project_id)));

DROP POLICY IF EXISTS "membros escrevem comentarios" ON public.guide_comments;
DROP POLICY IF EXISTS "membros leem comentarios" ON public.guide_comments;
CREATE POLICY "membros leem comentarios" ON public.guide_comments FOR SELECT TO authenticated USING (public.in_project(auth.uid(), project_id));
CREATE POLICY "membros escrevem comentarios" ON public.guide_comments FOR INSERT TO authenticated WITH CHECK (public.in_project(auth.uid(), project_id) AND author_id = auth.uid());

DROP POLICY IF EXISTS "membros leem reacoes" ON public.reactions;
DROP POLICY IF EXISTS "membros reagem" ON public.reactions;
CREATE POLICY "membros leem reacoes" ON public.reactions FOR SELECT TO authenticated USING (
  public.shares_group(auth.uid(), user_id));
CREATE POLICY "membros reagem" ON public.reactions FOR INSERT TO authenticated WITH CHECK (user_id = auth.uid());

DROP POLICY IF EXISTS "cria propria leitura" ON public.chat_reads;
CREATE POLICY "cria propria leitura" ON public.chat_reads FOR INSERT TO authenticated WITH CHECK (user_id = auth.uid() AND public.in_project(auth.uid(), project_id));

DROP POLICY IF EXISTS "Members can view profiles" ON public.profiles;
CREATE POLICY "perfis de quem divide grupo" ON public.profiles FOR SELECT TO authenticated USING (public.shares_group(auth.uid(), id));

DROP POLICY IF EXISTS "admin le auditoria" ON public.audit_logs;
CREATE POLICY "admin le auditoria do grupo" ON public.audit_logs FOR SELECT TO authenticated USING (group_id IS NOT NULL AND public.admins_group(auth.uid(), group_id));
UPDATE public.audit_logs a SET group_id = p.group_id FROM public.projects p
  WHERE a.group_id IS NULL AND (a.entity_id = p.id OR (a.details->>'projeto_id')::text = p.id::text);

-- Auditoria com grupo
CREATE OR REPLACE FUNCTION public.log_project_audit() RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    INSERT INTO public.audit_logs (actor_id, action, entity_type, entity_id, entity_label, details, group_id)
    VALUES (auth.uid(), 'criou', 'projeto', NEW.id, NEW.title, jsonb_build_object('status', NEW.status), NEW.group_id);
    RETURN NEW;
  ELSIF TG_OP = 'UPDATE' THEN
    IF NEW.status IS DISTINCT FROM OLD.status OR NEW.title IS DISTINCT FROM OLD.title OR NEW.beat_path IS DISTINCT FROM OLD.beat_path OR NEW.parent_project_id IS DISTINCT FROM OLD.parent_project_id THEN
      INSERT INTO public.audit_logs (actor_id, action, entity_type, entity_id, entity_label, details, group_id)
      VALUES (auth.uid(), 'alterou', 'projeto', NEW.id, NEW.title,
        jsonb_build_object('de', jsonb_build_object('status', OLD.status, 'titulo', OLD.title, 'beat', OLD.beat_file_name),
                           'para', jsonb_build_object('status', NEW.status, 'titulo', NEW.title, 'beat', NEW.beat_file_name)), NEW.group_id);
    END IF;
    RETURN NEW;
  ELSE
    INSERT INTO public.audit_logs (actor_id, action, entity_type, entity_id, entity_label, details, group_id)
    VALUES (auth.uid(), 'apagou', 'projeto', OLD.id, OLD.title, '{}'::jsonb, OLD.group_id);
    RETURN OLD;
  END IF;
END $$;

CREATE OR REPLACE FUNCTION public.log_guide_audit() RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    INSERT INTO public.audit_logs (actor_id, action, entity_type, entity_id, entity_label, details, group_id)
    VALUES (auth.uid(), 'enviou', 'guia', NEW.id, NEW.artist_name, jsonb_build_object('projeto_id', NEW.project_id, 'parte', NEW.part_label), public.project_group(NEW.project_id));
    RETURN NEW;
  ELSIF TG_OP = 'UPDATE' THEN
    IF NEW.status IS DISTINCT FROM OLD.status THEN
      INSERT INTO public.audit_logs (actor_id, action, entity_type, entity_id, entity_label, details, group_id)
      VALUES (auth.uid(), 'mudou status', 'guia', NEW.id, NEW.artist_name,
        jsonb_build_object('projeto_id', NEW.project_id, 'de', OLD.status, 'para', NEW.status), public.project_group(NEW.project_id));
    END IF;
    RETURN NEW;
  ELSE
    INSERT INTO public.audit_logs (actor_id, action, entity_type, entity_id, entity_label, details, group_id)
    VALUES (auth.uid(), 'apagou', 'guia', OLD.id, OLD.artist_name, jsonb_build_object('projeto_id', OLD.project_id), public.project_group(OLD.project_id));
    RETURN OLD;
  END IF;
END $$;

CREATE OR REPLACE FUNCTION public.log_member_audit() RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE target_email text; r record;
BEGIN
  IF TG_OP = 'DELETE' THEN r := OLD; ELSE r := NEW; END IF;
  SELECT email INTO target_email FROM public.profiles WHERE id = r.user_id;
  INSERT INTO public.audit_logs (actor_id, action, entity_type, entity_id, entity_label, details, group_id)
  VALUES (auth.uid(), CASE TG_OP WHEN 'INSERT' THEN 'entrou no grupo' WHEN 'UPDATE' THEN 'alterou permissão' ELSE 'saiu do grupo' END,
          'integrante', r.user_id, COALESCE(target_email, r.user_id::text), jsonb_build_object('funcao', r.role), r.group_id);
  RETURN r;
END $$;
CREATE TRIGGER trg_audit_members AFTER INSERT OR UPDATE OR DELETE ON public.group_members FOR EACH ROW EXECUTE FUNCTION public.log_member_audit();

-- Áudio: acesso pelo projeto/guia que usa o arquivo
DROP POLICY IF EXISTS "Members read group audio" ON storage.objects;
DROP POLICY IF EXISTS "Members upload owned audio" ON storage.objects;
DROP POLICY IF EXISTS "Authorized members update audio" ON storage.objects;
DROP POLICY IF EXISTS "Authorized members delete audio" ON storage.objects;
CREATE POLICY "Ler audio do grupo" ON storage.objects FOR SELECT TO authenticated USING (bucket_id = 'guias-audio' AND (owner_id = auth.uid()::text OR public.can_read_audio(auth.uid(), name)));
CREATE POLICY "Enviar audio proprio" ON storage.objects FOR INSERT TO authenticated WITH CHECK (bucket_id = 'guias-audio' AND owner_id = auth.uid()::text);
CREATE POLICY "Atualizar audio" ON storage.objects FOR UPDATE TO authenticated USING (bucket_id = 'guias-audio' AND (owner_id = auth.uid()::text OR public.can_manage_audio(auth.uid(), name))) WITH CHECK (bucket_id = 'guias-audio');
CREATE POLICY "Apagar audio" ON storage.objects FOR DELETE TO authenticated USING (bucket_id = 'guias-audio' AND (owner_id = auth.uid()::text OR public.can_manage_audio(auth.uid(), name)));

COMMENT ON TABLE public.user_roles IS 'DEPRECATED: replaced by group_members';
COMMENT ON TABLE public.group_invites IS 'DEPRECATED: replaced by group_invitations';
COMMENT ON TABLE public.group_settings IS 'DEPRECATED: replaced by groups.name';
COMMENT ON TABLE public.timeline_editors IS 'DEPRECATED: replaced by group_timeline_editors';
COMMENT ON TABLE public.track_tasks IS 'DEPRECATED: checklist removido';
