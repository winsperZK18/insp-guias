-- Helper: membro do grupo
CREATE OR REPLACE FUNCTION public.is_group_member(_user_id uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _user_id)
$$;

-- ============ CHAT POR GUIA ============
CREATE TABLE public.guide_comments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  guide_id uuid NOT NULL REFERENCES public.guides(id) ON DELETE CASCADE,
  project_id uuid NOT NULL REFERENCES public.projects(id) ON DELETE CASCADE,
  author_id uuid NOT NULL DEFAULT auth.uid(),
  body text NOT NULL,
  reply_to_id uuid REFERENCES public.guide_comments(id) ON DELETE SET NULL,
  mentions uuid[] NOT NULL DEFAULT '{}',
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_guide_comments_guide ON public.guide_comments(guide_id, created_at);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.guide_comments TO authenticated;
GRANT ALL ON public.guide_comments TO service_role;
ALTER TABLE public.guide_comments ENABLE ROW LEVEL SECURITY;

CREATE POLICY "membros leem comentarios" ON public.guide_comments
  FOR SELECT TO authenticated USING (public.is_group_member(auth.uid()));
CREATE POLICY "membros escrevem comentarios" ON public.guide_comments
  FOR INSERT TO authenticated WITH CHECK (public.is_group_member(auth.uid()) AND author_id = auth.uid());
CREATE POLICY "autor edita comentario" ON public.guide_comments
  FOR UPDATE TO authenticated USING (author_id = auth.uid()) WITH CHECK (author_id = auth.uid());
CREATE POLICY "autor ou admin apaga comentario" ON public.guide_comments
  FOR DELETE TO authenticated USING (author_id = auth.uid() OR public.has_role(auth.uid(), 'admin'));

-- ============ REACOES COM EMOJI ============
CREATE TABLE public.reactions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  comment_id uuid REFERENCES public.guide_comments(id) ON DELETE CASCADE,
  guide_id uuid REFERENCES public.guides(id) ON DELETE CASCADE,
  user_id uuid NOT NULL DEFAULT auth.uid(),
  emoji text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT reaction_target_check CHECK (num_nonnulls(comment_id, guide_id) = 1)
);
CREATE UNIQUE INDEX idx_reaction_comment_unique ON public.reactions(comment_id, user_id, emoji) WHERE comment_id IS NOT NULL;
CREATE UNIQUE INDEX idx_reaction_guide_unique ON public.reactions(guide_id, user_id, emoji) WHERE guide_id IS NOT NULL;

GRANT SELECT, INSERT, DELETE ON public.reactions TO authenticated;
GRANT ALL ON public.reactions TO service_role;
ALTER TABLE public.reactions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "membros leem reacoes" ON public.reactions
  FOR SELECT TO authenticated USING (public.is_group_member(auth.uid()));
CREATE POLICY "membros reagem" ON public.reactions
  FOR INSERT TO authenticated WITH CHECK (public.is_group_member(auth.uid()) AND user_id = auth.uid());
CREATE POLICY "remove propria reacao" ON public.reactions
  FOR DELETE TO authenticated USING (user_id = auth.uid());

-- ============ CHECKLIST DA FAIXA ============
CREATE TABLE public.track_tasks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id uuid NOT NULL REFERENCES public.projects(id) ON DELETE CASCADE,
  title text NOT NULL,
  position integer NOT NULL DEFAULT 0,
  done boolean NOT NULL DEFAULT false,
  done_by uuid,
  done_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_track_tasks_project ON public.track_tasks(project_id, position);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.track_tasks TO authenticated;
GRANT ALL ON public.track_tasks TO service_role;
ALTER TABLE public.track_tasks ENABLE ROW LEVEL SECURITY;

CREATE POLICY "membros leem tarefas" ON public.track_tasks
  FOR SELECT TO authenticated USING (public.is_group_member(auth.uid()));
CREATE POLICY "membros marcam tarefas" ON public.track_tasks
  FOR UPDATE TO authenticated USING (public.is_group_member(auth.uid())) WITH CHECK (public.is_group_member(auth.uid()));
CREATE POLICY "gestores criam tarefas" ON public.track_tasks
  FOR INSERT TO authenticated WITH CHECK (public.can_manage_projects(auth.uid()));
CREATE POLICY "gestores apagam tarefas" ON public.track_tasks
  FOR DELETE TO authenticated USING (public.can_manage_projects(auth.uid()));

-- Checklist industrial pre-semeado ao criar o projeto
CREATE OR REPLACE FUNCTION public.seed_track_tasks()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO public.track_tasks (project_id, title, position)
  VALUES
    (NEW.id, 'Beat definido com BPM e tom', 0),
    (NEW.id, 'Partes da faixa mapeadas', 1),
    (NEW.id, 'Refrão gravado', 2),
    (NEW.id, 'Verso 1 gravado', 3),
    (NEW.id, 'Verso 2 gravado', 4),
    (NEW.id, 'Dobras e ad-libs enviadas', 5),
    (NEW.id, 'Guias alinhadas e limpas', 6),
    (NEW.id, 'Prévia aprovada pelo produtor', 7);
  RETURN NEW;
END;
$$;
CREATE TRIGGER trg_seed_track_tasks AFTER INSERT ON public.projects
  FOR EACH ROW EXECUTE FUNCTION public.seed_track_tasks();

INSERT INTO public.track_tasks (project_id, title, position)
SELECT p.id, t.title, t.position
FROM public.projects p
CROSS JOIN (VALUES
  ('Beat definido com BPM e tom', 0),
  ('Partes da faixa mapeadas', 1),
  ('Refrão gravado', 2),
  ('Verso 1 gravado', 3),
  ('Verso 2 gravado', 4),
  ('Dobras e ad-libs enviadas', 5),
  ('Guias alinhadas e limpas', 6),
  ('Prévia aprovada pelo produtor', 7)
) AS t(title, position)
WHERE NOT EXISTS (SELECT 1 FROM public.track_tasks tt WHERE tt.project_id = p.id);

-- ============ AUDITORIA ============
CREATE TABLE public.audit_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  actor_id uuid,
  action text NOT NULL,
  entity_type text NOT NULL,
  entity_id uuid,
  entity_label text,
  details jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_audit_logs_created ON public.audit_logs(created_at DESC);

GRANT SELECT ON public.audit_logs TO authenticated;
GRANT ALL ON public.audit_logs TO service_role;
ALTER TABLE public.audit_logs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "admin le auditoria" ON public.audit_logs
  FOR SELECT TO authenticated USING (public.has_role(auth.uid(), 'admin'));

CREATE OR REPLACE FUNCTION public.log_project_audit()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    INSERT INTO public.audit_logs (actor_id, action, entity_type, entity_id, entity_label, details)
    VALUES (auth.uid(), 'criou', 'projeto', NEW.id, NEW.title, jsonb_build_object('status', NEW.status));
    RETURN NEW;
  ELSIF TG_OP = 'UPDATE' THEN
    IF NEW.status IS DISTINCT FROM OLD.status OR NEW.title IS DISTINCT FROM OLD.title OR NEW.beat_path IS DISTINCT FROM OLD.beat_path THEN
      INSERT INTO public.audit_logs (actor_id, action, entity_type, entity_id, entity_label, details)
      VALUES (auth.uid(), 'alterou', 'projeto', NEW.id, NEW.title,
        jsonb_build_object('de', jsonb_build_object('status', OLD.status, 'titulo', OLD.title, 'beat', OLD.beat_file_name),
                           'para', jsonb_build_object('status', NEW.status, 'titulo', NEW.title, 'beat', NEW.beat_file_name)));
    END IF;
    RETURN NEW;
  ELSE
    INSERT INTO public.audit_logs (actor_id, action, entity_type, entity_id, entity_label, details)
    VALUES (auth.uid(), 'apagou', 'projeto', OLD.id, OLD.title, '{}'::jsonb);
    RETURN OLD;
  END IF;
END;
$$;
CREATE TRIGGER trg_audit_projects AFTER INSERT OR UPDATE OR DELETE ON public.projects
  FOR EACH ROW EXECUTE FUNCTION public.log_project_audit();

CREATE OR REPLACE FUNCTION public.log_guide_audit()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    INSERT INTO public.audit_logs (actor_id, action, entity_type, entity_id, entity_label, details)
    VALUES (auth.uid(), 'enviou', 'guia', NEW.id, NEW.artist_name, jsonb_build_object('projeto_id', NEW.project_id, 'parte', NEW.part_label));
    RETURN NEW;
  ELSIF TG_OP = 'UPDATE' THEN
    IF NEW.status IS DISTINCT FROM OLD.status THEN
      INSERT INTO public.audit_logs (actor_id, action, entity_type, entity_id, entity_label, details)
      VALUES (auth.uid(), 'mudou status', 'guia', NEW.id, NEW.artist_name,
        jsonb_build_object('projeto_id', NEW.project_id, 'de', OLD.status, 'para', NEW.status));
    END IF;
    RETURN NEW;
  ELSE
    INSERT INTO public.audit_logs (actor_id, action, entity_type, entity_id, entity_label, details)
    VALUES (auth.uid(), 'apagou', 'guia', OLD.id, OLD.artist_name, jsonb_build_object('projeto_id', OLD.project_id));
    RETURN OLD;
  END IF;
END;
$$;
CREATE TRIGGER trg_audit_guides AFTER INSERT OR UPDATE OR DELETE ON public.guides
  FOR EACH ROW EXECUTE FUNCTION public.log_guide_audit();

CREATE OR REPLACE FUNCTION public.log_role_audit()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE target_email text;
BEGIN
  IF TG_OP = 'DELETE' THEN
    SELECT email INTO target_email FROM public.profiles WHERE id = OLD.user_id;
    INSERT INTO public.audit_logs (actor_id, action, entity_type, entity_id, entity_label, details)
    VALUES (auth.uid(), 'removeu permissão', 'integrante', OLD.user_id, COALESCE(target_email, OLD.user_id::text), jsonb_build_object('funcao', OLD.role));
    RETURN OLD;
  END IF;
  SELECT email INTO target_email FROM public.profiles WHERE id = NEW.user_id;
  INSERT INTO public.audit_logs (actor_id, action, entity_type, entity_id, entity_label, details)
  VALUES (auth.uid(), CASE WHEN TG_OP = 'INSERT' THEN 'definiu permissão' ELSE 'alterou permissão' END,
          'integrante', NEW.user_id, COALESCE(target_email, NEW.user_id::text), jsonb_build_object('funcao', NEW.role));
  RETURN NEW;
END;
$$;
CREATE TRIGGER trg_audit_roles AFTER INSERT OR UPDATE OR DELETE ON public.user_roles
  FOR EACH ROW EXECUTE FUNCTION public.log_role_audit();