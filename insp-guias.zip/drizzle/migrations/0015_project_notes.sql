CREATE TABLE public.project_notes (
  project_id uuid PRIMARY KEY REFERENCES public.projects(id) ON DELETE CASCADE,
  body text NOT NULL DEFAULT '',
  updated_by uuid DEFAULT auth.uid(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE ON public.project_notes TO authenticated;
GRANT ALL ON public.project_notes TO service_role;
ALTER TABLE public.project_notes ENABLE ROW LEVEL SECURITY;
CREATE POLICY "participantes leem notas" ON public.project_notes FOR SELECT TO authenticated USING (public.in_project(auth.uid(), project_id));
CREATE POLICY "participantes criam notas" ON public.project_notes FOR INSERT TO authenticated WITH CHECK (public.in_project(auth.uid(), project_id));
CREATE POLICY "participantes editam notas" ON public.project_notes FOR UPDATE TO authenticated USING (public.in_project(auth.uid(), project_id)) WITH CHECK (public.in_project(auth.uid(), project_id));