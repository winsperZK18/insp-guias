ALTER TABLE public.guides ALTER COLUMN status SET DEFAULT 'novo_take';

CREATE OR REPLACE FUNCTION public.can_manage_guide(_user_id uuid, _owner_id uuid, _status text)
 RETURNS boolean
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
  SELECT public.can_manage_projects(_user_id)
      OR (_owner_id = _user_id AND _status NOT IN ('aprovado', 'fechada'))
$function$;