CREATE TYPE public.app_role AS ENUM ('admin', 'member');

CREATE TABLE public.profiles (
  id uuid PRIMARY KEY,
  email text NOT NULL,
  display_name text,
  avatar_url text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE ON public.profiles TO authenticated;
GRANT ALL ON public.profiles TO service_role;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.user_roles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  role public.app_role NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, role)
);
GRANT SELECT ON public.user_roles TO authenticated;
GRANT ALL ON public.user_roles TO service_role;
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.group_invites (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text NOT NULL,
  role public.app_role NOT NULL DEFAULT 'member',
  invited_by uuid NOT NULL,
  claimed_by uuid,
  claimed_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (email)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.group_invites TO authenticated;
GRANT ALL ON public.group_invites TO service_role;
ALTER TABLE public.group_invites ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION public.has_role(_user_id uuid, _role public.app_role)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.user_roles
    WHERE user_id = _user_id AND role = _role
  )
$$;

CREATE OR REPLACE FUNCTION public.has_group_access(_user_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.user_roles
    WHERE user_id = _user_id AND role IN ('admin', 'member')
  )
$$;

CREATE OR REPLACE FUNCTION public.claim_group_access(_display_name text DEFAULT NULL, _avatar_url text DEFAULT NULL)
RETURNS public.app_role
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  _uid uuid := auth.uid();
  _email text := lower(auth.jwt() ->> 'email');
  _role public.app_role;
BEGIN
  IF _uid IS NULL OR _email IS NULL THEN
    RAISE EXCEPTION 'Authentication required';
  END IF;

  SELECT role INTO _role FROM public.user_roles WHERE user_id = _uid ORDER BY role LIMIT 1;

  IF _role IS NULL THEN
    LOCK TABLE public.user_roles IN SHARE ROW EXCLUSIVE MODE;
    IF NOT EXISTS (SELECT 1 FROM public.user_roles) THEN
      _role := 'admin';
    ELSE
      SELECT role INTO _role
      FROM public.group_invites
      WHERE lower(email) = _email AND claimed_by IS NULL;
    END IF;

    IF _role IS NULL THEN
      RETURN NULL;
    END IF;

    INSERT INTO public.user_roles (user_id, role) VALUES (_uid, _role)
    ON CONFLICT (user_id, role) DO NOTHING;

    UPDATE public.group_invites
    SET claimed_by = _uid, claimed_at = now()
    WHERE lower(email) = _email AND claimed_by IS NULL;
  END IF;

  INSERT INTO public.profiles (id, email, display_name, avatar_url)
  VALUES (_uid, _email, NULLIF(left(_display_name, 120), ''), NULLIF(left(_avatar_url, 2048), ''))
  ON CONFLICT (id) DO UPDATE SET
    email = EXCLUDED.email,
    display_name = COALESCE(EXCLUDED.display_name, public.profiles.display_name),
    avatar_url = COALESCE(EXCLUDED.avatar_url, public.profiles.avatar_url),
    updated_at = now();

  RETURN _role;
END;
$$;

GRANT EXECUTE ON FUNCTION public.has_role(uuid, public.app_role) TO authenticated;
GRANT EXECUTE ON FUNCTION public.has_group_access(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.claim_group_access(text, text) TO authenticated;

CREATE POLICY "Members can view profiles" ON public.profiles FOR SELECT TO authenticated
USING (public.has_group_access((SELECT auth.uid())));
CREATE POLICY "Users can update their profile" ON public.profiles FOR UPDATE TO authenticated
USING (id = (SELECT auth.uid())) WITH CHECK (id = (SELECT auth.uid()));
CREATE POLICY "Members can view roles" ON public.user_roles FOR SELECT TO authenticated
USING (public.has_group_access((SELECT auth.uid())));
CREATE POLICY "Admins manage invitations" ON public.group_invites FOR ALL TO authenticated
USING (public.has_role((SELECT auth.uid()), 'admin'))
WITH CHECK (public.has_role((SELECT auth.uid()), 'admin'));

DROP POLICY IF EXISTS projects_delete_all ON public.projects;
DROP POLICY IF EXISTS projects_update_all ON public.projects;
DROP POLICY IF EXISTS projects_insert_all ON public.projects;
DROP POLICY IF EXISTS projects_select_all ON public.projects;
REVOKE ALL ON public.projects FROM anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.projects TO authenticated;
CREATE POLICY "Group members can select projects" ON public.projects FOR SELECT TO authenticated
USING (public.has_group_access((SELECT auth.uid())));
CREATE POLICY "Group members can insert projects" ON public.projects FOR INSERT TO authenticated
WITH CHECK (public.has_group_access((SELECT auth.uid())));
CREATE POLICY "Group members can update projects" ON public.projects FOR UPDATE TO authenticated
USING (public.has_group_access((SELECT auth.uid())))
WITH CHECK (public.has_group_access((SELECT auth.uid())));
CREATE POLICY "Group members can delete projects" ON public.projects FOR DELETE TO authenticated
USING (public.has_group_access((SELECT auth.uid())));

DROP POLICY IF EXISTS guides_delete_all ON public.guides;
DROP POLICY IF EXISTS guides_update_all ON public.guides;
DROP POLICY IF EXISTS guides_insert_all ON public.guides;
DROP POLICY IF EXISTS guides_select_all ON public.guides;
REVOKE ALL ON public.guides FROM anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.guides TO authenticated;
CREATE POLICY "Group members can select guides" ON public.guides FOR SELECT TO authenticated
USING (public.has_group_access((SELECT auth.uid())));
CREATE POLICY "Group members can insert guides" ON public.guides FOR INSERT TO authenticated
WITH CHECK (public.has_group_access((SELECT auth.uid())));
CREATE POLICY "Group members can update guides" ON public.guides FOR UPDATE TO authenticated
USING (public.has_group_access((SELECT auth.uid())))
WITH CHECK (public.has_group_access((SELECT auth.uid())));
CREATE POLICY "Group members can delete guides" ON public.guides FOR DELETE TO authenticated
USING (public.has_group_access((SELECT auth.uid())));

DROP POLICY IF EXISTS guias_audio_select ON storage.objects;
DROP POLICY IF EXISTS guias_audio_insert ON storage.objects;
DROP POLICY IF EXISTS guias_audio_update ON storage.objects;
DROP POLICY IF EXISTS guias_audio_delete ON storage.objects;
CREATE POLICY "Group members can download audio" ON storage.objects FOR SELECT TO authenticated
USING (bucket_id = 'guias-audio' AND public.has_group_access((SELECT auth.uid())) AND (name LIKE 'beats/%' OR name LIKE 'guias/%' OR name LIKE 'vozes/%' OR name LIKE 'previas/%'));
CREATE POLICY "Group members can upload audio" ON storage.objects FOR INSERT TO authenticated
WITH CHECK (bucket_id = 'guias-audio' AND public.has_group_access((SELECT auth.uid())) AND owner_id = (SELECT auth.uid()::text) AND (name LIKE 'beats/%' OR name LIKE 'guias/%' OR name LIKE 'vozes/%' OR name LIKE 'previas/%'));
CREATE POLICY "Group members can replace audio" ON storage.objects FOR UPDATE TO authenticated
USING (bucket_id = 'guias-audio' AND public.has_group_access((SELECT auth.uid())) AND owner_id = (SELECT auth.uid()::text) AND (name LIKE 'beats/%' OR name LIKE 'guias/%' OR name LIKE 'vozes/%' OR name LIKE 'previas/%'))
WITH CHECK (bucket_id = 'guias-audio' AND public.has_group_access((SELECT auth.uid())) AND owner_id = (SELECT auth.uid()::text) AND (name LIKE 'beats/%' OR name LIKE 'guias/%' OR name LIKE 'vozes/%' OR name LIKE 'previas/%'));
CREATE POLICY "Group members can delete own audio" ON storage.objects FOR DELETE TO authenticated
USING (bucket_id = 'guias-audio' AND public.has_group_access((SELECT auth.uid())) AND owner_id = (SELECT auth.uid()::text) AND (name LIKE 'beats/%' OR name LIKE 'guias/%' OR name LIKE 'vozes/%' OR name LIKE 'previas/%'));