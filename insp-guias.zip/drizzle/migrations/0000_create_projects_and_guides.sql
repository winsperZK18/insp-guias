CREATE TABLE public.projects (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  status text NOT NULL DEFAULT 'ideia',
  bpm integer,
  musical_key text,
  notes text,
  release_kind text NOT NULL DEFAULT 'single',
  release_title text,
  beat_path text,
  beat_url text,
  beat_file_name text,
  beat_duration_seconds numeric,
  preview_path text,
  preview_url text,
  preview_created_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE public.guides (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id uuid NOT NULL REFERENCES public.projects(id) ON DELETE CASCADE,
  artist_name text NOT NULL,
  part_label text,
  status text NOT NULL DEFAULT 'recebido',
  audio_path text NOT NULL,
  audio_url text NOT NULL,
  file_name text,
  duration_seconds numeric,
  processed_path text,
  processed_url text,
  detected_offset_seconds numeric,
  entry_seconds numeric NOT NULL DEFAULT 0,
  position integer NOT NULL DEFAULT 0,
  notes text,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX guides_project_position_idx ON public.guides (project_id, position);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.projects TO anon, authenticated;
GRANT ALL ON public.projects TO service_role;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.guides TO anon, authenticated;
GRANT ALL ON public.guides TO service_role;

ALTER TABLE public.projects ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.guides ENABLE ROW LEVEL SECURITY;

CREATE POLICY "projects_select_all" ON public.projects FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "projects_insert_all" ON public.projects FOR INSERT TO anon, authenticated WITH CHECK (true);
CREATE POLICY "projects_update_all" ON public.projects FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "projects_delete_all" ON public.projects FOR DELETE TO anon, authenticated USING (true);

CREATE POLICY "guides_select_all" ON public.guides FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "guides_insert_all" ON public.guides FOR INSERT TO anon, authenticated WITH CHECK (true);
CREATE POLICY "guides_update_all" ON public.guides FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "guides_delete_all" ON public.guides FOR DELETE TO anon, authenticated USING (true);