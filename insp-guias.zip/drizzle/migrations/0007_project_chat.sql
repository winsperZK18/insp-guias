CREATE TABLE public.project_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id uuid NOT NULL REFERENCES public.projects(id) ON DELETE CASCADE,
  author_id uuid NOT NULL DEFAULT auth.uid(),
  body text NOT NULL,
  reply_to_id uuid REFERENCES public.project_messages(id) ON DELETE SET NULL,
  mentions uuid[] NOT NULL DEFAULT '{}',
  guide_refs uuid[] NOT NULL DEFAULT '{}',
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX project_messages_project_idx ON public.project_messages(project_id, created_at);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.project_messages TO authenticated;
GRANT ALL ON public.project_messages TO service_role;
ALTER TABLE public.project_messages ENABLE ROW LEVEL SECURITY;
CREATE POLICY "membros leem mensagens" ON public.project_messages FOR SELECT TO authenticated USING (public.is_group_member(auth.uid()));
CREATE POLICY "membros escrevem mensagens" ON public.project_messages FOR INSERT TO authenticated WITH CHECK (public.is_group_member(auth.uid()) AND author_id = auth.uid());
CREATE POLICY "autor edita mensagem" ON public.project_messages FOR UPDATE TO authenticated USING (author_id = auth.uid()) WITH CHECK (author_id = auth.uid());
CREATE POLICY "autor ou admin apaga mensagem" ON public.project_messages FOR DELETE TO authenticated USING (author_id = auth.uid() OR public.has_role(auth.uid(), 'admin'));
ALTER TABLE public.reactions ADD COLUMN message_id uuid REFERENCES public.project_messages(id) ON DELETE CASCADE;
COMMENT ON TABLE public.guide_comments IS 'DEPRECATED: replaced by project_messages (chat por música)';