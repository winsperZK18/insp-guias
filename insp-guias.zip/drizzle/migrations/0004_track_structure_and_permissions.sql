ALTER TABLE public.projects
  ADD COLUMN IF NOT EXISTS owner_id uuid REFERENCES auth.users(id) ON DELETE SET NULL;

ALTER TABLE public.guides
  ADD COLUMN IF NOT EXISTS owner_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS section_id uuid;

UPDATE public.projects
SET owner_id = (
  SELECT user_id FROM public.user_roles WHERE role = 'admin' ORDER BY created_at LIMIT 1
)
WHERE owner_id IS NULL;

UPDATE public.guides g
SET owner_id = p.owner_id
FROM public.projects p
WHERE g.project_id = p.id AND g.owner_id IS NULL;

ALTER TABLE public.projects ALTER COLUMN owner_id SET DEFAULT auth.uid();
ALTER TABLE public.guides ALTER COLUMN owner_id SET DEFAULT auth.uid();

CREATE TABLE public.track_sections (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id uuid NOT NULL REFERENCES public.projects(id) ON DELETE CASCADE,
  kind text NOT NULL CHECK (kind IN ('intro', 'verso', 'pre_refrao', 'refrao', 'ponte', 'final', 'personalizada')),
  label text NOT NULL,
  start_seconds numeric NOT NULL DEFAULT 0 CHECK (start_seconds >= 0),
  end_seconds numeric NOT NULL DEFAULT 0 CHECK (end_seconds >= start_seconds),
  is_suggested boolean NOT NULL DEFAULT false,
  confidence numeric CHECK (confidence IS NULL OR (confidence >= 0 AND confidence <= 1)),
  position integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.track_sections TO authenticated;
GRANT ALL ON public.track_sections TO service_role;
ALTER TABLE public.track_sections ENABLE ROW LEVEL SECURITY;

ALTER TABLE public.guides
  ADD CONSTRAINT guides_section_id_fkey FOREIGN KEY (section_id) REFERENCES public.track_sections(id) ON DELETE SET NULL;

CREATE OR REPLACE FUNCTION public.can_manage_projects(_user_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT public.has_role(_user_id, 'admin') OR public.has_role(_user_id, 'producer')
$$;

CREATE OR REPLACE FUNCTION public.can_manage_guide(_user_id uuid, _owner_id uuid, _status text)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT public.can_manage_projects(_user_id) OR (_owner_id = _user_id AND _status <> 'aprovado')
$$;

DROP POLICY IF EXISTS "Group members can insert projects" ON public.projects;
DROP POLICY IF EXISTS "Group members can update projects" ON public.projects;
DROP POLICY IF EXISTS "Group members can delete projects" ON public.projects;
CREATE POLICY "Managers create projects" ON public.projects FOR INSERT TO authenticated
  WITH CHECK (public.can_manage_projects((SELECT auth.uid())) AND owner_id = (SELECT auth.uid()));
CREATE POLICY "Managers update projects" ON public.projects FOR UPDATE TO authenticated
  USING (public.can_manage_projects((SELECT auth.uid()))) WITH CHECK (public.can_manage_projects((SELECT auth.uid())));
CREATE POLICY "Managers delete projects" ON public.projects FOR DELETE TO authenticated
  USING (public.can_manage_projects((SELECT auth.uid())));

DROP POLICY IF EXISTS "Group members can insert guides" ON public.guides;
DROP POLICY IF EXISTS "Group members can update guides" ON public.guides;
DROP POLICY IF EXISTS "Group members can delete guides" ON public.guides;
CREATE POLICY "Members create own guides" ON public.guides FOR INSERT TO authenticated
  WITH CHECK (public.has_group_access((SELECT auth.uid())) AND owner_id = (SELECT auth.uid()) AND status = 'recebido');
CREATE POLICY "Authorized members update guides" ON public.guides FOR UPDATE TO authenticated
  USING (public.can_manage_guide((SELECT auth.uid()), owner_id, status))
  WITH CHECK (public.can_manage_projects((SELECT auth.uid())) OR owner_id = (SELECT auth.uid()));
CREATE POLICY "Authorized members delete guides" ON public.guides FOR DELETE TO authenticated
  USING (public.can_manage_guide((SELECT auth.uid()), owner_id, status));

CREATE POLICY "Members view track sections" ON public.track_sections FOR SELECT TO authenticated
  USING (public.has_group_access((SELECT auth.uid())));
CREATE POLICY "Managers create track sections" ON public.track_sections FOR INSERT TO authenticated
  WITH CHECK (public.can_manage_projects((SELECT auth.uid())));
CREATE POLICY "Managers update track sections" ON public.track_sections FOR UPDATE TO authenticated
  USING (public.can_manage_projects((SELECT auth.uid()))) WITH CHECK (public.can_manage_projects((SELECT auth.uid())));
CREATE POLICY "Managers delete track sections" ON public.track_sections FOR DELETE TO authenticated
  USING (public.can_manage_projects((SELECT auth.uid())));

CREATE POLICY "Admins manage roles" ON public.user_roles FOR ALL TO authenticated
  USING (public.has_role((SELECT auth.uid()), 'admin'))
  WITH CHECK (public.has_role((SELECT auth.uid()), 'admin'));
GRANT INSERT, UPDATE, DELETE ON public.user_roles TO authenticated;

DROP POLICY IF EXISTS "Group members can delete own audio" ON storage.objects;
DROP POLICY IF EXISTS "Group members can download audio" ON storage.objects;
DROP POLICY IF EXISTS "Group members can replace audio" ON storage.objects;
DROP POLICY IF EXISTS "Group members can upload audio" ON storage.objects;
CREATE POLICY "Members read group audio" ON storage.objects FOR SELECT TO authenticated
  USING (bucket_id = 'guias-audio' AND public.has_group_access((SELECT auth.uid())));
CREATE POLICY "Members upload owned audio" ON storage.objects FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'guias-audio' AND owner_id = (SELECT auth.uid())::text AND public.has_group_access((SELECT auth.uid())));
CREATE POLICY "Authorized members update audio" ON storage.objects FOR UPDATE TO authenticated
  USING (bucket_id = 'guias-audio' AND (owner_id = (SELECT auth.uid())::text OR public.can_manage_projects((SELECT auth.uid()))))
  WITH CHECK (bucket_id = 'guias-audio' AND (owner_id = (SELECT auth.uid())::text OR public.can_manage_projects((SELECT auth.uid()))));
CREATE POLICY "Authorized members delete audio" ON storage.objects FOR DELETE TO authenticated
  USING (bucket_id = 'guias-audio' AND (owner_id = (SELECT auth.uid())::text OR public.can_manage_projects((SELECT auth.uid()))));