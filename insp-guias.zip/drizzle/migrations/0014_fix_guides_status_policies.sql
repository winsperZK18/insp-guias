DROP POLICY IF EXISTS "membros enviam guias" ON public.guides;
CREATE POLICY "membros enviam guias" ON public.guides FOR INSERT TO authenticated
  WITH CHECK (in_project(auth.uid(), project_id) AND owner_id = auth.uid() AND status = 'novo_take');
DROP POLICY IF EXISTS "autor ou gestor edita guia" ON public.guides;
CREATE POLICY "autor ou gestor edita guia" ON public.guides FOR UPDATE TO authenticated
  USING (manages_project(auth.uid(), project_id) OR (owner_id = auth.uid() AND status <> 'fechada'))
  WITH CHECK (manages_project(auth.uid(), project_id) OR (owner_id = auth.uid() AND status <> 'fechada'));
DROP POLICY IF EXISTS "autor ou gestor apaga guia" ON public.guides;
CREATE POLICY "autor ou gestor apaga guia" ON public.guides FOR DELETE TO authenticated
  USING (manages_project(auth.uid(), project_id) OR (owner_id = auth.uid() AND status <> 'fechada'));