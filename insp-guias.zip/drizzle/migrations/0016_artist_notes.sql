CREATE TABLE public.artist_notes (
  project_id uuid NOT NULL REFERENCES public.projects(id) ON DELETE CASCADE,
  author_id uuid NOT NULL DEFAULT auth.uid(),
  body text NOT NULL DEFAULT '',
  is_public boolean NOT NULL DEFAULT false,
  updated_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (project_id, author_id)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.artist_notes TO authenticated;
GRANT ALL ON public.artist_notes TO service_role;
ALTER TABLE public.artist_notes ENABLE ROW LEVEL SECURITY;
CREATE POLICY "ver propria ou publicada" ON public.artist_notes FOR SELECT TO authenticated
  USING (author_id = auth.uid() OR (is_public AND public.in_project(auth.uid(), project_id)));
CREATE POLICY "criar propria" ON public.artist_notes FOR INSERT TO authenticated
  WITH CHECK (author_id = auth.uid() AND public.in_project(auth.uid(), project_id));
CREATE POLICY "editar propria" ON public.artist_notes FOR UPDATE TO authenticated
  USING (author_id = auth.uid()) WITH CHECK (author_id = auth.uid());
CREATE POLICY "apagar propria" ON public.artist_notes FOR DELETE TO authenticated USING (author_id = auth.uid());
COMMENT ON TABLE public.project_notes IS 'DEPRECATED: replaced by artist_notes';