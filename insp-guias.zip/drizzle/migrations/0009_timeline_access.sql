CREATE TABLE public.timeline_editors (
  user_id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  granted_by uuid,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, DELETE ON public.timeline_editors TO authenticated;
GRANT ALL ON public.timeline_editors TO service_role;
ALTER TABLE public.timeline_editors ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Members read timeline access" ON public.timeline_editors FOR SELECT TO authenticated
  USING (EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = auth.uid()));
CREATE POLICY "Managers grant timeline access" ON public.timeline_editors FOR INSERT TO authenticated
  WITH CHECK (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'producer'));
CREATE POLICY "Managers revoke timeline access" ON public.timeline_editors FOR DELETE TO authenticated
  USING (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'producer'));